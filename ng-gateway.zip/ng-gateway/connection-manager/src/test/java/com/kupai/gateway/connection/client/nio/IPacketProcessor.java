package com.kupai.gateway.connection.client.nio;

import java.nio.channels.SocketChannel;

import com.kupai.gateway.connection.protocol.Command;

/**
 * Date: 17/1/9
 * Time: 下午9:55
 *
 * @author lintc
 */
public interface IPacketProcessor {
    void process(Command command);
    void write(SocketChannel channel, Command command) throws Exception ;
    void onError();
}
