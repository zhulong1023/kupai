package com.kupai.gateway.connection.client.nio;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.util.Constants;

/**
 * Date: 17/1/9
 * Time: 下午9:54
 *
 * @author lintc
 */
public class WebSocketPacketHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(WebSocketPacketHandler.class);
    private int readBufSize = 64 * 1024;
    private ByteBuffer lastDataBuffer = null;
    ByteBuffer receiveByteBuffer = ByteBuffer.allocate(readBufSize);
    private IPacketProcessor processor;

    public void setProcessor(IPacketProcessor processor) {
        this.processor = processor;
    }

    public void write(SocketChannel channel, Command command) throws Exception {
        processor.write(channel, command);
    }

    public boolean read(SocketChannel socketChannel) {
        try {
            receiveByteBuffer.clear();
            if (socketChannel.read(receiveByteBuffer) > 0) {
                receiveByteBuffer.flip();
                decode(receiveByteBuffer);
            }
        } catch (Exception e) {
            LOGGER.error("read packet error", e);
            fireError();
            return false;
        }
        return true;
    }

    public void fireError() {
        processor.onError();
    }

    private void decode(ByteBuffer dataBuffer) throws Exception {
        if (lastDataBuffer != null) {
            dataBuffer = mergeBuffer(lastDataBuffer, dataBuffer);
            lastDataBuffer = null;
        }

        for (; ; ) {
            int oldPosition = dataBuffer.position();
            boolean result = decodeBuffer(dataBuffer);
            if (result) {
                if (!dataBuffer.hasRemaining())
                    break;
                if (dataBuffer.position() == oldPosition)
                    break;
            } else
                break;
        }

        if (dataBuffer.hasRemaining()) {
            lastDataBuffer = copyBuffer(dataBuffer);
        }
    }

    private ByteBuffer mergeBuffer(ByteBuffer buffer1, ByteBuffer buffer2) {
        ByteBuffer newBuffer = ByteBuffer.allocate(buffer1.remaining()
                + buffer2.remaining());
        newBuffer.put(buffer1);
        newBuffer.put(buffer2);
        newBuffer.flip();
        return newBuffer;
    }

    private ByteBuffer copyBuffer(ByteBuffer dataBuffer) {
        ByteBuffer newBuffer = ByteBuffer.allocate(dataBuffer.remaining());
        newBuffer.put(dataBuffer);
        newBuffer.flip();
        return newBuffer;
    }

    private boolean decodeBuffer(ByteBuffer byteBuffer) throws Exception {
        int position = byteBuffer.position();

        int length = byteBuffer.remaining();
        if (length >= Constants.PACKET_MIN_BYTES) {
            try {
                //将二进制流转换为内存对象
//                Command command = Command.decode(byteBuffer);
//                //将command交付给报文解析器处理
//                processor.process(command);
            } catch (Exception ex) {
                LOGGER.error("decode or process byte buffer failed, details ", ex);
            }
            return true;
        }
        byteBuffer.position(position);
        return false;
    }
}
