package com.kupai.gateway.connection.client.ws;

import com.alibaba.fastjson.JSONObject;

import java.util.concurrent.atomic.AtomicLong;

public class CommandHelper {
    private static AtomicLong requestId = new AtomicLong(1);
    private static AtomicLong messageCount = new AtomicLong(0);

    public static long nextRequestId() {
        return requestId.getAndIncrement();
    }
    public static long addMessageCount() {
        return messageCount.getAndIncrement();
    }
    public static long messageCount() {
        return messageCount.get();
    }

    public static String buildAuth(long id) {
        JSONObject meta = new JSONObject();
        meta.put("type", 0);
        meta.put("event", "verify");
        meta.put("code", 1);

        JSONObject content = new JSONObject();
        content.put("passport", "sdfasdfadsf");
        content.put("source", 2);
        content.put("clientType", 0); // app
        content.put("role", 0);
//        content.put("callbackUrl", "http://localhost:8183/mock/auth/callback");

        JSONObject data = new JSONObject();
        data.put("meta", meta);
        data.put("content", content);

        JSONObject request = new JSONObject();
        request.put("code", 11);
        request.put("data", data);
        request.put("requestId", id);
        request.put("oneway", 0);
        request.put("type", 0);
        return request.toJSONString();
    }

    public static String buildMessage(long id, String message) {
        JSONObject meta_ext = new JSONObject();

        JSONObject meta = new JSONObject();
//        meta.put("type", 3);
        meta.put("event", "add");
        meta.put("code", 40);
        meta.put("from", "");
        meta.put("to", "1");
        meta.put("chatType", 2);
        meta.put("ext", meta_ext);

        JSONObject data = new JSONObject();
        data.put("meta", meta);
        data.put("content", message);

        JSONObject request = new JSONObject();
        request.put("code", 40);
        request.put("type", 0);
        request.put("version", 0);
        request.put("oneway", 1);
        request.put("data", data);
        request.put("requestId", id);
        return request.toJSONString();
    }

    public static String buildRoomOpt(long id, boolean enter, long roomId) {
        JSONObject meta = new JSONObject();
        meta.put("type", 1);
        meta.put("event", enter ? "enter" : "exit");
        meta.put("type", 1);

        JSONObject content = new JSONObject();
        content.put("roomId", 1);

        JSONObject data = new JSONObject();
        data.put("meta", meta);
        data.put("content", content);

        JSONObject request = new JSONObject();
        request.put("code", 12);
        request.put("type", 0);
        request.put("data", data);
        request.put("oneway", 0);
        request.put("version", 0);
        request.put("requestId", id);
        return request.toJSONString();
    }

    public static String buildSync(long id, String messageId) {
        JSONObject meta = new JSONObject();
        meta.put("event", "syc_message");
        meta.put("code", 30);
        meta.put("from", "");
        meta.put("to", "1");
        meta.put("chatType", 2);

        JSONObject data = new JSONObject();
        data.put("meta", meta);
        data.put("pullType", 0);
        data.put("messageId", messageId);
        data.put("pageSize", 5);

        JSONObject request = new JSONObject();
        request.put("code", 30);
        request.put("type", 0);
        request.put("data", data);
        request.put("oneway", 1);
        request.put("version", 0);
        request.put("requestId", id);
        return request.toJSONString();
    }
}
