package com.kupai.gateway.connection.client.nio;

/**
 * 专门用于处理Auth Command的业务处理器
 * Created by lintc on 17/1/12.
 */
public class AuthCommandProcessor {
    private WebSocketNioConnection webSocketNioConnection;

    public void setWebSocketNioConnection(WebSocketNioConnection webSocketNioConnection) {
        this.webSocketNioConnection = webSocketNioConnection;
    }

    public WebSocketNioConnection getWebSocketNioConnection() {
        return webSocketNioConnection;
    }


    public void updateAuthStatus(boolean status) {
        this.webSocketNioConnection.updateAuthStatus(status);
    }
}
