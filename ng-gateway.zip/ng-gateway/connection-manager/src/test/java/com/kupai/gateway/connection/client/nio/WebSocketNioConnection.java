package com.kupai.gateway.connection.client.nio;

import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.util.Constants;

/**
 * 基于NIO实现的TCP connection
 * Date: 17/1/9
 * Time: 下午9:49
 *
 * @author lintc
 */
public class WebSocketNioConnection {
    private static final Logger LOGGER = LoggerFactory.getLogger(WebSocketNioConnection.class);
    private volatile Selector selector;
    private volatile SocketChannel socketChannel;
    //连接是否认证成功
    private volatile boolean bAuthSuccess = false;
    private Thread receiveThread;
    private Timer timer;

    private final static int heartbeatInterval = 5000;
    //连续发送心跳包失败的最大次数
    private final static int MAX_HEART_BEAT_FAILED_COUNT = 10;

    private AtomicInteger heartbeatFailedCount = new AtomicInteger(0);
    private WebSocketPacketHandler webSocketPacketHandler;
    private String authContent;

    public WebSocketNioConnection(WebSocketPacketHandler webSocketPacketHandler, String authContent) {
        this.webSocketPacketHandler = webSocketPacketHandler;
        this.authContent = authContent;
    }


    public void setWebSocketPacketHandler(WebSocketPacketHandler packetHandler) {
        this.webSocketPacketHandler = packetHandler;
    }

    public void updateAuthStatus(boolean bAuthSuccess) {
        LOGGER.info(String.format("socket channel %s has auth success, auth_content %s", socketChannel, authContent));
        this.bAuthSuccess = bAuthSuccess;
    }


    public void write(Command Command) throws Exception {
        boolean isAlive = isAlive(socketChannel);
        if (isAlive && bAuthSuccess) {
            webSocketPacketHandler.write(socketChannel, Command);
        } else {
            LOGGER.warn(String.format("write Command %s failed, socketChannel isAlive=%s, socketChannel authSuccess=%s",
                    Command, isAlive, bAuthSuccess));
        }
    }


    void stop() {
        if (receiveThread != null) {
            LOGGER.info("stop connection and thread");
            try {
                timer.cancel();
                socketChannel.close();
                selector.close();
                receiveThread.interrupt();
            } catch (Exception e) {
                LOGGER.error("stop connection failed", e);
            }
            LOGGER.info("end to stop connection and thread");
        }
    }

    boolean start(InetSocketAddress address) {
        //尝试与IM服务器建立连接
        boolean bConnected = connect(address);
        //连接建立成功后,开启数据接收线程和心跳线程
        if (bConnected) {
            //数据接收线程
            receiveThread = new ReceiveThread("WebSocket-Receive-Thread");
            receiveThread.start();

            //心跳线程
            timer = new Timer("WebSocket-Client-Timer");
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    Command pingCommand = new Command<String>(RequestCode.HEARTBEAT_PING, Constants.PING_MESSAGE);
                    try {
                        webSocketPacketHandler.write(socketChannel, pingCommand);
                        LOGGER.info(String.format("send heart beat packet successfully, socket channel[%s->%s]",
                                socketChannel.getRemoteAddress(), socketChannel.getLocalAddress()));
                        //成功发送心跳包就需要将失败计数器清零
                        heartbeatFailedCount.set(0);
                    } catch (Throwable t) {
                        //心跳失败计数器+1
                        int failedCount = heartbeatFailedCount.incrementAndGet();
                        //该心跳线程不允许跑飞
                        LOGGER.error("heartbeat error. failed count " + failedCount + ", error details: ", t);
                        //判断是否需要重连
                        try {
                            //心跳失败次数达到最大值,重新连接
                            if (failedCount >= MAX_HEART_BEAT_FAILED_COUNT) {
                                //socket channel 是一个损坏的channel, 打印日志时需要特别小心
                                LOGGER.error(String.format("broken socket [%s] heartbeat successive failed count %s more than %s, should reconnect the IM Server.",
                                        socketChannel, failedCount, MAX_HEART_BEAT_FAILED_COUNT));

                                boolean isConnected = connect(address);
                                if (isConnected) {
                                    //清零失败计数器
                                    heartbeatFailedCount.set(0);
                                }
                            }
                        } catch (Exception e) {
                            LOGGER.error("do reconnect IM Server failed", e);
                        }
                    }
                }
            }, heartbeatInterval, heartbeatInterval);
        }
        return bConnected;
    }


    private boolean connect(InetSocketAddress address) {
        boolean bConnected = false;
        try {
            //假如连接已经存在且处于打开状态,先将老的连接关闭
            //socketChannel.isConnected()只是说明客户端发起的链接已经建立好,但是无法解决对端主动关闭该链接的情况.
            if (isAlive(socketChannel)) {
                LOGGER.warn(String.format("socket channel on %s is already opened and connected, close this old connection before create new connection. address: [%s->%s], opened:%s, connected:%s",
                        address, socketChannel.getRemoteAddress(), socketChannel.getLocalAddress(),
                        socketChannel.isOpen(), socketChannel.isConnected()));
                socketChannel.close();
                socketChannel = null;
            }

            //原有的selector 存在则将其关闭
            if (null != selector) {
                selector.close();
            }

            if (null != socketChannel) {
                //关闭原有连接,防止连接泄露
                socketChannel.close();
            }

            //建立socket channel
            socketChannel = SocketChannel.open();
            if (socketChannel.connect(address)) {
                socketChannel.configureBlocking(false);
                selector = Selector.open();
                socketChannel.register(selector, SelectionKey.OP_READ, webSocketPacketHandler);
                bConnected = true;
                LOGGER.info(String.format("connect to IM server successfully, socket_channel local_address %s, remote_address %s",
                        socketChannel.getRemoteAddress(), socketChannel.getRemoteAddress()));
            }
        } catch (Exception e) {
            LOGGER.error("connect to IM Server " + address + " failed", e);
        }

        //连接成功后,发送身份认证信息到服务端
        try {
            doAuth(this.authContent);
        } catch (Exception e) {
            LOGGER.warn("connection auth failed " + this.authContent, e);
        }

        return bConnected;
    }


    /**
     * 检测连接是否存活
     *
     * @param socketChannel 网络套接字连接
     * @return 存活则返回true, 否则为false
     */
    private boolean isAlive(SocketChannel socketChannel) {
        return null != socketChannel && socketChannel.isOpen() && socketChannel.isConnected();
    }

    private void doAuth(String authContent) throws Exception {
        if (!bAuthSuccess) {
            Command authCommand = new Command<String>(RequestCode.AUTH, authContent);
            webSocketPacketHandler.write(socketChannel, authCommand);
        }
    }


    private class ReceiveThread extends Thread {

        public ReceiveThread(String name) {
            super(name);
        }

        @Override
        public void run() {
            LOGGER.info("receive thread start");
            while (!Thread.interrupted()) {
                //只有在当前线程被中断的情况下,此接收线程才会结束生命,否则一直运行
                try {
                    if (WebSocketNioConnection.this.isAlive(socketChannel)) {
                        selector.select(1000);
                        Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
                        while (iterator.hasNext()) {
                            SelectionKey key = iterator.next();
                            WebSocketPacketHandler reader = (WebSocketPacketHandler) key.attachment();
                            iterator.remove();
                            if (key.isReadable()) {
                                //处理读请求
                                SocketChannel socketChannel = (SocketChannel) key.channel();
                                if (!reader.read(socketChannel)) {
                                    LOGGER.error("socket read error, local_address=" + socketChannel.getLocalAddress() + ", remote_address" + socketChannel.getRemoteAddress());
                                    key.cancel();
                                }
                            }
                        }
                    }
                } catch (Throwable t) {
                    LOGGER.error("receive thread has encountered exception, socket_channel  " + socketChannel, t);
                }
            }
            LOGGER.info("receive thread exit");
        }
    }
}
