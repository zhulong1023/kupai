package com.kupai.gateway.connection.client.ws;

import java.io.BufferedReader;
import java.io.Console;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;

public class ConsoleHandler {
    private final Console console = System.console();
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    private final ClientSessions clientSessions;
    private Map<String, ConsoleCommand> cmds = new TreeMap<>();

    abstract class ConsoleCommand {
        abstract void exec(String param) throws Exception;
    }


    public ConsoleHandler(ClientSessions clientSessions) {
        this.clientSessions = clientSessions;

        cmds.put("help", new ConsoleCommand() {
            @Override
            void exec(String param) {
                final Set<String> k = cmds.keySet();
                for (String s : k) {
                    System.out.println(s);
                }
            }
        });
        cmds.put("exit", new ConsoleCommand() {
            @Override
            void exec(String param) throws InterruptedException {
                clientSessions.sendAll(new CloseWebSocketFrame());
            }
        });
        cmds.put("ping", new ConsoleCommand() {
            @Override
            void exec(String parm) {
                ByteBuf buf = Unpooled.buffer(Long.BYTES);
                buf.setLong(0, System.currentTimeMillis());
                clientSessions.sendAll(new PingWebSocketFrame(buf));
            }
        });
        cmds.put("talk", new ConsoleCommand() {
            @Override
            void exec(String parm) {
                clientSessions.requestAll(0, parm);
            }
        });
        cmds.put("enter", new ConsoleCommand() {
            @Override
            void exec(String parm) {
                clientSessions.requestAll(1);
            }
        });
        cmds.put("leave", new ConsoleCommand() {
            @Override
            void exec(String parm) {
                clientSessions.requestAll(2);
            }
        });
        cmds.put("count", new ConsoleCommand() {
            @Override
            void exec(String parm) {
                System.out.println("session count=" + clientSessions.size() +
                    " message recv=" + CommandHelper.messageCount());
            }
        });
    }

    public boolean process() throws Exception {

        String msg = br.readLine();
        if (!msg.isEmpty()) {
            return handle(msg);
        }
        return true;
    }

    public void sendText(String text) {
        System.out.println("send:" + text);
        clientSessions.request(text, (code, object) -> {
            if (code != 0) {
                System.out.println("timeout");
            }
        });
    }

    private boolean handle(String cmd) {
        String param = "";
        int index = cmd.indexOf(':');
        if (index != -1) {
            param = cmd.substring(index + 1);
            cmd = cmd.substring(0, index);
        }
        if ("quit".equalsIgnoreCase(cmd)) {
            return false;
        }
        ConsoleCommand c = cmds.get(cmd);
        if (c != null) {
            try {
                c.exec(param);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("unknown " + cmd);
        }
        return true;
    }
}
