package com.kupai.gateway.connection.client.nio;

import java.nio.channels.SocketChannel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kupai.gateway.common.contants.MessageType;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.connection.protocol.Command;

/**
 * Date: 17/1/10
 * Time: 上午7:47
 *
 * @author lintc
 */
public class WebSocketProcessor implements IPacketProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(WebSocketProcessor.class);
    private AuthCommandProcessor authCommandProcessor;

    public WebSocketProcessor(AuthCommandProcessor authCommandProcessor){
        this.authCommandProcessor = authCommandProcessor;
    }


    @Override
    public void process(Command command) {
        //request/response,只需要第0位的值来判断是否为请求还是响应
        int remoteType = command.getType();
        if (MessageType.RESPONSE.getType() == remoteType) {
            doProcessResponse(command);
        }else if(MessageType.REQUEST.getType()==remoteType){
            doProcessRequest(command);
        }
    }

    @Override
    public void write(SocketChannel channel, Command command) throws Exception {
//        ByteBuffer byteBuffer = command.encode();
//        if(null!=byteBuffer && byteBuffer.remaining()>= Constants.PACKET_MIN_BYTES){
//            channel.write(byteBuffer);
//        }else{
//            LOGGER.warn(String.format("invalid Command %s, channel %s",command,channel));
//        }
    }

    private void doProcessRequest(Command Command){
        int requestCommandCode = Command.getCode();
        switch (requestCommandCode) {
            case RequestCode.HEARTBEAT_PING:
                doProcessHeartBeatPing(Command);
                break;
            default:
                doDefaultRequest(Command);
                break;
        }
    }

    private void doProcessResponse(Command command) {
        int commandCode = command.getCode();
//        switch (commandCode){
//            case ResponseCode.HEARTBEAT_PONG:
//                doProcessHeartBeatPong(command);
//                break;
//            case ResponseCode.AUTH_OK:
//                doProcessAuthOk(command);
//                break;
//            case ResponseCode.AUTH_FAILED:
//                doProcessAuthFailed(command);
//                break;
//            case ResponseCode.KUPAI_BID_TOP_PRICE:
//                doProcessBid(command);
//                break;
////            case ResponseCode.KUPAI_COMMENT_OK:
////                doProcessComment(command);
////                break;
//            default:
//                doDefaultResponse(command);
//                break;
//        }
    }

    private void doProcessHeartBeatPing(Command command){
        LOGGER.info("receive server's ping command, command=" + command);
        try {
//            authCommandProcessor.getWebSocketNioConnection().write(Command.createPongCommand(command.getRequestId()));
        } catch (Exception e) {
            LOGGER.warn("response pong command to server failed, ping_command=" + command, e);
        }
    }


    private void doProcessHeartBeatPong(Command command) {
        LOGGER.info("receive heart beat pong from server, command=" + command);
    }

    private void doProcessAuthFailed(Command command) {
        LOGGER.info("client connect to server auth failed, please check auth content, command=" + command);
    }

    private void doProcessAuthOk(Command command) {
        LOGGER.info("client connect to server auth success, command=" + command);
        //设置bAuth的Flag为true
        authCommandProcessor.updateAuthStatus(true);
    }

    private void doProcessBid(Command command) {
        LOGGER.info("client send the bid command to server has been processed successfully, command=" + command);
    }


    private void doProcessComment(Command command) {
        LOGGER.info("client send the comment command to server has been processed successfully, command=" + command);
    }


    private void doDefaultResponse(Command command) {
        LOGGER.info("unsupported response from server, command=" + command);
    }

    private void doDefaultRequest(Command command){
        LOGGER.info("unsupported request from server, command=" + command);
    }

    @Override
    public void onError() {

    }
}
