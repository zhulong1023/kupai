package com.kupai.gateway.connection.client.ws;

import com.alibaba.fastjson.JSONObject;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;

import java.util.*;
import java.util.concurrent.*;

import static com.kupai.gateway.connection.client.ws.CommandHelper.nextRequestId;

/**
 * Created by wiki2008 on 17/4/19.
 */
public class ClientSessions {

    private ConcurrentHashMap<Long, JsonRequest> requestMap = new ConcurrentHashMap<>();
    private List<Channel> channelList = new CopyOnWriteArrayList<>();
    private Timer timer = new Timer("client-timer");

    static final int REQUEST_TIMEOUT = 10000;
    static final int REQUEST_COUNT = 1;

    private ScheduledExecutorService pingThreadPoolExecutor = Executors
            .newScheduledThreadPool(1);

    private void scheduleTask(Runnable task) {
        pingThreadPoolExecutor.schedule(task, 600, TimeUnit.SECONDS);
    }

    private final class PingTask implements Runnable {
        final Channel ch;

        public PingTask(Channel ch) {
            this.ch = ch;
        }

        @Override
        public void run() {
            try {
                ch.writeAndFlush(new PingWebSocketFrame());
                scheduleTask(new PingTask(ch));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public int size() {
        return channelList.size();
    }


    interface Response {
        void onResponse(int code, JSONObject object);
    }

    class JsonRequest {
        Channel channel;
        String data;
        Response res;
        int requestCount;
        long requestTime;

        public JsonRequest(Channel channel, String data, Response res) {
            this.channel = channel;
            this.data = data;
            this.res = res;
            requestCount = 0;
            this.requestTime = System.currentTimeMillis();
        }

        boolean retry() {
            if (++requestCount > REQUEST_COUNT) {
                return false;
            }
            this.requestTime = System.currentTimeMillis();
            try {
                channel.writeAndFlush(new TextWebSocketFrame(data));
            } catch (Exception e) {
                return false;
            }
            return true;
        }

        boolean timeout() {
            return System.currentTimeMillis() > (requestTime + REQUEST_TIMEOUT);
        }
    }

    public ClientSessions() {
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                processTimeout();
            }
        }, 500, 500);
    }

    public void addChannel(Channel ch) {
        scheduleTask(new PingTask(ch));
        channelList.add(ch);
    }

    public void removeChannel(Channel ch) {
        channelList.remove(ch);
    }

    public void sendAll(WebSocketFrame frame) {
        for (Channel ch : channelList) {
            if (WebSocketClient.VERBOSE_LEVEL == 1) {
                System.out.println("send: " + frame.toString());
            }
            ch.writeAndFlush(frame.copy());
        }
    }

    Response defaultResponse = new Response() {
        @Override
        public void onResponse(int code, JSONObject object) {
            if (code != 0) {
                System.err.println("request error " +
                        (object == null ? "timeout" : object.toJSONString()));
            }
        }
    };

    void requestAll(int type) {
        requestAll(type, "", defaultResponse);
    }

    void requestAll(int type, String data) {
        requestAll(type, data, defaultResponse);
    }

    void requestAll(int type, String data, Response callback) {
        for (Channel ch : channelList) {
            long id = nextRequestId();
            switch (type) {
                case 0:
                    request(ch, CommandHelper.buildMessage(id, data), callback);
                    break;
                case 1:
                    request(ch, CommandHelper.buildRoomOpt(id, true, 1), callback);
                    break;
                case 2:
                    request(ch, CommandHelper.buildRoomOpt(id, false, 1), callback);
                    break;

                default:
                    break;
            }
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    void request(String data, Response callback) {
        Channel channel = channelList.get(new Random(channelList.size()).nextInt());
        request(channel, data, callback);
    }

    void request(int chIndex, String data, Response callback) {
        Channel channel = channelList.get(chIndex);
        request(channel, data, callback);
    }

    void request(Channel channel, String data, Response callback) {
        JSONObject json = JSONObject.parseObject(data);
        request(channel, data, json.getLong("requestId"), callback);
    }

    void request(Channel channel, String data, long id, Response callback) {
        requestMap.put(id, new JsonRequest(channel, data, callback));
        if (WebSocketClient.VERBOSE_LEVEL == 1) {
            System.out.println("send: " + data);
        }
        channel.writeAndFlush(new TextWebSocketFrame(data));
    }

    void processTimeout() {
        try {
            for (Map.Entry<Long, JsonRequest> e : requestMap.entrySet()) {
                final JsonRequest req = e.getValue();
                if (req.timeout()) {
                    if (!req.retry()) {
                        requestMap.remove(e.getKey());
                        if (req.res != null) {
                            req.res.onResponse(1, null);
                        }
                    }
                }
            }
            channelList.stream().filter(ch -> !ch.isActive()).forEach(ch -> {
                channelList.remove(ch);
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void process(Channel ch, String data) {
        try {
            JSONObject json = JSONObject.parseObject(data);
            int code = json.getIntValue("code");
            switch (code) {
                case 301: // 通知拉取消息
                    autoSync(ch, json);
                    break;
                case 12: // 通知进入房间
                    break;
                default: // 处理应答
                    int type = json.getIntValue("type");
                    if (type == 1) {
                        Long id = json.getLong("requestId");
                        if (id != null) {
                            JsonRequest req = requestMap.remove(id);
                            if (req != null) {
                                if (req.res != null) {
                                    req.res.onResponse(0, json);
                                }
                            } else {
                                System.out.println("expired response:" + data);
                            }
                        }
                    }
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void autoSync(Channel ch, JSONObject json) {
        //String messageId = json.getJSONObject("data").getString("messageId");
        request(ch, CommandHelper.buildSync(nextRequestId(), "0"), defaultResponse);

    }

}
