package com.kupai.gateway.connection.client.nio;

import java.net.InetSocketAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.connection.protocol.Command;

/**
 * 基于NIO实现的web socket client
 * <p>
 * 1.采用java.nio.Socket连接 websocket server
 * 2.基于protocol.txt规定的协议,实现数据包解析
 * 3.封装库拍的评论,叫价等上行操作对应的API
 * 4.接收来自库拍后端服务的推送消息(最高价,拍卖开始,拍卖结束,IM评论)
 * 5.支持失败重连
 * 6.实现PING-PONG机制,维持长连接心跳
 * </p>
 * Date: 17/1/9
 * Time: 下午9:37
 *
 * @author lintc
 */
public class WebSocketNioClient {
    private static Logger LOGGER = LoggerFactory.getLogger(WebSocketNioClient.class);
    private WebSocketNioConnection webSocketNioConnection;
    //client是否已经启动
    private volatile boolean bStart = false;

    private String serverAddress;
    private int port;
    private String authContent;

    public WebSocketNioClient(String serverAddress, int port,String authContent ){
        this.serverAddress = serverAddress;
        this.port = port;
        this.authContent =authContent;
    }

    public void start() {
        //1.初始化相关类,并连接到server
        WebSocketPacketHandler packetHandler = new WebSocketPacketHandler();

        webSocketNioConnection = new WebSocketNioConnection(packetHandler,authContent);
        AuthCommandProcessor authCommandProcessor = new AuthCommandProcessor();
        authCommandProcessor.setWebSocketNioConnection(webSocketNioConnection);
        IPacketProcessor packetProcessor = new WebSocketProcessor(authCommandProcessor);
        packetHandler.setProcessor(packetProcessor);

        bStart = webSocketNioConnection.start(new InetSocketAddress(serverAddress, port));
        if (!bStart) {
            LOGGER.warn("start WebSocketNioClient failed ");
        }

        //2..注册shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread("nio-client-shutdown-hook") {
            public void run() {
                webSocketNioConnection.stop();
                bStart = false;
            }
        });
    }


    public boolean comment(String comment) {
        if(!bStart){
            LOGGER.warn("WebSocket Nio Client has not started, comment="+comment);
            return false;
        }

        try {
            Command<String> command = new Command<String>(RequestCode.MSG_TEXT, comment);
            webSocketNioConnection.write(command);
            return true;
        } catch (Exception ex) {
            LOGGER.warn("post comment failed, content=" + comment, ex);
            return false;
        }
    }


    public boolean bid(String bidContent) {
        if (!bStart) {
            LOGGER.warn("WebSocket Nio Client has not started, bid=" + bidContent);
            return false;
        }

        try {
            Command<String> command = new Command<String>(RequestCode.BID, bidContent);
            webSocketNioConnection.write(command);
            return true;
        } catch (Exception ex) {
            LOGGER.warn("post bid price content failed, bid=" + bidContent, ex);
            return false;
        }
    }
}
