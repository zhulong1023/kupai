package com.kupai.gateway.connection.client.nio;

import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.data.DataMeta;
import com.kupai.gateway.common.data.Text;
import com.kupai.gateway.connection.protocol.Command;

/**
 * Created by Administrator on 2017/3/28.
 */
public class ChatText {
    public static void main(String[] args) {
        Command<Text> command = new Command<Text> ();
        Text text = new Text();
        DataMeta dataMeta = new DataMeta();
        text.setContent("sdfasdfadfa");
        text.setMeta(dataMeta);

        dataMeta.setEvent("add");
        dataMeta.setCode(10);
        dataMeta.setExt("{\"nick\":\"测试用户\",\"pic\":\"http://wx.qlogo.cn/mmopen/KkQajzCuoRoftRLo93LCuHYTlCiceaNa2AiaiaQvhSAa6Kco4Tsgog9kf8nlU2LawcXIwlgj5y5qiaeQbp85SVLcNv7QfnsDQMvX/0\",\"uid\":\"4013152291379078\",\"anonymous\":0,\"authStatus\":0,\"type\":1}");
        dataMeta.setFrom(12121212L);
        dataMeta.setTo(121L);

        command.setData(text);
        command.setCode(10);
        command.setRequestId(1L);
        command.setType(0);
        command.setVersion(1);

        System.out.println(JSONObject.toJSON(command));
    }
}
