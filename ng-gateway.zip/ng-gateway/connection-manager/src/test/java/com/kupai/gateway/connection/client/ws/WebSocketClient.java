/*
 * Copyright 2014 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package com.kupai.gateway.connection.client.ws;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.http.DefaultHttpHeaders;
import io.netty.handler.codec.http.HttpClientCodec;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketClientHandshakerFactory;
import io.netty.handler.codec.http.websocketx.WebSocketVersion;
import io.netty.handler.codec.http.websocketx.extensions.compression.WebSocketClientCompressionHandler;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.apache.commons.collections.list.SynchronizedList;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class WebSocketClient {

    public static int VERBOSE_LEVEL = 0;

    public static void main(String[] args) throws Exception {
        int count = 1;
//        URI uri = new URI(args.length > 0 ? args[0] : "ws://10.0.30.60:8186/websocket");
//        URI uri = new URI("ws://192.168.37.147:8181/websocket?x-device-id=xxxxxx");
        URI uri = new URI("ws://10.0.30.60:8186/websocket?x-device-id=xxxxxx");
        if (args.length > 0) {
            count = Integer.parseInt(args[0]);
            if (args.length > 1) {
                VERBOSE_LEVEL = Integer.parseInt(args[0]);
            }
        }
        String scheme = uri.getScheme() == null ? "ws" : uri.getScheme();
        final String host = uri.getHost() == null ? "127.0.0.1" : uri.getHost();
        final int port;
        if (uri.getPort() == -1) {
            if ("ws".equalsIgnoreCase(scheme)) {
                port = 80;
            } else if ("wss".equalsIgnoreCase(scheme)) {
                port = 443;
            } else {
                port = -1;
            }
        } else {
            port = uri.getPort();
        }
        final boolean ssl = "wss".equalsIgnoreCase(scheme);
        final SslContext sslCtx;
        if (ssl) {
            sslCtx = SslContextBuilder.forClient()
                    .trustManager(InsecureTrustManagerFactory.INSTANCE).build();
        } else {
            sslCtx = null;
        }

        EventLoopGroup group = new NioEventLoopGroup();
        try {
            System.out.println("connect to " + uri);

            ClientSessions clientSessions = new ClientSessions();

            Bootstrap b = new Bootstrap();
            b.group(group)
                    .channel(NioSocketChannel.class)
                    .handler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel ch) {
                            final HttpHeaders header = new DefaultHttpHeaders();
                            header.add("origin", uri.toString());
                            header.add("x-device-id", ch.toString());
                            final WebSocketClientHandler handler =
                                    new WebSocketClientHandler(clientSessions, WebSocketClientHandshakerFactory.newHandshaker(
                                            uri, WebSocketVersion.V08, null, true, header));

                            ChannelPipeline p = ch.pipeline();
                            if (sslCtx != null) {
                                p.addLast(sslCtx.newHandler(ch.alloc(), host, port));
                            }
                            p.addLast(
                                    new HttpClientCodec(),
                                    new HttpObjectAggregator(4096),
                                    WebSocketClientCompressionHandler.INSTANCE,
                                    handler);
                        }
                    });


            for (int i = 0; i < count; i++) {
                b.connect(uri.getHost(), port).addListener(new ChannelFutureListener() {
                    @Override
                    public void operationComplete(ChannelFuture future) throws Exception {
                        if (future.isSuccess()) {
                            Channel ch = future.channel();
                            System.out.println("connected channel " + ch);
                        }
                    }
                });
                Thread.sleep(5);
            }
            
            Thread consoleReader = new Thread("consoleReader"){
                
                public void run() {
                    ConsoleHandler console = new ConsoleHandler(clientSessions);
                    try {
                        while (console.process()) {
                            ;
                        }
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
                
            };
            consoleReader.start();
            consoleReader.join();
            System.out.println("stop");
        } finally {
            group.shutdownGracefully();
        }
    }
    
}