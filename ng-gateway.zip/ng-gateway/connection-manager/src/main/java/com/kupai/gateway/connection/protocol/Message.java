/**
 * 
 */
package com.kupai.gateway.connection.protocol;

import com.kupai.gateway.common.contants.MessageType;

/**
 * @author zhouqisheng
 * 2017年3月25日
 */
public class Message<T> {
    private Long requestId;
    private int version;
    private T data;
    private int code;
    private int source;
    private boolean oneway;
    private int type;
    
    public static<T> Message<T> createResponseCommand(int code, long requestId) {
        Message<T> msg = new Message<T>();
        msg.setCode(code);
        msg.setRequestId(requestId);
        return msg;
    }
    
    public MessageType getType() {
        if (this.type == MessageType.RESPONSE.getType()) {
            return MessageType.RESPONSE;
        }
        return MessageType.REQUEST;
    }
    
    public void markResponseType() {
        this.type = MessageType.RESPONSE.getType();
    }
    @Override
    public String toString() {
        return "Message [requestId=" + requestId + ", version=" + version + ", code=" + code + ", source=" + source
                + ", oneway=" + oneway + ", type=" + type + "]";
    }
    
    
    public Long getRequestId() {
        return requestId;
    }
    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }
    public int getVersion() {
        return version;
    }
    public void setVersion(int version) {
        this.version = version;
    }
    public T getData() {
        return data;
    }
    public void setData(T data) {
        this.data = data;
    }
    public int getCode() {
        return code;
    }
    public void setCode(int code) {
        this.code = code;
    }
    public int getSource() {
        return source;
    }
    public void setSource(int source) {
        this.source = source;
    }
    
    public boolean isOneway() {
        return oneway;
    }
    public void setOneway(boolean oneway) {
        this.oneway = oneway;
    }
    public void setType(int type) {
        this.type = type;
    }
    
}
