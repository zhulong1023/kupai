package com.kupai.gateway.connection.domain;

import java.util.Map;

import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.remoting.RemotingProcessor;
import com.kupai.gateway.connection.util.Constants;

import io.netty.channel.Channel;
import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;
import io.netty.util.Attribute;

/**
 * Date: 16/11/14
 * Time: 下午8:17
 *
 * @author lintc
 */
public class Session implements Comparable<Session>{
    /**
     * 用户uid
     */
    private Long uid;
    
    private String name;
    
    private Object ext; 

    /**
     * 连接建立时间
     */
    private Long connectionCreatedTime;

    /**
     * 客户端连接
     */
    private Channel clientChannel;

    /**
     * 用户所拥有的角色 默认为普通用户角色
     */
    private Short role = RoleEnum.normal.getRole();

    /**
     * 会话来源
     */
    private Integer source;

    /**
     * 协议类型  tcp ws
     */
    private Integer protocolType;

    /**
     * 终端类型 example 库拍 开放平台....
     */
    private Integer clientType;
    
    private RemotingProcessor remotingProcessor;

    /**
     * app运行状态 前台运行 ,后台运行
     */
    private Integer appState;
    /**
     * 网络延时
     */
    private long delay;

    /**
     * 扩展属性
     */
    private Map<String, Object> attribute;
    

    public Session() {
        super();
    }

    public Session(Long uid, Channel clientChannel, Integer source) {
        super();
        this.uid = uid;
        this.clientChannel = clientChannel;
        this.source = source;
        this.connectionCreatedTime = System.currentTimeMillis();
    }
    
    /**
     * 关闭会话
     * @param option 
     *               0-timeout 1-login conflict
     */
    public void close(int option){
        if(option == 1){
            Command<String> response = Command.buildResponse(ResponseCode.AUTH_UNIQUE_CONFLICT, ResponseMessage.LOGIN_CONLICT, System.currentTimeMillis(), 0);
            this.clientChannel.writeAndFlush(response);
        }
        this.clientChannel.close();
    }

    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    public Channel getClientChannel() {
        return clientChannel;
    }

    public void setClientChannel(Channel clientChannel) {
        this.clientChannel = clientChannel;
    }

    public Long getConnectionCreatedTime() {
        return connectionCreatedTime;
    }

    public void setConnectionCreatedTime(Long connectionCreatedTime) {
        this.connectionCreatedTime = connectionCreatedTime;
    }


    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public Short getRole() {
        return role;
    }

    public void setRole(Short role) {
        this.role = role;
    }

    public Integer getProtocolType() {
        return protocolType;
    }

    public void setProtocolType(Integer protocolType) {
        this.protocolType = protocolType;
    }

    public Integer getClientType() {
        return clientType;
    }

    public void setClientType(Integer clientType) {
        this.clientType = clientType;
    }

    public RemotingProcessor getRemotingProcessor() {
        return remotingProcessor;
    }

    public void setRemotingProcessor(RemotingProcessor remotingProcessor) {
        this.remotingProcessor = remotingProcessor;
    }

    public Map<String, Object> getAttribute() {
        return attribute;
    }

    public void setAttribute(Map<String, Object> attribute) {
        this.attribute = attribute;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getExt() {
        return ext;
    }

    public void setExt(Object ext) {
        this.ext = ext;
    }

    public Integer getAppState() {
        return appState;
    }

    public void setAppState(Integer appState) {
        this.appState = appState;
    }

    public long getDelay() {
        return delay;
    }

    public void setDelay(long delay) {
        this.delay = delay;
    }

    @Override
    public String toString() {
        return "Session [uid=" + uid + ", name=" + name + ", connectionCreatedTime=" + connectionCreatedTime
                + ", lastActiveTime=" + clientChannel.attr(Constants.LAST_ACTIVE_TIME_ATTR_KEY).get()
                + ", ip=" + clientChannel.attr(Constants.CLIENT_IP).get() == null ?  clientChannel.remoteAddress().toString() : clientChannel.attr(Constants.CLIENT_IP).get()
                + ", role=" + role
                + ", source=" + source + ", protocolType=" + protocolType + ", clientType=" + clientType + ", appState="
                + appState + ", delay=" + delay + "]";
    }
    
    public long getLastActiveTime() {
       return clientChannel.attr(Constants.LAST_ACTIVE_TIME_ATTR_KEY).get();
    }

    public boolean isOpen() {
        return clientChannel != null && clientChannel.isOpen();
    }

    public boolean isActive() {
        return clientChannel != null && clientChannel.isActive();
    }

    private long lastPingTime = 0;
    public void onTimePing() {
        if (protocolType == ProtocolType.WS.getType()) {
            WebSocketFrame ping = new PingWebSocketFrame();
            clientChannel.writeAndFlush(ping);
            lastPingTime = System.currentTimeMillis();
        } else if (protocolType == ProtocolType.TCP.getType()) {
            // TODO implement
        }
    }
    
    public void onPongEvent(){
        long now = System.currentTimeMillis();
        this.delay = now - lastPingTime;
    }

    /**
     * 获取唯一的请求id
     * @param requestId
     * @return
     */
    public String getUniqueRequestId(long requestId) {
        return "client-" + requestId + "-" + uid;
    }

    /**
     * 角色枚举类
     */
    public enum RoleEnum {
        normal((short) 1, "普通用户"),    //普通用户
        programme((short) 2, "主持人"), //主持人
        unknown((short) 0, "非定义类型");

        private final short role;
        private final String desc;

        RoleEnum(short role, String desc) {
            this.role = role;
            this.desc = desc;
        }

        public short getRole() {
            return role;
        }

        public String getDesc() {
            return desc;
        }

        public static RoleEnum valueOf(final short role) {
            for (RoleEnum t : RoleEnum.values()) {
                if (role == t.role)
                    return t;
            }
            return unknown;
        }
    }

    public static enum AppStateEnum {

        foreground(0,"前台运行"),
        background(1,"后台运行");

        private int val;
        private String desc;

        AppStateEnum(int val,String desc){
            this.val = val;
            this.desc = desc;
        }

        public int getVal() {
            return val;
        }

        public String getDesc() {
            return desc;
        }

        public static AppStateEnum parse(int val){
            switch (val){
                case 0:
                    return foreground;
                case 1:
                    return background;
                default:
                    return null;
            }
        }
    }

    @Override
    public int compareTo(Session o) {
        return this.clientChannel.compareTo(o.clientChannel);
    }
}
