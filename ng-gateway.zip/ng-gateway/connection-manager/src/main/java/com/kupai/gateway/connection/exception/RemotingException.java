package com.kupai.gateway.connection.exception;

/**
 * Date: 16/12/25
 * Time: 下午1:56
 *
 * @author lintc
 */
public class RemotingException extends RuntimeException {
    private static final long serialVersionUID = -5690687334570505110L;

    public RemotingException(String message) {
        super(message);
    }

    public RemotingException(String message, Throwable cause) {
        super(message, cause);
    }
}