/**
 * 
 */
package com.kupai.gateway.connection.remoting;

import java.util.concurrent.ExecutorService;

import com.kupai.gateway.connection.protocol.Command;

import io.netty.channel.ChannelHandlerContext;

/**
 * @author zhouqisheng
 *
 *
 * 2017年3月22日
 */
public interface RemotingProcessor extends RemotingServer{
    
    public void processRequestCommand(RemotingProcessor remotingProcessor, ChannelHandlerContext ctx, Command<?> cmd);
    
    public void processResponseCommand(RemotingProcessor remotingProcessor, ChannelHandlerContext ctx, Command<?> cmd);
    
    public void processMessageReceived(RemotingProcessor remotingProcessor, ChannelHandlerContext ctx, Command<?> cmd) throws Exception;
    
    public void registerProcessor(int requestCode, RequestProcessor processor, ExecutorService executor);

    public void registerDefaultProcessor(RequestProcessor processor, ExecutorService executor);
    
}
