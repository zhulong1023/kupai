package com.kupai.gateway.connection.protocol;

/**
 * Date: 16/12/25
 * Time: 下午1:45
 *
 * @author lintc
 */
public enum CompressType {
    NONE(0),
    GZIP(1),
    QUICK_LZ(2),
    ZLIB(3);
    private int type;

    CompressType(int type) {
        this.type = type;
    }

    public int getType() {
        return this.type;
    }

    public static CompressType getCompressType(int type) {
        switch (type) {
            case 0:
                return NONE;
            case 1:
                return GZIP;
            case 2:
                return QUICK_LZ;
            case 3:
                return ZLIB;
            default:
                return NONE;
        }
    }
}
