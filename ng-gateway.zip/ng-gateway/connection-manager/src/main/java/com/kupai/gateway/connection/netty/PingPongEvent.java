/**
 * 
 */
package com.kupai.gateway.connection.netty;

/**
 * @author zhouqisheng 2017年4月12日
 */
public class PingPongEvent {
    public final static PingPongEvent PING = new PingPongEvent(0);
    public final static PingPongEvent PONG = new PingPongEvent(1);

    private int value;

    public PingPongEvent(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "PingPongEvent [value=" + value + "]";
    }

}
