package com.kupai.gateway.connection.netty.handler;

import com.alibaba.fastjson.JSON;
import com.kupai.gateway.connection.domain.ProtocolType;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.remoting.RemotingProcessor;

import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;


/**
 * web socket 消息处理
 * 解析并转换为Command实例
 *
 * @author zhouqisheng
 *         <p>
 *         2017年3月22日
 */
@Sharable
public class WebSocketServerHandler extends SimpleChannelInboundHandler<WebSocketFrame> {
    private RemotingProcessor remotingProcessor;

    public WebSocketServerHandler(RemotingProcessor remotingProcessor) {
        this.remotingProcessor = remotingProcessor;
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, WebSocketFrame frame) throws Exception {
        Command<?> cmd = parseMessage(ctx, frame);
        if (cmd != null) {
            cmd.setProtocolType(ProtocolType.WS.getType());
            remotingProcessor.processMessageReceived(remotingProcessor, ctx, cmd);
        }
    }

    /**
     * 消息转换
     *
     * @param ctx
     * @return
     */
    private Command<?> parseMessage(ChannelHandlerContext ctx, WebSocketFrame frame) {
        if (frame instanceof TextWebSocketFrame) {
            String json = ((TextWebSocketFrame) frame).text();
            @SuppressWarnings("unchecked")
            Command<Object> cmd = JSON.parseObject(json, Command.class);
            return cmd;
        } else {
            throw new UnsupportedOperationException(String.format("%s frame types not supported", frame.getClass().getName()));
        }

       
    }

}
