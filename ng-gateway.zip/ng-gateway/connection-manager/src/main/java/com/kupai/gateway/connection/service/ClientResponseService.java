package com.kupai.gateway.connection.service;

import javax.annotation.Resource;

import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.stereotype.Component;

import com.kupai.gateway.connection.protocol.Command;

/**
 * 重复请求处理
 * Created by shichen on 2017/4/19.
 */
@Component
public class ClientResponseService {

    @Resource(name = "reqAndResCache")
    private CaffeineCache reqAndResCache;

    /**
     * 添加相应
     *
     * @param uniqueRequestId
     * @param response
     * @return
     */
    public boolean addResponse(String uniqueRequestId, Command<?> response) {
        reqAndResCache.put(uniqueRequestId, response);
        return true;
    }

    /**
     * 根据请求id，获取相应数据
     *
     * @param uniqueRequestId 请求id
     * @return
     */
    public Command<?> getResponse(String uniqueRequestId) {
        return (Command<?>) reqAndResCache.getNativeCache().asMap().get(uniqueRequestId);
    }
}
