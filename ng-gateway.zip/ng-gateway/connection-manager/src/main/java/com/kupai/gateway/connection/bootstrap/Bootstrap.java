package com.kupai.gateway.connection.bootstrap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Date: 16/11/13
 * Time: 下午7:55
 *
 * @author lintc
 */
@SpringBootApplication(scanBasePackages = {"com.kupai.gateway"})
@PropertySource(value={"classpath:application.properties", "classpath:application-redis.properties"})
@EnableScheduling
public class Bootstrap {
    public static void main(String[] args) {
        SpringApplication.run(Bootstrap.class, args);
    }
}
