package com.kupai.gateway.connection.util;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 * Date: 16/11/11
 * Time: 下午2:31
 *
 * @author lintc
 */
public class SecurityHelper {
    private static Logger LOGGER = LoggerFactory.getLogger(SecurityHelper.class);
    private static SecretKey aesKey;
    private static String aesKeyStr = "NGQxNmUwMjM4M2Y0MTI2MTM3NDI0Y2MxMjA1N2IyNDM=";
    private static char[] HEXCHAR = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    static {
        initAuth();
    }

    /**
     * 加密
     */
    public static String encrypt(String plainText)
            throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, aesKey);
        return toHexString(cipher.doFinal(plainText.getBytes()));
    }


    /**
     * 解密
     */
    public static String decrypt(String encryptText)
            throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, aesKey);
        byte[] decByte = cipher.doFinal(toBytes(encryptText));
        return new String(decByte);
    }


    private static void initAuth() {
        try {
            aesKey = loadAesKey();
        } catch (Exception e) {
            LOGGER.error("init aes secret key failed", e);
        }
    }

    private static SecretKey loadAesKey()
            throws Exception {
        String buffer = new String(Base64.decodeBase64(aesKeyStr));
        byte[] keyStr = toBytes(buffer);
        return new SecretKeySpec(keyStr, "AES");
    }


    public static String toHexString(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (int i = 0; i < b.length; i++) {
            sb.append(HEXCHAR[(b[i] & 0xf0) >>> 4]);
            sb.append(HEXCHAR[b[i] & 0x0f]);
        }
        return sb.toString();
    }

    private static byte[] toBytes(String s) {
        byte[] bytes;
        bytes = new byte[s.length() / 2];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        }
        return bytes;
    }
}
