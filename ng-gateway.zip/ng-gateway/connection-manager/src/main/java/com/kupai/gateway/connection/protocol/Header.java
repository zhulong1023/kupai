package com.kupai.gateway.connection.protocol;

/**
 * Date: 16/12/25
 * Time: 下午1:37
 *
 * @author lintc
 */
public class Header {
    /**
     * the identifier of the request.
     * When the server response this request,the server should use the requestId to fill up this field.
     */
    private long requestId;

    private int version;
    private int languageCode;
    /**
     * the remote communication type and whether is one way
     */
    private int remotingType;
    private int encrypt;
    private int compress;
    private int serializable;
    //0 is RPC, 1 is one way
    public static final int RPC_ONEWAY=1;

    /**
     * the request/response code.
     */
    private int code;
    /**
     * the message source
     */
    private int source;
    
    /**
     * 消息优先级
     */
    private int priority;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getRemotingType() {
        return remotingType;
    }

    public void setRemotingType(int remotingType) {
        this.remotingType = remotingType;
    }

    public long getRequestId() {
        return requestId;
    }

    public void setRequestId(long requestId) {
        this.requestId = requestId;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getSerializable() {
        return serializable;
    }

    public void setSerializable(int serializable) {
        this.serializable = serializable;
    }

    public int getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(int languageCode) {
        this.languageCode = languageCode;
    }

    public int getEncrypt() {
        return encrypt;
    }

    public void setEncrypt(int encrypt) {
        this.encrypt = encrypt;
    }

    public int getCompress() {
        return compress;
    }

    public void setCompress(int compress) {
        this.compress = compress;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    @Override
    public String toString() {
        return "Header [requestId=" + requestId + ", version=" + version + ", languageCode=" + languageCode
                + ", remotingType=" + remotingType + ", encrypt=" + encrypt + ", compress=" + compress
                + ", serializable=" + serializable + ", code=" + code + ", source=" + source + ", priority=" + priority
                + "]";
    }

}
