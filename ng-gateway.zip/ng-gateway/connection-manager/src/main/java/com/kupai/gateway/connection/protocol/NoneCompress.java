package com.kupai.gateway.connection.protocol;

/**
 * Date: 17/1/1
 * Time: 上午10:05
 *
 * @author lintc
 */
public class NoneCompress implements Compress {
    @Override
    public byte[] compress(byte[] source) {

        return source;
    }

    @Override
    public byte[] decompress(byte[] source) {
        return source;
    }
}
