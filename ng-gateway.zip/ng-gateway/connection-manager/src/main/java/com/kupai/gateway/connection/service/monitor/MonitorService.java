package com.kupai.gateway.connection.service.monitor;

import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.connection.service.session.SessionService;

/**
 * 服务内部运行状态监控服务类
 * <p>
 * 1. 监控JVM运行状态(内存,CPU使用率等)
 * 2. 统计每个拍卖间的连接数,在线时长等
 * 3. 统计消息发送量以及接受量
 * </p>
 * Date: 16/11/22
 * Time: 下午5:15
 *
 * @author lintc
 */

@Service("monitorService")
public class MonitorService {
    private static final Logger LOGGER = LoggerFactory.getLogger(MonitorService.class);

    @Autowired
    private SessionService sessionService;

    /**
     * IM服务器的消息计数器
     */
    private AtomicLong imMessageCounter = new AtomicLong(0);

    /**
     * 网关推送的消息计数器
     */
    private AtomicLong pushMessageCounter = new AtomicLong(0);

    /**
     * 接收来自其他集群广播的消息计数器
     */
    private AtomicLong jgroupReceiveMessageCounter = new AtomicLong(0);


    /**
     * 向其他集群发送的消息计数器
     */
    private AtomicLong jgroupSendMessageCounter = new AtomicLong(0);


    /**
     * 统计所有连接情况
     */
    public String getOnlineCountForAll() {
        /**
         *[{"saleId":123,"onlineCount":23}]
         */
//        Map<Long, List<Session>> userSessionMap = sessionService.getUserSessionMap();
//        if (null != userSessionMap && !userSessionMap.isEmpty()) {
//            //房间链接统计集合
//            JSONArray salesJsonArray = new JSONArray();
//            for (Map.Entry<Long, List<Session>> entry : userSessionMap.entrySet()) {
//                int userCount = userSessionMap.size();
//                //每个房间的链接统计JSONObject
//                JSONObject saleJsonObject = new JSONObject();
//                saleJsonObject.put("onlineCount", userCount);
//                salesJsonArray.add(saleJsonObject);
//            }
//            return salesJsonArray.toJSONString();
//        } else {
//            return "[]";
//        }
        return null;
    }


   public void incrementImMessage() {
        imMessageCounter.incrementAndGet();
    }

    public void incrementPushMessage() {
        pushMessageCounter.incrementAndGet();
    }

    public void incrementJgroupSendMessage() {
        jgroupSendMessageCounter.incrementAndGet();
    }

    public void incrementJgroupReceiveMessage() {
        jgroupReceiveMessageCounter.incrementAndGet();
    }


    public String statisticsMessageCounter() {
       JSONArray counterArray = new JSONArray();
        JSONObject imMessageJsonObject = new JSONObject();
        imMessageJsonObject.put("type", "imMessage");
        imMessageJsonObject.put("counter", imMessageCounter.get());
        counterArray.add(imMessageJsonObject);

        JSONObject pushMessageJsonObject = new JSONObject();
        pushMessageJsonObject.put("type", "pushMessage");
        pushMessageJsonObject.put("counter", pushMessageCounter.get());
        counterArray.add(pushMessageJsonObject);

        JSONObject jgroupSendMessageJsonObject = new JSONObject();
        jgroupSendMessageJsonObject.put("type", "jgroupSendMessage");
        jgroupSendMessageJsonObject.put("counter", jgroupSendMessageCounter.get());
        counterArray.add(jgroupSendMessageJsonObject);

        JSONObject jgroupReceiveMessageJsonObject = new JSONObject();
        jgroupReceiveMessageJsonObject.put("type", "jgroupReceiveMessage");
        jgroupReceiveMessageJsonObject.put("counter", jgroupReceiveMessageCounter.get());
        counterArray.add(jgroupReceiveMessageJsonObject);

        return counterArray.toJSONString();
    }

    /**
     * 每隔五分钟打印一次系统的消息状态信息
     */
    @Scheduled(initialDelay = 60 * 1000l, fixedDelay = 5 * 60 * 1000l)
    public void displayMessageCounter() {
        LOGGER.info(String.format("[message-counter] details=%s", statisticsMessageCounter()));
    }
}
