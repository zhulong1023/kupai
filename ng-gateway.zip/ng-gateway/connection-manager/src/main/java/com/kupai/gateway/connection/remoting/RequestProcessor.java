package com.kupai.gateway.connection.remoting;

import com.kupai.gateway.connection.protocol.Command;

import io.netty.channel.ChannelHandlerContext;

/**
 * Date: 16/12/25 Time: 下午3:14
 *
 * @author lintc
 */
public interface RequestProcessor {
    /**
     * 处理请求
     * @param remotingProcessor
     * @param ctx
     * @param request
     * @return
     * @throws Exception
     */
    public Command<?> processRequest(RemotingProcessor remotingProcessor, ChannelHandlerContext ctx, Command<?> request) throws Exception;
}
