/**
 * 
 */
package com.kupai.gateway.connection.netty.handler;

import com.alibaba.fastjson.JSON;
import com.kupai.gateway.connection.domain.ProtocolType;
import com.kupai.gateway.connection.protocol.BinaryMessage;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.remoting.RemotingProcessor;
import com.kupai.gateway.connection.util.Constants;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

/**
 * @author zhouqisheng
 * 2017年3月25日
 */
public class NettyServerHandler extends SimpleChannelInboundHandler<BinaryMessage>{

    private RemotingProcessor remotingProcessor;
    
    public NettyServerHandler(RemotingProcessor remotingProcessor) {
        super();
        this.remotingProcessor = remotingProcessor;
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, BinaryMessage msg) throws Exception {
        Command<Object> cmd = new Command<Object>(msg.getRequestId(), msg.getCode(), msg.getType().getType());
        cmd.setData(JSON.parseObject(new String(msg.getBody(), Constants.DEFAULT_ENCODING)));
        cmd.setOneway(msg.isOnewayRPC() ? 1 : 0);
        cmd.setVersion(msg.getHeader().getVersion());
        cmd.setProtocolType(ProtocolType.TCP.getType());
        cmd.setPriority(msg.getHeader().getPriority());
        remotingProcessor.processMessageReceived(remotingProcessor, ctx, cmd);
    }

}
