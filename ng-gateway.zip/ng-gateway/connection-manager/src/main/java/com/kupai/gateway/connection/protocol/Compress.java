package com.kupai.gateway.connection.protocol;

/**
 * Date: 16/12/25
 * Time: 下午1:53
 *
 * @author lintc
 */
public interface Compress {
    byte[] compress(byte[] source);
    byte[] decompress(byte[] source);
}
