package com.kupai.gateway.connection.remoting;

/**
 * Date: 17/1/1
 * Time: 下午1:43
 *
 * @author lintc
 */
public interface ConnectionStateListener {
    void reconnected();
}
