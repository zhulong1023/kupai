package com.kupai.gateway.connection.server.callback;

import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.remoting.InvokeCallback;
import com.kupai.gateway.connection.remoting.ResponseFuture;
import io.netty.channel.ChannelHandlerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * netty server端的默认异步回调call back实现类
 * Date: 17/1/14
 * Time: 下午5:50
 *
 * @author lintc
 */
@Service("defaultInvokeCallBack")
public class DefaultInvokeCallBackImpl implements InvokeCallback {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultInvokeCallBackImpl.class);

    @Override
    public void operationComplete(ResponseFuture responseFuture, ChannelHandlerContext ctx) {
        Command<?> command = responseFuture.getResponseCommand();
        LOGGER.info(String.format("async invoke callback, response_command=%s,isTimeOut=%s, isSendRequestOk=%s",
                command, responseFuture.isTimeout(), responseFuture.isSendRequestOK()));
    }
}
