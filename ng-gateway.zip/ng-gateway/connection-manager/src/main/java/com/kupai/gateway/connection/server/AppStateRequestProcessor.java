package com.kupai.gateway.connection.server;

import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.contants.MessageType;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.common.util.StringUtils;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.remoting.RemotingProcessor;
import com.kupai.gateway.connection.remoting.RequestProcessor;
import com.kupai.gateway.connection.service.session.SessionService;
import io.netty.channel.ChannelHandlerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by zhulong on 2017/4/13.
 * 前后台运行
 */
@Component("appStateRequestProcessor")
public class AppStateRequestProcessor implements RequestProcessor {

    private Logger log = LoggerFactory.getLogger(getClass());

    @Autowired
    private SessionService sessionService;

    @Override
    public Command<?> processRequest(RemotingProcessor remotingProcessor, ChannelHandlerContext ctx, Command<?> request) throws Exception {

        try {
            com.kupai.gateway.common.data.Command cmd = ((JSONObject) request.getData()).toJavaObject(com.kupai.gateway.common.data.Command.class);
            Command<String> response=null;
            Session session = sessionService.getSessionByChannel(ctx.channel());
            if(session == null){
                response = new Command<String>(request.getRequestId(), ResponseCode.APP_STATE_FAILED, MessageType.RESPONSE.getType());
                response.setData(ResponseMessage.NOT_LOGIN);
                return response;
            }
            response = new Command<String>(request.getRequestId(), ResponseCode.APP_STATE_OK, MessageType.RESPONSE.getType());
            if(StringUtils.isNotBlank(cmd.getMeta().getEvent())) {
                if ("foreground".equals(cmd.getMeta().getEvent())) {
                    //前台运行
                    Session.AppStateEnum app = Session.AppStateEnum.parse(0);
                    session.setAppState(app.getVal());
                    response.setData(ResponseMessage.APP_STATE_FOREGROUND);
                } else if("background".equals(cmd.getMeta().getEvent())){
                    //后台运行
                    Session.AppStateEnum app = Session.AppStateEnum.parse(1);
                    session.setAppState(app.getVal());
                    response.setData(ResponseMessage.APP_STATE_BACKGROUND);
                }else{
                    //...
                }
            }
        }catch (Exception e){
            log.error("process message error and the code is {}" , request.getCode(), e);
            Command<String> response = new Command<String>(request.getRequestId(), ResponseCode.APP_STATE_FAILED, MessageType.RESPONSE.getType());
            response.setData(ResponseMessage.SYSTEM_ERROR);
            return response;
        }
        return null;
    }
}
