package com.kupai.gateway.connection.security;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.security.KeyStore;

/**
 * Date: 16/12/18
 * Time: 下午3:05
 *
 * @author lintc
 */
public class SslContextFactory {
    private static final String PROTOCOL = "TLS";
    private static final SSLContext SERVER_CONTEXT;
//    private static final SSLContext CLIENT_CONTEXT;
//
//    private static String CLIENT_KEY_STORE = "/Users/ltc/Documents/ssl/websocket_client.jks";
//    private static String CLIENT_KEY_STORE_PASSWORD = "123456";

    private static String SERVER_KEY_STORE = "server.keystore";
    private static String SERVER_KEY_STORE_PASSWORD = "111111";

    static {
        String algorithm = System.getProperty("ssl.KeyManagerFactory.algorithm", "SunX509");
        if (algorithm == null) {
            algorithm = "SunX509";
        }

        SSLContext serverContext;
        SSLContext clientContext;
        try {
            //server key store
            KeyStore serverKeyStore = KeyStore.getInstance("JKS");
            serverKeyStore.load(SslContextFactory.class.getClassLoader().getResourceAsStream(SERVER_KEY_STORE), SERVER_KEY_STORE_PASSWORD.toCharArray());
            KeyManagerFactory serverKeyManagerFactory = KeyManagerFactory.getInstance(algorithm);
            serverKeyManagerFactory.init(serverKeyStore, SERVER_KEY_STORE_PASSWORD.toCharArray());

            // Initialize the SSLContext to work with our key managers.
            serverContext = SSLContext.getInstance(PROTOCOL);
            //单向认证,服务端不需要验证客户端的合法性,因此TrustManager为空,安全随机数不需要设置,使用JDK默认创建的即可
            serverContext.init(serverKeyManagerFactory.getKeyManagers(), null, null);
        } catch (Exception e) {
            throw new Error("Failed to initialize the server-side SSLContext", e);
        }

//        try {
//            //客户端认证服务端,因此客户端只需要加载存放服务端CA的证书仓库即可
//            KeyStore clientKeyStore = KeyStore.getInstance("JKS");
//            clientKeyStore.load(new FileInputStream(CLIENT_KEY_STORE), CLIENT_KEY_STORE_PASSWORD.toCharArray());
//            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance("SunX509");
//            trustManagerFactory.init(clientKeyStore);
//            clientContext = SSLContext.getInstance(PROTOCOL);
//            clientContext.init(null, trustManagerFactory.getTrustManagers(), null);
//        } catch (Exception e) {
//            throw new Error("Failed to initialize the client-side SSLContext", e);
//        }

        SERVER_CONTEXT = serverContext;
//        CLIENT_CONTEXT = clientContext;
    }

    public static SSLContext getServerContext() {
        return SERVER_CONTEXT;
    }

//    public static SSLContext getClientContext() {
//        return CLIENT_CONTEXT;
//    }

    private SslContextFactory() {
    }
}