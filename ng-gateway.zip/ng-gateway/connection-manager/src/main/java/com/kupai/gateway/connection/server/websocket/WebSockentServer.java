/**
 *
 */
package com.kupai.gateway.connection.server.websocket;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.util.StatisticsLog;
import com.kupai.gateway.common.util.ThreadFactoryImpl;
import com.kupai.gateway.connection.netty.NettyServerConfig;
import com.kupai.gateway.connection.netty.WebSocketRemotingServer;
import com.kupai.gateway.connection.remoting.ChannelEventListener;
import com.kupai.gateway.connection.remoting.RequestProcessor;
import com.kupai.gateway.connection.service.ClientResponseService;
import com.kupai.gateway.connection.service.session.SessionService;
import com.kupai.gateway.connection.util.Constants;

/**
 * @author zhouqisheng
 *         <p>
 *         <p>
 *         2017年3月22日
 */
@Service
public class WebSockentServer{

    @Resource(name = "defaultRequestProcessor")
    private RequestProcessor defaultRequestProcessor;
    @Resource(name = "authRequestProcessor")
    private RequestProcessor authRequestProcessor;
    @Resource(name = "inOutRoomRequestProcessor")
    private RequestProcessor inOutRoomRequestProcessor;
    @Resource(name = "appStateRequestProcessor")
    private RequestProcessor appStateRequestProcessor;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private ClientResponseService clientResponseService;
    
    @Autowired
    private ChannelEventListener nettyChannelEventListener;
    
    @Value("${websocket.protocl.origin}")
    private String origin;
   
    @Value("${netty.websocket.port}")
    private int port;
    
    @Value("${netty.websocket.ssl.port}")
    private int sslPort;

    @PostConstruct
    public void start() {
        NettyServerConfig nettyServerConfig = new NettyServerConfig();
        if (port > 0) {//启动未加密服务
            nettyServerConfig.setListenPort(port);
            WebSocketRemotingServer websocketServer = new WebSocketRemotingServer(nettyServerConfig, nettyChannelEventListener, origin);
            //limit the max queue size of the thread pool
            ExecutorService remoteExecutor = new ThreadPoolExecutor(nettyServerConfig.getServerWorkerThreads(),
                    nettyServerConfig.getServerWorkerThreads(), 0L, TimeUnit.MILLISECONDS,
                    new LinkedBlockingQueue<>(Constants.DEFAULT_MAX_QUEUE_ITEM), new ThreadFactoryImpl("WebSocketServerExecutorThread-"));
            StatisticsLog.registerExecutor("websocket-request-pool", (ThreadPoolExecutor) remoteExecutor);
            
            websocketServer.registerDefaultProcessor(defaultRequestProcessor, remoteExecutor);
            websocketServer.registerProcessor(RequestCode.AUTH, authRequestProcessor, remoteExecutor);
            websocketServer.registerProcessor(RequestCode.ROOM, inOutRoomRequestProcessor, remoteExecutor);
            websocketServer.registerProcessor(RequestCode.APP_STATE, appStateRequestProcessor, remoteExecutor);
            websocketServer.setSessionService(sessionService);
            websocketServer.setClientResponseService(clientResponseService);
            websocketServer.start();
        }
        
        if (sslPort > 0) {//启动ssl服务
            nettyServerConfig.setSslListenPort(sslPort);
            nettyServerConfig.setSslSupport(true);
            WebSocketRemotingServer websocketSSLServer = new WebSocketRemotingServer(nettyServerConfig, nettyChannelEventListener, origin);
            //limit the max queue size of the thread pool
            ExecutorService remoteExecutor = new ThreadPoolExecutor(nettyServerConfig.getServerWorkerThreads(),
                    nettyServerConfig.getServerWorkerThreads(), 0L, TimeUnit.MILLISECONDS,
                    new LinkedBlockingQueue<>(Constants.DEFAULT_MAX_QUEUE_ITEM), new ThreadFactoryImpl("WebSocketSSLServerExecutorThread-"));
            StatisticsLog.registerExecutor("websocketSSL-request-pool", (ThreadPoolExecutor) remoteExecutor);
            
            websocketSSLServer.registerDefaultProcessor(defaultRequestProcessor, remoteExecutor);
            websocketSSLServer.registerProcessor(RequestCode.AUTH, authRequestProcessor, remoteExecutor);
            websocketSSLServer.registerProcessor(RequestCode.ROOM, inOutRoomRequestProcessor, remoteExecutor);
            websocketSSLServer.registerProcessor(RequestCode.APP_STATE, appStateRequestProcessor, remoteExecutor);
            websocketSSLServer.setSessionService(sessionService);
            websocketSSLServer.setClientResponseService(clientResponseService);
            websocketSSLServer.start();
        }
        
    }

}
