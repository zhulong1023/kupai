package com.kupai.gateway.connection.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.remoting.RemotingProcessor;
import com.kupai.gateway.connection.remoting.RequestProcessor;
import com.kupai.gateway.connection.service.MessageDispatchService;
import com.kupai.gateway.connection.service.session.SessionService;

import io.netty.channel.ChannelHandlerContext;

/**
 * 处理来自客户端的上行请求 Date: 16/12/25 Time: 下午7:43
 *
 * @author lintc
 */
@Service("defaultRequestProcessor")
public class DefaultRequestProcessor implements RequestProcessor {
    private Logger log = LoggerFactory.getLogger(DefaultRequestProcessor.class);

    @Autowired
    private SessionService sessionService;
    @Autowired
    private MessageDispatchService messageDispatchService;

    @Override
    public Command<?> processRequest(RemotingProcessor remotingProcessor, ChannelHandlerContext ctx, Command<?> request) {
        try {
            Session session = sessionService.getSessionByChannel(ctx.channel());
            log.info("process request uid={}, msg={}", session == null ? "" : session.getUid(), request);
            if(session == null){
                Command<String> response = Command.buildResponse(ResponseCode.AUTH_FAILED, ResponseMessage.NOT_LOGIN, request.getRequestId(), request.getVersion());
                return response;
            }
            
            JGroupMessage jmsg = new JGroupMessage(JGroupMessage.SendType.P2P.getValue(), request.getCode(), session.getUid(), request.getRequestId());
            jmsg.setData(request.getData());
            jmsg.setSource(session.getSource());
            jmsg.setOneWay(request.isOneway());
            jmsg.setVersion(request.getVersion());
            jmsg.setClientType(session.getClientType());
            messageDispatchService.forwardToRM(sessionService.getSessionByChannel(ctx.channel()), jmsg);
            return null;
        } catch (Exception e) {
           log.error("process message error,msg={}" ,request,  e);
           Command<String> _response = Command.buildResponse(ResponseCode.SYSTEM_ERROR, ResponseMessage.SYSTEM_ERROR, request.getRequestId(), request.getVersion());
           return  _response;
        }
    }
}
