package com.kupai.gateway.connection.util;

import java.util.concurrent.atomic.AtomicLong;

import io.netty.util.AttributeKey;

/**
 * Date: 16/11/9
 * Time: 下午5:57
 *
 * @author lintc
 */
public class Constants {
    //WebSocket资源路径
    public static final String WEBSOCKET_PATH = "/websocket";
    public static final String DEFAULT_ENCODING = "utf-8";
    
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS="yyyy-MM-dd HH:mm:ss";
    public final static String INITIAL_HOSTS_KEY="jgroups.tcpping.initial_hosts";
    public final static String BIND_ADDRESS_KEY="jgroups.bind_addr";
    /**
     * thread counter
     */
    public final static AtomicLong THREAD_ID = new AtomicLong(0);

    public static final String PING_MESSAGE="{\"type\":\"heartbeat\",\"event\":\"ping\",\"body\":{}}";
    public static final String PONG_MESSAGE="{\"type\":\"heartbeat\",\"event\":\"pong\",\"body\":{}}";
    /**
     * 3分钟没有活动则关闭连接
     */
    public static final long MAX_IN_ACTIVE_TIME= 4*60*1000;
    
    /**
     * 等待连接认证时间
     */
    public static final long WAIT_AUTH_TIME_OUT = 5 * 1000;

    public static final int DEFAULT_MAX_QUEUE_ITEM = 1024*1024;
    public static final int DEFAULT_QUEUE_TIMEOUT = 3*1000;

    /**
     * the magic code of the WebSocket header
     */
    public static final short MAGIC_CODE = 0x51BA;
    /**
     * the max length of the packet
     */
    public static final int MAX_PACKET_LENGTH = 1024 * 1024;

    /**
     * the total count byte that the field of header length occupy.
     */
    public static final int HEADER_LENGTH_BYTE_COUNT = 2;

    /**
     * body正文大小超过多少就开启压缩
     */
    public static final int DEFAULT_COMPRESS_LENGTH = 4096;

    /**
     * 报文头最小字节数
     */
    public static final int MIN_PACKET_HEADER_LENGTH = 12;

    /**
     * 报文头最大字节数
     */
    public static final int MAX_PACKET_HEADER_LENGTH = 60;

    /**
     * 报文魔法数字节数
     */
    public static final int PACKET_MAGIC_CODE_BYTES=Short.BYTES;

    /**
     * 报文头部长度的字节数
     */
    public static final int PACKET_HEADER_LENGTH_BYTES=Short.BYTES;
    /**
     * 报文正文长度的字节数
     */
    public static final int PACKET_BODY_LENGTH_BYTES=Integer.BYTES;
    /**
     * 报文最小的字节数
     */
    public static  final int PACKET_MIN_BYTES= Constants.PACKET_MAGIC_CODE_BYTES+Constants.PACKET_HEADER_LENGTH_BYTES
            +Constants.PACKET_BODY_LENGTH_BYTES+Constants.MIN_PACKET_HEADER_LENGTH;


    public static final int DEFAULT_READ_WRITE_LOCK_TIMEOUT = 3000;
    /**
     * the default timeout of socket reading timeout.
     */
    public static final long DEFAULT_SOCKET_READING_TIMEOUT = 2*1000;

    /**
     * the default timeout of socket reading timeout for async request.
     */
    public static final long DEFAULT_ASYNC_SOCKET_READING_TIMEOUT = 1000;
    
    /**
     * 设备id
     */
    public static final String HEAD_DEVICE_ID = "x-device-id";
    
    /**
     * X-Forwarded-For
     */
    public static final String HEAD_X_FORWARDED_FOR = "X-Forwarded-For";
    
    /**
     * 客户端ip
     */
    public static final AttributeKey<String> CLIENT_IP = AttributeKey.valueOf(String.class, "CLIENT_IP");
    
    /**
     * 会话最后活动时间
     */
    public static final AttributeKey<Long> LAST_ACTIVE_TIME_ATTR_KEY = AttributeKey.valueOf(Long.class, "LAST_ACTIVE_TIME");
}
