/**
 * 
 */
package com.kupai.gateway.connection.service.httpClient;

import com.kupai.gateway.connection.server.AuthRequestProcessor.AuthVerifyResult;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.http.Url;

/**
 * @author zhouqisheng
 * 2017年3月29日
 */
public interface AuthVerify {
    @GET
    public Call<AuthVerifyResult> verify(@Url String url, @Query("passport") String passport);

}
