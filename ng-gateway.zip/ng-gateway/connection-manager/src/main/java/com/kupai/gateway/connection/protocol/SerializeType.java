package com.kupai.gateway.connection.protocol;

/**
 * Date: 16/12/25
 * Time: 下午1:43
 *
 * @author lintc
 */
public enum SerializeType {
    JSON(0),
    PROTOCOL_BUFFER(1),
    HESSIAN(2),
    THRIFT(3);
    private int type;

    SerializeType(int type) {
        this.type = type;
    }

    public static SerializeType getSerializeType(int type) {
        switch (type) {
            case 0:
                return JSON;
            case 1:
                return PROTOCOL_BUFFER;
            case 2:
                return HESSIAN;
            case 3:
                return THRIFT;
            default:
                return JSON;
        }
    }

    public int getType() {
        return this.type;
    }
}
