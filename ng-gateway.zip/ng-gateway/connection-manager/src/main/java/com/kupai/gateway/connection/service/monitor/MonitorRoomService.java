package com.kupai.gateway.connection.service.monitor;

import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.util.DateUtils;
import com.kupai.gateway.connection.domain.ProtocolType;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.service.session.SessionRoomService;
import com.kupai.gateway.connection.util.Constants;

/**
 * 用于对房间session进行监控
 * Created by Administrator on 2017/3/25.
 */
@Service
public class MonitorRoomService {

    @Autowired
    private SessionRoomService sessionRoomService;

    /**
     * 获取某一个房间的所有的有效连接
     *
     * @param roomId 房间id
     * @return
     */
    public String getOnlineUsersByRoomId(Long roomId) {
        /**
         *[
         {
         "userId":12,
         "createdTime":1244,
         "onlineTime":1234
         }
         ]
         */
        Map<Long, Map<Long, Set<Session>>> roomSessionMap = sessionRoomService.getRoomSessionMap();
        if (null != roomSessionMap && !roomSessionMap.isEmpty()) {
            for (Map.Entry<Long, Map<Long, Set<Session>>> entry : roomSessionMap.entrySet()) {
                Long key = entry.getKey();
                if (Objects.equals(roomId, key)) {
                    Map<Long, Set<Session>> userSessionMap = entry.getValue();
                    //每个房间的在线用户集合
                    JSONArray userSessionJsonArray = new JSONArray();
                    for (Map.Entry<Long, Set<Session>> sessionEntry : userSessionMap.entrySet()) {
                        //每个房间的某个具体用户的session信息
                        
                        Long userId = sessionEntry.getKey();
                        Set<Session> userSessionList = sessionEntry.getValue();
                        for (Session userSession : userSessionList) {
                            JSONObject sessionJsonObject = new JSONObject();
                            //系统来源
                            sessionJsonObject.put("source", userSession.getSource());
                            //用户ID
                            sessionJsonObject.put("userId", userId);
                            //用户连接创立时间
                            String connectionTime = DateUtils.long2String(userSession.getConnectionCreatedTime(), Constants.DATE_FORMAT_YYYYMMDDHHMMSS);
                            sessionJsonObject.put("createdTime", connectionTime);
                            //用户在线时长(s)
                            sessionJsonObject.put("onlineTime", (System.currentTimeMillis() - userSession.getConnectionCreatedTime()) / 1000);
                            //协议类型
                            sessionJsonObject.put("protocolType", ProtocolType.parser(userSession.getProtocolType().intValue()).getDesc());
                            //clientType
                            sessionJsonObject.put("clientType", userSession.getClientType());
                            //角色
                            sessionJsonObject.put("role", Session.RoleEnum.valueOf(userSession.getRole()).getDesc());
                            userSessionJsonArray.add(sessionJsonObject);
                        }
                       
                    }
                    return userSessionJsonArray.toJSONString();
                }
            }
            return "[]";
        } else {
            return "[]";
        }
    }
}
