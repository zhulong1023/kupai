package com.kupai.gateway.connection.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.remoting.RemotingProcessor;
import com.kupai.gateway.connection.remoting.RequestProcessor;
import com.kupai.gateway.connection.service.MessageDispatchService;
import com.kupai.gateway.connection.service.session.SessionService;

import io.netty.channel.ChannelHandlerContext;

/**
 * Created by zhulong on 2017/3/30.
 * 进出房间
 */
@Component("inOutRoomRequestProcessor")
public class InOutRoomRequestProcessor implements RequestProcessor {

    private Logger log = LoggerFactory.getLogger(getClass());

    @Autowired
    private SessionService sessionService;

    @Autowired
    private MessageDispatchService messageDispatchService;


    @Override
    public Command<?> processRequest(RemotingProcessor remotingProcessor, ChannelHandlerContext ctx, Command<?> request) throws Exception {

        com.kupai.gateway.common.data.Command cmd = ((JSONObject) request.getData()).toJavaObject(com.kupai.gateway.common.data.Command.class);
        Command<String> response = null;
        Long roomid = 1l;
        Object roomId = ((JSONObject) cmd.getContent()).get("roomId");
        if (roomId == null) {
            response = Command.buildResponse(ResponseCode.INOUT_ROOM_FAILED, ResponseMessage.ROOMID_NOT_NULL, request.getRequestId(), request.getVersion());
            return response;
        }
        try {
            roomid = (Long.parseLong(roomId.toString()));
        } catch (NumberFormatException e) {
            log.error("type transform error and the code is {}", request.getCode(), e);
            response = Command.buildResponse(ResponseCode.INOUT_ROOM_FAILED, ResponseMessage.TYPE_CAST_ERROR, request.getRequestId(), request.getVersion());
            return response;
        } catch (ClassCastException e2) {
            log.error("type transform error and the code is {}", request.getCode(), e2);
            response = Command.buildResponse(ResponseCode.INOUT_ROOM_FAILED, ResponseMessage.TYPE_CAST_ERROR, request.getRequestId(), request.getVersion());
            return response;
        }
        Session session = sessionService.getSessionByChannel(ctx.channel());
        if (session == null) {
            response = Command.buildResponse(ResponseCode.AUTH_FAILED, ResponseMessage.NOT_LOGIN, request.getRequestId(), request.getVersion());
            return response;
        }

        try {
            JSONObject content = new JSONObject();
            content.put("uid", session.getUid());
            content.put("roomId", roomid);
            content.put("name", session.getName());
            content.put("ext", session.getExt());
            cmd.getMeta().setFrom(session.getUid());

            com.kupai.gateway.common.data.Command msgcom = new com.kupai.gateway.common.data.Command();
            msgcom.setMeta(cmd.getMeta());
            msgcom.setContent(content);

            JGroupMessage jmsg = new JGroupMessage(JGroupMessage.SendType.P2P.getValue(), request.getCode(), session.getUid(), request.getRequestId());
            jmsg.setFrom(session.getUid());
            jmsg.setData(msgcom);
//                jmsg.setData(request.getData());
            jmsg.setRoomId(roomid);
            jmsg.setSource(session.getSource());
            jmsg.setVersion(request.getVersion());
            jmsg.setClientType(session.getClientType());
            messageDispatchService.forwardToRM(session, jmsg);

            return null;
        } catch (Exception e) {
            log.error("process message error and the code is {}", request.getCode(), e);
            Command<String> _response = Command.buildResponse(ResponseCode.SYSTEM_ERROR, ResponseMessage.SYSTEM_ERROR, request.getRequestId(), request.getVersion());
            return  _response;
        }
    }
}
