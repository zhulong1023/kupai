package com.kupai.gateway.connection.service.session;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.util.Constants;

import io.netty.channel.Channel;

/**
 * 1.存放用户session(uid,token,roomId) 2.存放用户的连接 3.存放每个拍卖间的所有在线用户session Date:
 * 16/11/14 Time: 下午8:16
 *
 * @author lintc
 */

@Service("sessionService")
public class SessionService {
    private Logger log = LoggerFactory.getLogger(SessionService.class);
    @Autowired
    private SessionRoomService sessionRoomService;

    private ScheduledExecutorService pingThreadPoolExecutor = Executors.newScheduledThreadPool(1);

    private final static long pingMaxRTT = 10 * 1000;
    private final static long pingInterval = Constants.MAX_IN_ACTIVE_TIME - pingMaxRTT;

    private void scheduleTask(Runnable task, long tickTime) {
        pingThreadPoolExecutor.schedule(task, tickTime, TimeUnit.MILLISECONDS);
    }

    private final class PingTask implements Runnable {
        final Session session;
        final int timeoutCount;

        public PingTask(Session session) {
            this(session, 0);
        }

        public PingTask(Session session, int timeout) {
            this.session = session;
            this.timeoutCount = timeout;
        }

        @Override
        public void run() {
            try {
                if (session == null || !session.isOpen()) {
                    log.debug("session invalid");
                    return;
                }
                if (session.isActive()) {
                    long lastActiveTime = session.getLastActiveTime();
                    long idleTime = System.currentTimeMillis() - lastActiveTime;
                    long nextTime = pingInterval - idleTime;
                    if (nextTime < 1000) {
                        if (timeoutCount > 0) {
                            log.info("close timeout channel.source {}, userId {}, channel: {}",
                                    session.getSource(), session.getUid(), session.getClientChannel());
                            session.close(0);
                        } else {
                            log.info("on time ping channel.source {}, userId {}, channel: {}",
                                    session.getSource(), session.getUid(), session.getClientChannel());
                            session.onTimePing();
                            scheduleTask(new PingTask(session, timeoutCount + 1), pingMaxRTT);
                        }
                    } else {
                        scheduleTask(new PingTask(session), nextTime);
                    }
                } else {
                    log.info("close inactive channel.source {}, userId {}, channel: {}",
                            session.getSource(), session.getUid(), session.getClientChannel());
                    session.close(0);
                }
            } catch (Exception e) {
                log.error("PingTask", e);
            }
        }
    }

    /**
     * 支持一个用户建立多个连接
     */
    private Map<Integer/* 应用源 */, Map<Long/* 用户uid */, Map<Integer, Session>>> userSessionMap = new ConcurrentHashMap<>();

    /**
     * 根据channel查询session
     */
    private Map<Channel, Session> channelSessionMap = new ConcurrentHashMap<>();

    /**
     * 新建连接未认证列表
     */
    private Map<Channel, Long> channelEvictMap = new ConcurrentHashMap<>();

    /**
     * 角色会话列表
     */
    private Map<Integer/** source */
            , Map<Short/** role */
                    , Set<Session>>> roleSessionMap = new ConcurrentHashMap<>();

    /**
     * 添加session
     *
     * @param session
     */
    public void addSession(Session session) {
        // 获取同一应用源会话
        Map<Long, Map<Integer, Session>> sameSrcSessionMap = userSessionMap.get(session.getSource());
        if (sameSrcSessionMap == null) {
            sameSrcSessionMap = new ConcurrentHashMap<>();
            Map<Long, Map<Integer, Session>> _sameSrcSessionMap = userSessionMap.putIfAbsent(session.getSource(),
                    sameSrcSessionMap);
            if (_sameSrcSessionMap != null) {
                sameSrcSessionMap = _sameSrcSessionMap;
            }
        }

        // 获取同一用户会话
        Map<Integer, Session> userSessionMap = sameSrcSessionMap.get(session.getUid());
        if (userSessionMap == null) {
            userSessionMap = new ConcurrentHashMap<>();
            Map<Integer, Session> _userSessionMap = sameSrcSessionMap.putIfAbsent(session.getUid(), userSessionMap);
            if (_userSessionMap != null) {
                userSessionMap = _userSessionMap;
            }
        }

        // 获取同一类终端会话
        Session sessionOld = userSessionMap.put(session.getClientType(), session);
        // 添加session到channelSessionMap
        channelSessionMap.put(session.getClientChannel(), session);
        // 删除未认证连接
        channelEvictMap.remove(session.getClientChannel());
        // 添加会话到 roleSessionMap
        Map<Short, Set<Session>> sameSrcRoleSessionMap = this.roleSessionMap.get(session.getSource());
        if (sameSrcRoleSessionMap == null) {
            sameSrcRoleSessionMap = new ConcurrentHashMap<>();
            this.roleSessionMap.put(session.getSource(), sameSrcRoleSessionMap);
        }
        Set<Session> sessionSet = sameSrcRoleSessionMap.get(session.getRole());
        if (sessionSet == null) {
            sessionSet = new ConcurrentSkipListSet<>();
            sameSrcRoleSessionMap.put(session.getRole(), sessionSet);
        }
        sessionSet.add(session);

        if (sessionOld != null) {// 关闭原有会话
            sessionOld.close(1);
        }

        scheduleTask(new PingTask(session), pingInterval);
        log.info("add session success! session={}", session);
    }

    /**
     * 移除会话
     * 
     * @param session
     */
    public void removeSession(Session session) {
        // 移除通道会话映射
        channelSessionMap.remove(session.getClientChannel());
        // 移除用户会话映射
        Map<Long, Map<Integer, Session>> srcUserSessionMap = this.userSessionMap.get(session.getSource());
        Map<Integer, Session> userSessionMap = srcUserSessionMap.get(session.getUid());
        if (userSessionMap != null) {
            Session _session = userSessionMap.get(session.getClientType());
            if (_session != null && _session.getClientChannel().equals(session.getClientChannel())) {// 通道相同才认为是同一个session
                userSessionMap.remove(session.getClientType());
                // 移除房间中的会话
                sessionRoomService.removeSessionFromRoom(session);
                // 移除角色会话对应
                Map<Short, Set<Session>> sameSrcRoleSessionMap = this.roleSessionMap.get(session.getSource());
                if (sameSrcRoleSessionMap != null) {
                    Set<Session> sessionSet = sameSrcRoleSessionMap.get(session.getRole());
                    if (sessionSet != null) {
                        sessionSet.remove(session);
                    }
                }
                log.info("remove session success! session={}", session);
            }
            if (userSessionMap.size() == 0) {
                srcUserSessionMap.remove(session.getUid());
            }
        }
    }

    /**
     * 获得某一应用源的在线用户
     * 
     * @param source
     * @return
     */
    public Map<Long, Map<Integer, Session>> getOnlineUsersBySource(int source) {
        Map<Long, Map<Integer, Session>> srcUserSessionMap = this.userSessionMap.get(source);
        if (srcUserSessionMap == null) {
            return Collections.emptyMap();
        }
        return srcUserSessionMap;
    }

    /**
     * 获得在线用户session
     * 
     * @param source
     * @param uid
     * @return
     */
    public Map<Integer, Session> getOnlineUsersByUid(int source, long uid) {
        Map<Long, Map<Integer, Session>> srcUserSessionMap = this.userSessionMap.get(source);
        if (srcUserSessionMap == null) {
            return Collections.emptyMap();
        }

        Map<Integer, Session> userSessionMap = srcUserSessionMap.get(uid);
        if (userSessionMap == null) {
            return Collections.emptyMap();
        }
        return userSessionMap;
    }

    /**
     * 获得在线用户session
     * 
     * @param source
     * @param uid
     * @param clientType
     * @return
     */
    public Session getOnlineUsersByUid(int source, long uid, int clientType) {
        Map<Integer, Session> userSessionMap = this.getOnlineUsersByUid(source, uid);
        if (userSessionMap != null) {
            Session session = userSessionMap.get(clientType);
            if (session != null) {
                return session;
            }
        }
        return null;
    }

    /**
     * 获取某个应用源的整个服务的用户连接情况
     * 
     * @param source
     * @return
     */
    public Map<Long, Map<Integer, Session>> getUserSessionMap(int source) {
        return this.userSessionMap.get(source);
    }

    /**
     * @return
     */
    public Map<Integer, Map<Long, Map<Integer, Session>>> getUserSessionMap() {
        return userSessionMap;
    }

    /**
     * 通过channel获取其对应的session
     *
     * @param channel
     *            通道
     * @return
     */
    public Session getSessionByChannel(Channel channel) {
        return channelSessionMap.get(channel);
    }

    /**
     * 添加未认证连接
     * 
     * @param channel
     */
    public void addNewConnection(Channel channel) {
        this.channelEvictMap.put(channel, System.currentTimeMillis());
    }

    /**
     * 查找同一角色得所有会话
     * 
     * @param source
     * @param role
     * @return
     */
    public Set<Session> getRoleSession(int source, short role) {
        Map<Short, Set<Session>> sameSrcRoleSessionMap = this.roleSessionMap.get(source);
        if (sameSrcRoleSessionMap != null) {
            Set<Session> sessionSet = sameSrcRoleSessionMap.get(role);
            if (sessionSet != null) {
                return sessionSet;
            }
        }
        return Collections.emptySet();
    }

    /**
     * 剔除认证超时连接
     */
    @Scheduled(cron = "*/5 * * * * *")
    public void evictIdleChannel() {
        long now = System.currentTimeMillis();
        List<Channel> evictedChannel = new ArrayList<>();
        for (Entry<Channel, Long> entry : this.channelEvictMap.entrySet()) {
            if (now - entry.getValue() >= Constants.WAIT_AUTH_TIME_OUT) {
                evictedChannel.add(entry.getKey());
            }
        }
        // 关闭认证超时连接
        for (Channel channel : evictedChannel) {
            this.channelEvictMap.remove(channel);

            if (this.channelSessionMap.get(channel) == null) {
                channel.close();
            }
        }
    }

}
