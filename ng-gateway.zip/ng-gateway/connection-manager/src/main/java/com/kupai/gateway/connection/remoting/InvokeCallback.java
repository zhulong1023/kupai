package com.kupai.gateway.connection.remoting;

import io.netty.channel.ChannelHandlerContext;

/**
 * Date: 16/12/25
 * Time: 下午3:10
 *
 * @author lintc
 */
public interface InvokeCallback {
    void operationComplete(final ResponseFuture responseFuture, ChannelHandlerContext ctx);
}
