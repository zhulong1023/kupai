package com.kupai.gateway.connection.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.JGroupsNode;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.remoting.InvokeCallback;
import com.kupai.gateway.connection.service.monitor.MonitorService;

/**
 * 消息分发服务
 * <p>
 * 1. 接收来自客户端的上行请求,解析消息格式并转发给后端服务
 * 2. 接收来自后端服务推送过来的消息(主要是IM消息服务),解析消息并分发给相应的拍卖间的所有连接
 * </p>
 * Date: 16/11/11
 * Time: 下午5:19
 *
 * @author lintc
 */
@Service("messageDispatchService")
public class MessageDispatchService {
    private static Logger LOGGER = LoggerFactory.getLogger(MessageDispatchService.class);

    //防止响应消息处理器
    private static final Map<Integer, InvokeCallback> invokeCallbackHashMap = new HashMap<>();

    @Autowired
    private MonitorService monitorService;
    @Autowired
    private JGroupsNode jgroupsNode;

    @Autowired
    private ClientResponseService clientResponseService;

    /**
     * 注册客户端的响应消息Callback
     *
     * @param requestCode    请求码
     * @param invokeCallback 请求码对应的处理器
     */
    public final static void registerInvokeCallback(int requestCode, InvokeCallback invokeCallback) {
        if (null == invokeCallbackHashMap) {
            return;
        }
        invokeCallbackHashMap.put(requestCode, invokeCallback);
    }


    /**
     * 转发webSocketFrame给rm，除了ping pong消息外，其他都转发到rm进行处理
     *
     * @param session
     */
    public void forwardToRM(Session session, JGroupMessage jmsg) {
        try {
            jgroupsNode.sendMessage(null, jmsg);
            //发送的消息数+1
            monitorService.incrementJgroupSendMessage();
        } catch (Exception e) {
            LOGGER.error(String.format("push jgroups message to cm error,type %s, toUid %s, message %s, error %s",
                    jmsg.getSendType(), jmsg.getToUid(), jmsg.getData(), e), e);
        }
    }

    /**
     * 处理从rm接收到的消息
     */
    public void forwardToClient(Session session, Command<?> msg) {
        if (msg != null) {
            try {
                if (msg.isOneway()) {
                    session.getRemotingProcessor().invokeOneway(session.getClientChannel(), msg, 3000);
                    //将该requestId对应的相应放入到本地缓存中
                    clientResponseService.addResponse(session.getUniqueRequestId(msg.getRequestId()), msg);
                } else {
                    session.getRemotingProcessor().invokeAsync(session.getClientChannel(), msg, 3000, null);
                }
            } catch (Exception e) {
                LOGGER.error("dispatcher msg err, msg:{}", msg, e);
            }
        }
    }

}
