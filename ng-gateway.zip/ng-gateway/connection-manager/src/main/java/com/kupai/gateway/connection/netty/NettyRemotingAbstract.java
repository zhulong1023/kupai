package com.kupai.gateway.connection.netty;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kupai.gateway.common.contants.MessageType;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.exception.RemotingSendRequestException;
import com.kupai.gateway.connection.exception.RemotingTimeoutException;
import com.kupai.gateway.connection.exception.RemotingTooMuchRequestException;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.protocol.Pair;
import com.kupai.gateway.connection.remoting.ChannelEventListener;
import com.kupai.gateway.connection.remoting.InvokeCallback;
import com.kupai.gateway.connection.remoting.RPCHook;
import com.kupai.gateway.connection.remoting.RemotingHelper;
import com.kupai.gateway.connection.remoting.RemotingProcessor;
import com.kupai.gateway.connection.remoting.RequestProcessor;
import com.kupai.gateway.connection.remoting.ResponseFuture;
import com.kupai.gateway.connection.service.ClientResponseService;
import com.kupai.gateway.connection.service.session.SessionService;
import com.kupai.gateway.connection.util.Constants;

import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.util.Attribute;

/**
 * Date: 16/12/25
 * Time: 下午3:17
 *
 * @author lintc
 */
public abstract class NettyRemotingAbstract implements RemotingProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(NettyRemotingAbstract.class);
    protected final String SYSTEM_BUSY_BYTES = "too many requests and system thread pool busy, please try another server";

    // cache all the remote request that is outing
    protected final ConcurrentHashMap<String, ResponseFuture> responseTable = new ConcurrentHashMap<String, ResponseFuture>(256);
    // the default request processor
    protected Pair<RequestProcessor, ExecutorService> defaultRequestProcessor;
    // the request processors
    protected final HashMap<Integer/* request code */, Pair<RequestProcessor, ExecutorService>> processorTable = new HashMap<>(64);

    private SessionService sessionService;

    private ClientResponseService clientResponseService;

    public abstract ChannelEventListener getChannelEventListener();

    public abstract RPCHook getRPCHook();


    @Override
    public void processRequestCommand(final RemotingProcessor remotingProcessor, final ChannelHandlerContext ctx, final Command<?> cmd) {
        final Pair<RequestProcessor, ExecutorService> matched = this.processorTable.get(cmd.getCode());
        final Pair<RequestProcessor, ExecutorService> pair = null == matched ? this.defaultRequestProcessor : matched;
        if (pair != null) {
            Runnable run = new Runnable() {
                @Override
                public void run() {
                    try {
                        RPCHook rpcHook = NettyRemotingAbstract.this.getRPCHook();
                        if (rpcHook != null) {
                            rpcHook.doBeforeRequest(RemotingHelper.parseChannelRemoteAddress(ctx.channel()), cmd);
                        }

                        //定义返回的指令
                        Command<?> response = null;
                        //查看是否能取得对应的请求的回应
                        Session session = sessionService.getSessionByChannel(ctx.channel());
                        if (null != session) {
                            //从本地缓存中获取该requestId对应的回应
                            Command<?> responseCmd = clientResponseService.getResponse(session.getUniqueRequestId(cmd.getRequestId()));
                            if (null != responseCmd) {
                                //能取得，则直接返回
                                response = responseCmd;
                            } else {
                                response = pair.getObject1().processRequest(remotingProcessor, ctx, cmd);
                                if (rpcHook != null) {
                                    rpcHook.doAfterResponse(cmd, response);
                                }
                            }
                        } else {
                            response = pair.getObject1().processRequest(remotingProcessor, ctx, cmd);
                            if (rpcHook != null) {
                                rpcHook.doAfterResponse(cmd, response);
                            }
                        }

                        // ignore the result in one way
                        if (!cmd.isOneway()) {
                            if (response != null) {
                                //set the request id for response
                                response.setRequestId(cmd.getRequestId());
                                response.markResponseType();
                                try {
                                    ctx.writeAndFlush(response);
                                } catch (Throwable e) {
                                    LOGGER.error(String.format("process request %s over, but response %s failed", cmd.toString(), response.toString()), e);
                                }
                            }
                        } else {
                            if (null != response) {
                                invokeOneway(session.getClientChannel(), response, 3000);
                            }
                        }
                    } catch (Throwable e) {
                        LOGGER.error(String.format("process request %s error,exception is ", cmd.toString()), e);
                        if (!cmd.isOneway()) {
//                            final Command<String> response = Command.createResponseCommand(ResponseCode.SYSTEM_ERROR, cmd.getRequestId());
                            final Command<String> response = new Command<String>(ResponseCode.SYSTEM_ERROR, cmd.getRequestId());
                            response.setData(e.getMessage() == null ? "system error" : e.getMessage());
                            ctx.writeAndFlush(response);
                        }
                    }
                }
            };

            try {
                pair.getObject2().submit(run);
            } catch (RejectedExecutionException e) {
                LOGGER.warn(String.format("%s too many requests and system thread pool busy, RejectedExecutionException %s of request code %s",
                        RemotingHelper.parseChannelRemoteAddress(ctx.channel()), pair.getObject2().toString(), cmd.getCode()));
                if (!cmd.isOneway()) {
                    final Command<String> response = new Command<String>(ResponseCode.SYSTEM_BUSY, cmd.getRequestId());
                    response.setData(SYSTEM_BUSY_BYTES);
                    response.setRequestId(cmd.getRequestId());
                    ctx.writeAndFlush(response);
                }
            }
        } else {
            //request is not supported
            String error = "request type " + cmd.getCode() + " not supported";
            LOGGER.error(RemotingHelper.parseChannelRemoteAddress(ctx.channel()) + error);
            final Command<String> response = new Command<String>(ResponseCode.CODE_NOT_SUPPORTED, cmd.getRequestId());
            response.setData(error);
            response.setRequestId(cmd.getRequestId());
            ctx.writeAndFlush(response);
        }
    }

    @Override
    public void processResponseCommand(RemotingProcessor remotingProcessor, ChannelHandlerContext ctx, Command<?> cmd) {
        final ResponseFuture responseFuture = responseTable.get(cmd.getRequestId());
        if (responseFuture != null) {
            responseFuture.setResponseCommand(cmd);
            // async remote call
            if (responseFuture.getInvokeCallback() != null) {
                boolean runInThisThread = false;
                ExecutorService executor = this.getCallbackExecutor();
                if (executor != null) {
                    try {
                        executor.submit(new Runnable() {
                            public void run() {
                                try {
                                    responseFuture.executeInvokeCallback(ctx);
                                } catch (Throwable e) {
                                    LOGGER.warn("execute callback in executor exception, and callback throw", e);
                                }
                            }
                        });
                    } catch (Exception e) {
                        runInThisThread = true;
                        LOGGER.warn("execute callback in executor exception, maybe executor busy", e);
                    }
                } else {
                    runInThisThread = true;
                }

                if (runInThisThread) {
                    try {
                        responseFuture.executeInvokeCallback(ctx);
                    } catch (Throwable e) {
                        LOGGER.warn("executeInvokeCallback Exception", e);
                    }
                }
            }
            // sync remote call
            else {
                responseFuture.putResponse(cmd);
            }
        } else {
            //case
            //1.the request is not sending by the client
            //2.the request is sending by the client,but it is timeout,and after the timeout period,the server response this request.
            LOGGER.warn(String.format("receive response %s, but not matched any request,channel id %s", cmd.toString(), RemotingHelper.getChannelId(ctx.channel())));
        }
        responseTable.remove(cmd.getRequestId());
    }

    @Override
    public void processMessageReceived(RemotingProcessor remotingProcessor, ChannelHandlerContext ctx, Command<?> cmd) throws Exception {
        Attribute<Long> lastActiveTime = ctx.channel().attr(Constants.LAST_ACTIVE_TIME_ATTR_KEY);
        lastActiveTime.set(System.currentTimeMillis());
        if (cmd != null) {
            switch (MessageType.parse(cmd.getType())) {
                case REQUEST:
                    processRequestCommand(remotingProcessor, ctx, cmd);
                    break;
                case RESPONSE:
                    processResponseCommand(remotingProcessor, ctx, cmd);
                    break;
                default:
                    break;
            }
        }
    }

    abstract public ExecutorService getCallbackExecutor();

    public void scanResponseTable() {
        Iterator<Map.Entry<String, ResponseFuture>> it = this.responseTable.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, ResponseFuture> next = it.next();
            ResponseFuture rep = next.getValue();

            if ((rep.getBeginTimestamp() + rep.getTimeoutMillis() + 1000) <= System.currentTimeMillis()) {
                it.remove();
                try {
                    rep.executeInvokeCallback(null);
                } catch (Throwable e) {
                    LOGGER.warn("scanResponseTable, operationComplete Exception", e);
                }

                LOGGER.warn("remove timeout request, " + rep);
            }
        }
    }

    @Override
    public Command<?> invokeSync(final Channel channel, final Command<?> request, final long timeoutMillis) throws InterruptedException, RemotingSendRequestException, RemotingTimeoutException {
        try {
            final ResponseFuture responseFuture = new ResponseFuture(request.getRequestId(), timeoutMillis, request, null);
            this.responseTable.put(channel.id().asLongText() + request.getRequestId(), responseFuture);
            channel.writeAndFlush(request).addListener(new ChannelFutureListener() {
                @Override
                public void operationComplete(ChannelFuture f) throws Exception {
                    if (f.isSuccess()) {
                        responseFuture.setSendRequestOK(true);
                        Attribute<Long> lastActiveTime = channel.attr(Constants.LAST_ACTIVE_TIME_ATTR_KEY);
                        lastActiveTime.set(System.currentTimeMillis());
                        return;
                    } else {
                        responseFuture.setSendRequestOK(false);
                    }
                    responseTable.remove(request.getRequestId());
                    responseFuture.setCause(f.cause());
                    responseFuture.putResponse(null);
                    LOGGER.warn(String.format("send request %s to channel <%s> failed.", request.toString(), RemotingHelper.getChannelId(channel)));
                }
            });
            Command<?> responseCommand = responseFuture.waitResponse(timeoutMillis);
            if (null == responseCommand) {
                // successfully sending the remote request,timeout happens when reading the ACK
                if (responseFuture.isSendRequestOK()) {
                    LOGGER.warn(String.format("timeout when waiting for response from remote channel %s. request is %s",
                            RemotingHelper.parseChannelRemoteAddress(channel),
                            request.toString()));
                    throw new RemotingTimeoutException(RemotingHelper.getChannelId(channel),
                            timeoutMillis, responseFuture.getCause());
                }
                // failed in sending the remote request
                else {
                    LOGGER.warn(String.format("failed when sending request to remote channel %s. request is %s",
                            RemotingHelper.parseChannelRemoteAddress(channel),
                            request.toString()));
                    throw new RemotingSendRequestException(RemotingHelper.getChannelId(channel),
                            responseFuture.getCause());
                }
            }
            return responseCommand;
        } finally {
            this.responseTable.remove(request.getRequestId());
        }
    }

    @Override
    public void invokeAsync(final Channel channel, final Command<?> request,
                            final long timeoutMillis, final InvokeCallback invokeCallback) throws InterruptedException,
            RemotingTooMuchRequestException, RemotingTimeoutException, RemotingSendRequestException {

        final ResponseFuture responseFuture = new ResponseFuture(request.getRequestId(), timeoutMillis, request, invokeCallback);
        this.responseTable.put(channel.id().asLongText() + request.getRequestId(), responseFuture);
        try {
            channel.writeAndFlush(request).addListener(new ChannelFutureListener() {
                @Override
                public void operationComplete(ChannelFuture f) throws Exception {
                    if (f.isSuccess()) {
                        responseFuture.setSendRequestOK(true);
                        Attribute<Long> lastActiveTime = channel.attr(Constants.LAST_ACTIVE_TIME_ATTR_KEY);
                        lastActiveTime.set(System.currentTimeMillis());
                        return;
                    } else {
                        responseFuture.setSendRequestOK(false);
                    }

                    responseFuture.putResponse(null);
                    responseTable.remove(request.getRequestId());
                    try {
                        responseFuture.executeInvokeCallback(null);
                    } catch (Throwable e) {
                        LOGGER.warn("execute callback in writeAndFlush addListener, and callback throw", e);
                    }

                    LOGGER.warn("send a request command to channel <{}> failed, request {}",
                            RemotingHelper.parseChannelRemoteAddress(channel), request);
                }
            });
        } catch (Exception e) {
            LOGGER.warn("send a request command to channel <" + RemotingHelper.parseChannelRemoteAddress(channel) + "> Exception", e);
            throw new RemotingSendRequestException(RemotingHelper.getChannelId(channel), e);
        }
    }

    @Override
    public void invokeOneway(final Channel channel, final Command<?> request,
                             final long timeoutMillis) throws InterruptedException, RemotingTooMuchRequestException,
            RemotingTimeoutException, RemotingSendRequestException {
        request.markOneway();
        try {
            channel.writeAndFlush(request).addListener(new ChannelFutureListener() {
                @Override
                public void operationComplete(ChannelFuture f) throws Exception {
                    if (!f.isSuccess()) {
                        LOGGER.warn("send a request command to channel <{}> failed, channel status is {}, request is {}", channel.remoteAddress(), channel.isActive(), request);
                    } else {
                        Attribute<Long> lastActiveTime = channel.attr(Constants.LAST_ACTIVE_TIME_ATTR_KEY);
                        lastActiveTime.set(System.currentTimeMillis());
                    }
                }
            });
        } catch (Exception e) {
            LOGGER.warn("write send a request command to channel <" + channel.remoteAddress() + "> failed.");
            throw new RemotingSendRequestException(RemotingHelper.getChannelId(channel), e);
        }
    }

    public void setSessionService(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    public void setClientResponseService(ClientResponseService clientResponseService) {
        this.clientResponseService = clientResponseService;
    }
}