package com.kupai.gateway.connection.netty;

import java.nio.ByteBuffer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kupai.gateway.connection.exception.RemotingCommandException;
import com.kupai.gateway.connection.protocol.BinaryMessage;
import com.kupai.gateway.connection.remoting.RemotingHelper;
import com.kupai.gateway.connection.util.Constants;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;

/**
 * 基于自定义的报文解析器
 * Date: 16/12/25
 * Time: 上午10:32
 *
 * @author lintc
 */
public class NettyDecoder extends LengthFieldBasedFrameDecoder {
    private static final Logger logger = LoggerFactory.getLogger(NettyDecoder.class);
    public NettyDecoder() {
        super(Constants.MAX_PACKET_LENGTH, 2, 4, 2, 0);
    }

    @Override
    protected Object decode(ChannelHandlerContext ctx, ByteBuf in) throws Exception {
        ByteBuf frame = null;
        try {
            frame = (ByteBuf) super.decode(ctx, in);
            if (null == frame) {
                logger.warn("decode input stream frame is null");
                return null;
            }
            ByteBuffer byteBuffer = frame.nioBuffer();
            return BinaryMessage.decode(byteBuffer);
        } catch (Exception e) {
            logger.error("decode exception on channel " + RemotingHelper.parseChannelRemoteAddress(ctx.channel()), e);
            throw new RemotingCommandException("remote command can't decode",e);
        } finally {
            if (null != frame) {
                frame.release();
            }
        }
    }
}
