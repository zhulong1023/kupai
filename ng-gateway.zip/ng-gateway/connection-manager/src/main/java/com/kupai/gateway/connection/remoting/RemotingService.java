package com.kupai.gateway.connection.remoting;

/**
 * the base interface of remote communicating
 * Date: 16/12/25
 * Time: 下午3:03
 *
 * @author lintc
 */
public interface RemotingService {
    void start();

    void shutdown();

    void registerRPCHook(RPCHook rpcHook);
}
