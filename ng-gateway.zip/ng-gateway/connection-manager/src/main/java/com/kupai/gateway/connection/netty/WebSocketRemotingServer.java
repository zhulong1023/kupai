/**
 *
 */
package com.kupai.gateway.connection.netty;

import java.net.InetSocketAddress;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicInteger;

import javax.net.ssl.SSLEngine;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kupai.gateway.common.util.NetUtils;
import com.kupai.gateway.common.util.StatisticsLog;
import com.kupai.gateway.common.util.ThreadFactoryImpl;
import com.kupai.gateway.common.util.ThreadUtils;
import com.kupai.gateway.connection.netty.handler.NettyConnectManageHandler;
import com.kupai.gateway.connection.netty.handler.WebSocketProtocolHandler;
import com.kupai.gateway.connection.netty.handler.WebSocketServerHandler;
import com.kupai.gateway.connection.protocol.Pair;
import com.kupai.gateway.connection.remoting.ChannelEventListener;
import com.kupai.gateway.connection.remoting.RPCHook;
import com.kupai.gateway.connection.remoting.RequestProcessor;
import com.kupai.gateway.connection.security.SslContextFactory;
import com.kupai.gateway.connection.util.Constants;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.websocketx.extensions.compression.WebSocketServerCompressionHandler;
import io.netty.handler.ssl.SslHandler;
import io.netty.util.concurrent.DefaultEventExecutorGroup;

/**
 * @author zhouqisheng
 *         <p>
 *         <p>
 *         2017年3月22日
 */
public class WebSocketRemotingServer extends NettyRemotingAbstract {

    private static final Logger log = LoggerFactory.getLogger(WebSocketRemotingServer.class);
    private final ServerBootstrap serverBootstrap;
    private final EventLoopGroup eventLoopGroupWorker;
    private final EventLoopGroup eventLoopGroupBoss;
    private final NettyServerConfig nettyServerConfig;
    // the executor is using to process the callback ACK
    private final ExecutorService publicExecutor;
    private final ChannelEventListener channelEventListener;
    /**
     * the total connection number of the config server
     */
    private final AtomicInteger totalConnectionNumber = new AtomicInteger(0);
    // timer
    private final Timer timer = new Timer("ServerHouseKeepingService", true);
    private DefaultEventExecutorGroup defaultEventExecutorGroup;
    private RPCHook rpcHook;
    // the listening port of the server
    private int port = 0;
    //the http header
    private String origin;
    
    //handler
    private final SslHandler sslHandler;
 

    public WebSocketRemotingServer(final NettyServerConfig nettyServerConfig) {
        this(nettyServerConfig, null, null);
    }

    public WebSocketRemotingServer(final NettyServerConfig nettyServerConfig, final ChannelEventListener channelEventListener, String origin) {
        this.serverBootstrap = new ServerBootstrap();
        this.nettyServerConfig = nettyServerConfig;
        this.channelEventListener = channelEventListener;
        this.origin = origin;

        int publicThreadNumbers = nettyServerConfig.getServerCallbackExecutorThreads();
        if (publicThreadNumbers <= 0) {
            publicThreadNumbers = 4;
        }

        this.publicExecutor = Executors.newFixedThreadPool(publicThreadNumbers, new ThreadFactoryImpl("NettyServerPublicExecutor-"));

        this.eventLoopGroupBoss = new NioEventLoopGroup(1, new ThreadFactoryImpl("NettyBossSelector-"));

        this.eventLoopGroupWorker = new NioEventLoopGroup(nettyServerConfig.getServerSelectorThreads(),
                new ThreadFactoryImpl(String.format("NettyServerSelector-%d-", nettyServerConfig.getServerSelectorThreads())));
        
        if (nettyServerConfig.isSslSupport()) {
            SSLEngine sslEngine = SslContextFactory.getServerContext().createSSLEngine();
            //设置SSLEngine为服务端模式,由于不需要对客户端进行认证,因此NeedClientAuth不需要额外设置,使用默认值False
            sslEngine.setUseClientMode(false);
            //sslEngine.setNeedClientAuth(true);
            sslHandler = new SslHandler(sslEngine);
        } else {
            sslHandler = null;
        }
    }

    @Override
    public void start() {
        StatisticsLog.registerExecutor("server-public-pool", (ThreadPoolExecutor) this.publicExecutor);
        this.defaultEventExecutorGroup = new DefaultEventExecutorGroup(nettyServerConfig.getServerWorkerThreads(), new ThreadFactoryImpl("NettyServerWorkerThread-"));

        if (!NetUtils.isValidPort(this.nettyServerConfig.getListenPort())) {
            throw new IllegalArgumentException(String.format("invalid listening port %s of the config server", this.nettyServerConfig.getListenPort()));
        }
        
        ServerBootstrap childHandler = this.serverBootstrap
                .group(this.eventLoopGroupBoss, this.eventLoopGroupWorker)
                .channel(NioServerSocketChannel.class)
                .option(ChannelOption.SO_BACKLOG, 1024)
                .option(ChannelOption.SO_REUSEADDR, true)
                .childOption(ChannelOption.TCP_NODELAY, true)
                .childOption(ChannelOption.SO_SNDBUF, NettySystemConfig.SocketSndbufSize)
                .childOption(ChannelOption.SO_RCVBUF, NettySystemConfig.SocketRcvbufSize)
                .childHandler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    public void initChannel(SocketChannel ch) throws Exception {
                        ch.pipeline().addLast(
                                defaultEventExecutorGroup,
                                new HttpServerCodec(),
                                new HttpObjectAggregator(65536),
                                new WebSocketServerCompressionHandler(),
                                new WebSocketProtocolHandler(Constants.WEBSOCKET_PATH, null, true, 65536, false, true, origin),
                                new WebSocketEncoder(),
                                new NettyConnectManageHandler(nettyServerConfig, channelEventListener, totalConnectionNumber),
                                new WebSocketServerHandler(WebSocketRemotingServer.this));
                        if (nettyServerConfig.isSslSupport()) {
                            ch.pipeline().addFirst(sslHandler);
                        } 
                    }
                });

        if (NettySystemConfig.NettyPooledByteBufAllocatorEnable) {
            //this option may occupy too much no-heap memory.
            //the option is close in default.
            childHandler.childOption(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT);
        }

        try {
            int port = this.nettyServerConfig.isSslSupport() ? this.nettyServerConfig.getSslListenPort() : this.nettyServerConfig.getListenPort();
            ChannelFuture sync = this.serverBootstrap.bind(port).sync();
            InetSocketAddress address = (InetSocketAddress) sync.channel().localAddress();
            this.port = address.getPort();
            log.info("start netty server, listen port " + this.port);
        } catch (InterruptedException ex) {
            throw new RuntimeException("serverBootstrap.bind().sync() InterruptedException", ex);
        }


        // schedule the timeout of async call per second
        this.timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                try {
                    scanResponseTable();
                } catch (Exception e) {
                    log.error("scanResponseTable exception", e);
                }
            }
        }, 1000 * 3, 3000);
    }

    @Override
    public void registerProcessor(int requestCode, RequestProcessor processor,
                                  ExecutorService executor) {
        ExecutorService executorThis = executor;
        if (null == executor) {
            executorThis = this.publicExecutor;
        }

        Pair<RequestProcessor, ExecutorService> pair = new Pair<>(processor, executorThis);
        this.processorTable.put(requestCode, pair);
    }

    @Override
    public void registerDefaultProcessor(RequestProcessor processor,
                                         ExecutorService executor) {
        this.defaultRequestProcessor = new Pair<>(processor, executor);
    }

    @Override
    public void shutdown() {
        try {
            this.timer.cancel();
            this.eventLoopGroupBoss.shutdownGracefully();

            this.eventLoopGroupWorker.shutdownGracefully();

            if (this.defaultEventExecutorGroup != null) {
                this.defaultEventExecutorGroup.shutdownGracefully();
            }
        } catch (Exception e) {
            log.error("NettyRemotingServer shutdown exception, ", e);
        }

        if (this.publicExecutor != null) {
            try {
                ThreadUtils.shutdownAndAwaitTermination(this.publicExecutor);
            } catch (Exception e) {
                log.error("NettyRemotingServer shutdown exception, ", e);
            }
        }
    }

    @Override
    public ChannelEventListener getChannelEventListener() {
        return channelEventListener;
    }

    @Override
    public ExecutorService getCallbackExecutor() {
        return this.publicExecutor;
    }


    @Override
    public void registerRPCHook(RPCHook rpcHook) {
        this.rpcHook = rpcHook;
    }

    @Override
    public RPCHook getRPCHook() {
        return this.rpcHook;
    }

    @Override
    public int localPort() {
        return this.port;
    }

}
