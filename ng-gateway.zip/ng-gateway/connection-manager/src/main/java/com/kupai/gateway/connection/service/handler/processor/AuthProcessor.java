/**
 * 
 */
package com.kupai.gateway.connection.service.handler.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kupai.gateway.common.annotations.RegistrantConfiguration;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.data.Authorization;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.service.session.SessionService;

/**
 * @author zhouqisheng
 * 2017年3月28日
 */
@Component
@RegistrantConfiguration(code = {RequestCode.AUTH}, order = 0, unique = true)
public class AuthProcessor implements JGroupsMessageProcessor {
    @Autowired
    private SessionService sessionService;

    /* (non-Javadoc)
     * @see com.kupai.gateway.connection.service.handler.processor.JGroupsMessageProcessor#process(com.kupai.gateway.common.jgroups.JGroupMessage)
     */
    @Override
    public Command<?> process(JGroupMessage jmsg) {
        Authorization auth = (Authorization) jmsg.getData();
        Session session = sessionService.getOnlineUsersByUid(auth.getSource(), auth.getUid(), auth.getClientType());
        if(session != null && session.getConnectionCreatedTime() != auth.getNewSessionCreateTime()){
            session.close(1);
        }
        
        return null;
    }

}
