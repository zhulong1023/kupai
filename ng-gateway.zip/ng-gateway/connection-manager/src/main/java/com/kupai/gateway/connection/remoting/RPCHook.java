package com.kupai.gateway.connection.remoting;

import com.kupai.gateway.connection.protocol.Command;

/**
 * Date: 16/12/25
 * Time: 下午3:04
 *
 * @author lintc
 */
public interface RPCHook {
    void doBeforeRequest(final String remoteAddress, final Command<?> request);

    void doAfterResponse(final Command<?> request, final Command<?> response);
}
