/**
 *
 */
package com.kupai.gateway.connection.netty;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.kupai.gateway.connection.protocol.Command;

import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageEncoder;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;

/**
 * @author zhouqisheng 2017年3月23日
 */
@Sharable
public class WebSocketEncoder extends MessageToMessageEncoder<Command<?>> {
    @Override
    protected void encode(ChannelHandlerContext ctx, Command<?> msg, List<Object> out) throws Exception {
        TextWebSocketFrame wsFrame = new TextWebSocketFrame(JSON.toJSONString(msg));
        out.add(wsFrame);
    }

}
