package com.kupai.gateway.connection.remoting;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import com.kupai.gateway.connection.protocol.Command;
import io.netty.channel.ChannelHandlerContext;

/**
 * Date: 16/12/25
 * Time: 下午3:12
 *
 * @author lintc
 */
public class ResponseFuture {
    private volatile Command<?> responseCommand;
    private Command<?> requestCommand;
    private volatile boolean sendRequestOK = true;
    private volatile Throwable cause;
    private final long opaque;
    private final long timeoutMillis;
    private final InvokeCallback invokeCallback;
    private final long beginTimestamp = System.currentTimeMillis();
    private final CountDownLatch countDownLatch = new CountDownLatch(1);
    private final AtomicBoolean executeCallbackOnlyOnce = new AtomicBoolean(false);


    public ResponseFuture(long opaque, long timeoutMillis, Command<?> requestCommand, InvokeCallback invokeCallback) {
        this.opaque = opaque;
        this.timeoutMillis = timeoutMillis;
        this.requestCommand = requestCommand;
        this.invokeCallback = invokeCallback;
    }


    public void executeInvokeCallback(ChannelHandlerContext ctx) {
        if (invokeCallback != null) {
            if (this.executeCallbackOnlyOnce.compareAndSet(false, true)) {
                invokeCallback.operationComplete(this, ctx);
            }
        }
    }

    public boolean isTimeout() {
        long diff = System.currentTimeMillis() - this.beginTimestamp;
        return diff > this.timeoutMillis;
    }


    public Command<?> waitResponse(final long timeoutMillis) throws InterruptedException {
        this.countDownLatch.await(timeoutMillis, TimeUnit.MILLISECONDS);
        return this.responseCommand;
    }


    public void putResponse(final Command<?> responseCommand) {
        this.responseCommand = responseCommand;
        this.countDownLatch.countDown();
    }


    public long getBeginTimestamp() {
        return beginTimestamp;
    }


    public boolean isSendRequestOK() {
        return sendRequestOK;
    }


    public void setSendRequestOK(boolean sendRequestOK) {
        this.sendRequestOK = sendRequestOK;
    }


    public long getTimeoutMillis() {
        return timeoutMillis;
    }


    public InvokeCallback getInvokeCallback() {
        return invokeCallback;
    }


    public Throwable getCause() {
        return cause;
    }


    public void setCause(Throwable cause) {
        this.cause = cause;
    }


    public Command<?> getResponseCommand() {
        return responseCommand;
    }


    public void setResponseCommand(Command<?> responseCommand) {
        this.responseCommand = responseCommand;
    }

    public Command<?> getRequestCommand() {
        return requestCommand;
    }

    public void setRequestCommand(Command<?> requestCommand) {
        this.requestCommand = requestCommand;
    }

    public long getOpaque() {
        return opaque;
    }


    @Override
    public String toString() {
        return "ResponseFuture{" +
                "responseCommand=" + responseCommand +
                ", requestCommand=" + requestCommand +
                ", sendRequestOK=" + sendRequestOK +
                ", cause=" + cause +
                ", opaque=" + opaque +
                ", timeoutMillis=" + timeoutMillis +
                ", invokeCallback=" + invokeCallback +
                ", beginTimestamp=" + beginTimestamp +
                ", countDownLatch=" + countDownLatch +
                ", executeCallbackOnlyOnce=" + executeCallbackOnlyOnce +
                '}';
    }
}
