package com.kupai.gateway.connection.netty;

import java.nio.ByteBuffer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.connection.exception.RemotingCommandException;
import com.kupai.gateway.connection.protocol.BinaryMessage;
import com.kupai.gateway.connection.protocol.Command;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

/**
 * @author zhouqisheng
 *         2017年3月25日
 */
public class NettyEncoder extends MessageToByteEncoder<Command<?>> {
    private static final Logger log = LoggerFactory.getLogger(NettyEncoder.class);

    @Override
    public void encode(ChannelHandlerContext ctx, Command<?> command, ByteBuf out)
            throws Exception {
        try {
            BinaryMessage msg = BinaryMessage.createResponseCommand(command.getCode(), command.getRequestId());
            if (command.getData() instanceof JSONObject) {
                msg.setBody(JSON.toJSONBytes(command.getData()));
            }
            ByteBuffer outputBytes = msg.encode();

            out.writeBytes(outputBytes);
        } catch (Exception e) {
            log.error(String.format("exception happens when encode remote command %s on channel %s",
                    command, ctx.channel()), e);
            throw new RemotingCommandException("remote command can't encode.", e);
        }
    }
}