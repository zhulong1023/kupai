package com.kupai.gateway.connection.service.handler.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kupai.gateway.common.annotations.RegistrantConfiguration;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.util.StringUtils;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.service.session.SessionRoomService;
import com.kupai.gateway.connection.service.session.SessionService;

/**
 * Created by zhulong on 2017/3/30.
 */
@Component
@RegistrantConfiguration(code = { ResponseCode.INOUT_ROOM_OK, ResponseCode.NONE_ROOM }, order = 1, unique = true)
public class InOutRoomProcessor implements JGroupsMessageProcessor {

    private Logger log = LoggerFactory.getLogger(getClass());

    @Autowired
    private SessionRoomService sessionRoomService;
    @Autowired
    private SessionService sessionService;

    @Override
    public Command<?> process(JGroupMessage jmsg) {
        Command<Object> msg = null;
        if (jmsg.getCode() == ResponseCode.INOUT_ROOM_OK) {
            com.kupai.gateway.common.data.Command cmd = (com.kupai.gateway.common.data.Command) jmsg.getData();
            String event = cmd.getMeta().getEvent();
            if (StringUtils.isNotBlank(event)) {
                Session session = sessionService.getOnlineUsersByUid(jmsg.getSource(), jmsg.getToUid().get(0), jmsg.getClientType());
                if (session == null) {
                    log.error(String.format("session disconnect interrupt ,JGroupMessage code is %s ", jmsg.getCode()));
                    return null;
                }
                if ("enter".equals(event)) {
                    // 进入房间，把session加入房间
                    sessionRoomService.addSessionToRoom(session, jmsg.getRoomId());
                } else {
                    sessionRoomService.removeSessionFromRoom(session, jmsg.getRoomId());
                }
                msg = Command.buildResponse(jmsg.getCode(), ResponseMessage.SUCCESS, jmsg.getRequestId(), jmsg.getVersion());
            }
        } else {
            msg = Command.buildResponse(jmsg.getCode(), jmsg.getData(), jmsg.getRequestId(), jmsg.getVersion());
        }
        return msg;
    }
}
