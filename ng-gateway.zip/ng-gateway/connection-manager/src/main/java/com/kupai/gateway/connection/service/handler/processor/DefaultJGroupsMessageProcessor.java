/**
 * 
 */
package com.kupai.gateway.connection.service.handler.processor;

import org.springframework.stereotype.Component;

import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.connection.protocol.Command;

/**
 * @author zhouqisheng
 * 2017年3月28日
 */
@Component("defaultJGroupsMessageProcessor")
public class DefaultJGroupsMessageProcessor implements JGroupsMessageProcessor {
    
    /* (non-Javadoc)
     * @see com.kupai.gateway.connection.service.handler.processor.JGroupsMessageProcessor#process(com.kupai.gateway.common.jgroups.JGroupMessage)
     */
    @Override
    public Command<?> process(JGroupMessage jmsg) {
        Long requestId = jmsg.getRequestId();
        if (null != requestId) {
            requestId = requestId.longValue();
        } else {
            requestId = 0L;
        }
        Command<Object> msg = new Command<Object>(jmsg.getCode(), jmsg.getData(), requestId);
        msg.setType(jmsg.getType());
        msg.setVersion(jmsg.getVersion());
        msg.setOneway(jmsg.isOneWay() ? 1 : 0);
        
        return msg;
    }

}
