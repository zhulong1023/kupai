package com.kupai.gateway.connection.remoting;

import java.net.InetSocketAddress;
import java.net.SocketAddress;

import com.kupai.gateway.connection.util.Constants;

import io.netty.channel.Channel;

/**
 * Date: 16/12/25
 * Time: 下午3:25
 *
 * @author lintc
 */
public class RemotingHelper {
    /**
     * IP:PORT
     */
    public static SocketAddress string2SocketAddress(final String address) {
        String[] s = address.split(":");
        return new InetSocketAddress(s[0], Integer.valueOf(s[1]));
    }

    public static String parseChannelRemoteAddress(final Channel channel) {
        if (null == channel) {
            return "";
        }
        String ip = channel.attr(Constants.CLIENT_IP).get();
        final SocketAddress remote = channel.remoteAddress();
        final String address = ip == null ? (remote != null ? remote.toString() : "") : ip;

        if (address.length() > 0) {
            int index = address.lastIndexOf("/");
            if (index >= 0) {
                return address.substring(index + 1);
            }

            return address;
        }

        return "";
    }

    public static String parseChannelLocalAddress(final Channel channel) {
        if (null == channel) {
            return "";
        }
        final SocketAddress local = channel.localAddress();
        final String address = local != null ? local.toString() : "";

        if (address.length() > 0) {
            int index = address.lastIndexOf("/");
            if (index >= 0) {
                return address.substring(index + 1);
            }

            return address;
        }

        return "";
    }

    public static String getChannelId(final Channel channel) {
        return parseChannelRemoteAddress(channel) + "-" + parseChannelLocalAddress(channel);
    }
}
