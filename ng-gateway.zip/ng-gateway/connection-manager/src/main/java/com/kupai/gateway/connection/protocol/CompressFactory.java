package com.kupai.gateway.connection.protocol;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Date: 16/12/25
 * Time: 下午1:53
 *
 * @author lintc
 */
public class CompressFactory {
    private final static Map</**/Integer, Compress> compressMap = new ConcurrentHashMap<>(8);

    static {
        compressMap.put(CompressType.NONE.getType(), new NoneCompress());
        compressMap.put(CompressType.QUICK_LZ.getType(), new QuickLZ());
    }

    public static Compress createCompress(CompressType type) {
        Compress compress = compressMap.get(type.getType());
        if (null == compress) {
            return compressMap.get(CompressType.NONE.getType());
        } else {
            return compress;
        }
    }
}
