package com.kupai.gateway.connection.protocol;

/**
 * Date: 16/12/25
 * Time: 下午1:40
 *
 * @author lintc
 */
public class CommandFlagUtils {

    public static SerializeType getSerializeType(Header header) {
        int type = 0;
        if (null != header) {
            type = header.getSerializable();
        }
        return SerializeType.getSerializeType(type);
    }

    public static void setSerializeType(Header header, SerializeType type) {
        if (null != header) {
            header.setSerializable(type.getType());
        }
    }


    public static boolean isCompressed(Header header) {
        //压缩字段占用一个字节,flag不为0则代表启用了压缩算法
        return null != header && header.getCompress() == 0;
    }

    public static CompressType getCompressType(Header header) {
        int type = 0;
        if (null != header) {
            type = header.getCompress();
        }
        return CompressType.getCompressType(type);
    }

    public static void setCompressType(Header header, CompressType type) {
        if (null != header) {
            header.setCompress(type.getType());
        }
    }


    public static EncryptType getEncrypType(Header header) {
        int type = 0;
        if (null != header) {
            type = header.getEncrypt();
        }
        return EncryptType.getEncryptType(type);
    }

    public static void setEncyptType(Header header, EncryptType type) {
        if (null != header) {
            header.setEncrypt(type.getType());
        }
    }

    public static boolean isEncrypt(Header header) {
        return null != header && header.getEncrypt() != 0;
    }
}
