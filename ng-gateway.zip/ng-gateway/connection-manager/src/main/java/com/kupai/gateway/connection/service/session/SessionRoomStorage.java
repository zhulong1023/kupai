package com.kupai.gateway.connection.service.session;

import com.kupai.gateway.common.contants.KeyRepertory;
import com.kupai.gateway.connection.domain.Session;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.clients.jedis.JedisCluster;

import java.util.Set;

/**
 * 用于维护房间内所有的session
 * Created by Administrator on 2017/4/7.
 */
@Component
public class SessionRoomStorage {

    private final static int ROOM_EXPIRE_LONG = 10 * 24 * 60 * 60;

    @Autowired
    private JedisCluster jedisCluster;

    /**
     * 保存session到房间中
     *
     * @param roomId  房间id
     * @param session 用户对应的session
     * @return
     */
    public boolean saveSession2Room(String roomId, Session session) {
        String key = getRoomSessionKeyPre(roomId);
        String uid = String.valueOf(session.getUid());
        boolean flag = jedisCluster.sadd(key, uid) > 0;
        if (flag) {
            jedisCluster.expire(key, ROOM_EXPIRE_LONG);
        }
        return flag;
    }

    /**
     * 删除房间中的某一个session
     *
     * @param roomId
     * @param session
     * @return
     */
    public boolean removeSessionFromRoom(String roomId, Session session) {
        String key = getRoomSessionKeyPre(roomId);
        String uid = String.valueOf(session.getUid());
        boolean flag = jedisCluster.srem(key, uid) > 0;
        return flag;
    }

    /**
     * 获取房间内所有的session列表
     *
     * @param roomId 房间id
     * @return
     */
    public Set<String> listRoomSession(String roomId) {
        String key = getRoomSessionKeyPre(roomId);
        Set<String> set = jedisCluster.smembers(key);
        if (CollectionUtils.isNotEmpty(set)) {
            return set;
        }
        return null;
    }

    /**
     * 判断某个用户是否在房间内
     *
     * @param roomId 房间号
     * @param uid    用户uid
     * @return
     */
    public boolean isInRoom(String roomId, long uid) {
        String key = getRoomSessionKeyPre(roomId);
        return jedisCluster.sismember(key, String.valueOf(uid));
    }

    /**
     * 获取房间内的在线人数
     *
     * @param roomId 房间号
     * @return
     */
    public int countRoomSession(String roomId) {
        String key = getRoomSessionKeyPre(roomId);
        Long count = jedisCluster.scard(key);
        if (null == count) {
            return 0;
        }
        return count.intValue();
    }

    /**
     * 获得room session的key
     *
     * @param roomId
     * @return
     */
    private static String getRoomSessionKeyPre(String roomId) {
        return KeyRepertory.ROOM_SESSION_KEY_PRE + roomId;
    }
}
