package com.kupai.gateway.connection.service.session;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kupai.gateway.connection.domain.Session;

/**
 * Created by Administrator on 2017/3/23.
 */
@Service
public class SessionRoomService {
    private Logger log = LoggerFactory.getLogger(SessionRoomService.class);

    @Autowired
    private SessionRoomStorage sessionRoomStorage;

    /**
     * 支持一个用户在一个拍卖间建立多个连接
     */
    private Map<Long/* 房间ID */, Map<Long/* uid */, Set<Session>/* 使用支持并发操作的集合 */>> roomSessionMap = new ConcurrentHashMap<>();

    /**
     * 会话房间对应
     */
    private Map<Session, Long> sessionRoomMap = new ConcurrentHashMap<>();

    /**
     * 添加session到聊天室中
     * 
     * 一个会话只能在一个房间中，加入新房间会挤掉原有房间
     *
     * @param session
     *            用户session
     * @param roomId
     *            房间id
     * @return
     */
    public boolean addSessionToRoom(Session session, Long roomId) {
        if (roomId != null && roomId > 0) {
            log.info("add session to room, roomId {}, session {}", roomId, session);
            Map<Long, Set<Session>> roomUserSessionMap = roomSessionMap.get(roomId);
            //删除其他房间关联
            Long oldRoomId = getRoomIdBySession(session);
            if (oldRoomId != null) {
                if (roomId.longValue() == oldRoomId.longValue()) {
                    return true;
                } else {
                    removeSessionFromRoom(session , oldRoomId);// 踢掉用户
                }
            }

            if (null == roomUserSessionMap) {
                roomUserSessionMap = new ConcurrentHashMap<>();
                // 存放拍卖间的session列表
                Map<Long, Set<Session>> _roomUserSessionMap = roomSessionMap.putIfAbsent(roomId, roomUserSessionMap);
                if (_roomUserSessionMap != null) {
                    roomUserSessionMap = _roomUserSessionMap;
                }
            }

            Set<Session> roomUserSessionSet = roomUserSessionMap.get(session.getUid());
            if (null == roomUserSessionSet) {
                roomUserSessionSet = new ConcurrentSkipListSet<>();
                Set<Session> _roomUserSessionSet = roomUserSessionMap.putIfAbsent(session.getUid(),
                        roomUserSessionSet);
                if (_roomUserSessionSet != null) {
                    roomUserSessionSet = _roomUserSessionSet;
                }
            }
            // 存放用户的session列表
            roomUserSessionSet.add(session);
            // 存放会话房间列表
            sessionRoomMap.put(session, roomId);
            // 放入到全局session维护中---》 redis
            sessionRoomStorage.saveSession2Room(String.valueOf(roomId), session);
            log.info("add session to room successful, roomId {}, session {}", roomId, session);
        }
        return true;
    }

    /**
     * 从房间中删除用户session
     *
     * @param session
     *            用户session
     * @param roomId
     *            房间id
     * @return
     */
    public boolean removeSessionFromRoom(Session session, Long roomId) {
        if (null != roomId && roomId > 0 && roomSessionMap.containsKey(roomId)) {
            log.info("remove session from room, roomId {}, uid {}, session {}", roomId, session.getUid(),
                    session);
            Map<Long, Set<Session>> userSessionMap = roomSessionMap.get(roomId);
            if (userSessionMap != null) {
                Long uid = session.getUid();
                Set<Session> useSessionSet = userSessionMap.get(uid);
                if (useSessionSet != null) {
                    if (useSessionSet.remove(session)) {// 删除会话房间对应关系
                        this.sessionRoomMap.remove(session);
                        log.info("session is removed  from room successful, session={}, room={}", session, roomId);
                    }
                    // 用户没有任何连接,删除用户
                    if (CollectionUtils.isEmpty(useSessionSet)) {
                        userSessionMap.remove(uid);
                    }
                }
            }
            // 放入到全局session维护中---》 redis
            sessionRoomStorage.removeSessionFromRoom(String.valueOf(roomId), session);
            // 拍卖间没有任何用户链接,删除拍卖间
            if (userSessionMap.isEmpty()) {
                roomSessionMap.remove(roomId);
            }
        }
        return true;
    }

    /**
     * 从房间中删除用户session
     * 
     * @param session
     */
    public void removeSessionFromRoom(Session session) {
        Long roomId = this.sessionRoomMap.get(session);
        if (roomId != null) {
            this.removeSessionFromRoom(session, roomId);
        }
    }

    /**
     * 根据拍卖间编号查询该拍卖间所有在线的用户 session --->查询的是本台服务器上的所有连接
     *
     * @param roomId
     *            拍卖间ID
     * @return 拍卖间的所有用户连接
     */
    public Map<Long, Set<Session>> getOnlineUsersByRoomId(Long roomId) {
        if (null != roomId && roomId > 0) {
            Map<Long, Set<Session>> userSessionMap = roomSessionMap.get(roomId);
            if (null == userSessionMap || userSessionMap.isEmpty()) {
                return Collections.emptyMap();
            } else {
                return userSessionMap;
            }
        }
        return Collections.emptyMap();
    }

    /**
     * 查询某个拍卖间下某个用户所有的会话
     *
     * @param roomId
     *            拍卖间
     * @param userId
     *            用户ID
     * @return 用户会话列表
     */
    public Set<Session> getSessionByRoomIdAndUserId(Long roomId, Long userId) {
        Map<Long, Set<Session>> userSessionMap = roomSessionMap.get(roomId);
        if (null != userSessionMap && !userSessionMap.isEmpty()) {
            return userSessionMap.get(userId);
        } else {
            return Collections.emptySet();
        }
    }

    /**
     * 获取整个服务的房间用户连接情况
     *
     * @return
     */
    public Map<Long, Map<Long, Set<Session>>> getRoomSessionMap() {

        return this.roomSessionMap;
    }

    public Long getRoomIdBySession(Session session) {
        return this.sessionRoomMap.get(session);
    }
}
