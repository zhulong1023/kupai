package com.kupai.gateway.connection.remoting;

import com.kupai.gateway.connection.netty.NettyEvent;

/**
 * Date: 16/12/25
 * Time: 下午3:21
 *
 * @author lintc
 */
public interface ChannelEventListener {
    void onChannelConnect(final NettyEvent event);

    void onChannelClose(final NettyEvent event);

    void onChannelException(final NettyEvent event);

    void onChannelIdle(final NettyEvent event);

    void onChannelActive(final NettyEvent event);
    
    void onChannelHeartbeat(final NettyEvent event);
}
