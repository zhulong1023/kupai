/**
 * 
 */
package com.kupai.gateway.connection.protocol;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicInteger;

import com.kupai.gateway.common.contants.MessageType;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.connection.exception.RemotingCommandException;
import com.kupai.gateway.connection.util.Constants;

/**
 * @author zhouqisheng
 * 2017年3月25日
 */
public class BinaryMessage {
    private static AtomicInteger requestId = new AtomicInteger(0);
    private int packetLength;
    private int headerLength;
    private Header header;

    /**
     * the body of the remote message
     */
    private byte[] body;

    public BinaryMessage() {
        
    }


    public static BinaryMessage createRequestCommand(int code,byte[] content) {
        Header hdr = createHeader(code, requestId.incrementAndGet(), MessageType.REQUEST.getType());
        BinaryMessage cmd = new BinaryMessage();
        cmd.header = hdr;
        cmd.setCode(code);
        cmd.setBody(content);
        return cmd;
    }


    private byte[] buildHeader() {
        ByteBuffer headerBuffer = ByteBuffer.allocate(12);
        headerBuffer.put((byte) header.getVersion());//version
        headerBuffer.put((byte) header.getLanguageCode());//language code
        headerBuffer.put((byte) header.getCompress());//compress
        headerBuffer.put((byte) header.getEncrypt());//encrypt
        headerBuffer.put((byte) header.getSerializable());
        headerBuffer.put((byte) header.getRemotingType());//request/response flag
        headerBuffer.putShort((short) header.getCode());//request/response code
        headerBuffer.putLong(header.getRequestId());//request id
        headerBuffer.put((byte) header.getSource());
        headerBuffer.put((byte) header.getPriority());

        headerBuffer.flip();
        return headerBuffer.array();
    }

    public static Header decodeHeader(byte[] header) throws Exception {
        if (null != header && header.length >= Constants.MIN_PACKET_HEADER_LENGTH) {
            Header remoteHeader = new Header();
            ByteBuffer buffer = ByteBuffer.wrap(header);

            remoteHeader.setVersion(buffer.get());
            remoteHeader.setLanguageCode(buffer.get());
            remoteHeader.setCompress(buffer.get());
            remoteHeader.setEncrypt(buffer.get());
            remoteHeader.setSerializable(buffer.get());
            remoteHeader.setRemotingType(buffer.get());
            remoteHeader.setCode(buffer.getShort());
            remoteHeader.setRequestId(buffer.getLong());
            remoteHeader.setSource(buffer.get());
            remoteHeader.setPriority(buffer.get());

            return remoteHeader;
        } else {
            throw new Exception("invalid header format");
        }
    }


    public ByteBuffer encode() throws Exception {
        return encode(this.body != null ? this.body.length : 0);
    }
    
    public ByteBuffer encode(final int bodyLength) throws Exception {

        //valid the body's length
        if (bodyLength > Constants.MAX_PACKET_LENGTH) {
            throw new RemotingCommandException(String.format("request/response packet's body length is invalid.%s is not in[0,%s]", bodyLength, Constants.MAX_PACKET_LENGTH));
        }

        byte[] headerData = this.buildHeader();

        if (null == headerData) {
            throw new NullPointerException("header data is null or empty!");
        }

        int headerLength = headerData.length;
        //valid the header's length
        if (headerLength < Constants.MIN_PACKET_HEADER_LENGTH || headerLength > Constants.MAX_PACKET_HEADER_LENGTH) {
            throw new RemotingCommandException(String.format("request/response packet's header length is invalid. %s is not in [%s,%s]", headerLength, Constants.MIN_PACKET_HEADER_LENGTH, Constants.MAX_PACKET_HEADER_LENGTH));
        }

        int magicCodeSize = 2;
        int totalLengthSize = 4;
        int headerLengthSize = Constants.HEADER_LENGTH_BYTE_COUNT;

        ByteBuffer result = ByteBuffer.allocate(magicCodeSize + totalLengthSize + headerLengthSize + headerLength+bodyLength);
        //put magic code
        result.putShort(Constants.MAGIC_CODE);
        int totalLength = headerLength + bodyLength;
        this.setHeaderLength(headerLength);
        this.setPacketLength(totalLength);
        // put total length
        result.putInt(totalLength);
        // put header length
        result.putShort((short) headerLength);
        // put header data
        result.put(headerData);
        //put body
        if(null!=body && body.length>0){
            result.put(body);
        }
        result.flip();
        return result;
    }

    public static BinaryMessage decode(final ByteBuffer byteBuffer) throws Exception {
        int length = byteBuffer.remaining();
        //检查byte buffer长度是否符合最低标准
        if (length < Constants.PACKET_MIN_BYTES) {
            throw new RemotingCommandException(String.format("request/response message is invalid. byte buffer length %s is less than %s", length, Constants.PACKET_MIN_BYTES));
        }

        short magicCode = byteBuffer.getShort();//magic code
        int packetTotalLength = byteBuffer.getInt();// the total length of the packet
        int headerLength = byteBuffer.getShort();//the header length

        //valid the magic code
        if (magicCode != Constants.MAGIC_CODE) {
            throw new RemotingCommandException(String.format("request/response message magic code is invalid. %s is not match the correct code %s", magicCode, Constants.MAGIC_CODE));
        }

        //get the bytes of header content
        byte[] headerData = new byte[headerLength];
        byteBuffer.get(headerData);

        int bodyLength = packetTotalLength - headerLength;
        byte[] bodyData = null;
        if (bodyLength > 0) {
            bodyData = new byte[bodyLength];
            //get the bytes of body content
            byteBuffer.get(bodyData);
        }

        BinaryMessage cmd = new BinaryMessage();
        Header header = BinaryMessage.decodeHeader(headerData);
        cmd.setHeader(header);
        cmd.setHeaderLength(headerLength);
        cmd.setPacketLength(packetTotalLength);


        //check whether decrypt the input stream
        boolean isEncrypted = CommandFlagUtils.isEncrypt(header);
        byte[] bodyDataAfterDecrypted = bodyData;
        if (isEncrypted) {
            EncryptType encryptType = CommandFlagUtils.getEncrypType(header);
            //decrypt body data
            //TODO
        }

        //check whether decompress the input stream
        boolean isCompressed = CommandFlagUtils.isCompressed(header);
        byte[] bodyDataAfterUnCompressed = bodyDataAfterDecrypted;
        if (isCompressed) {
            CompressType type = CommandFlagUtils.getCompressType(header);
            Compress compress = CompressFactory.createCompress(type);
            if (null != compress) {
                bodyDataAfterUnCompressed = compress.decompress(bodyDataAfterDecrypted);
            }
        }
        cmd.setBody(bodyDataAfterUnCompressed);

        return cmd;
    }


    public static BinaryMessage createResponseCommand(int code, long requestId) {
        Header hdr = createHeader(code, requestId, MessageType.RESPONSE.getType());
        BinaryMessage cmd = new BinaryMessage();
        cmd.header = hdr;
        cmd.markResponseType();
        cmd.setCode(code);
        return cmd;
    }

    public long getRequestId() {
        long requestId =  this.header == null ? 0L : this.header.getRequestId();
        if(this.header != null &&  requestId == 0L){
            this.setRequestId(requestId);
        }
        return requestId;
    }

    public void setRequestId(long requestId) {
        if (null != this.header) {
            this.header.setRequestId(requestId);
        }
    }

    /**
     * create the remote header
     */
    private static Header createHeader(int code, long requestId, int commandType) {
        Header hdr = new Header();
        hdr.setCode(code);
        hdr.setRemotingType(commandType);
        hdr.setRequestId(requestId);
        hdr.setLanguageCode(LanguageCode.JAVA.getCode());
        hdr.setVersion(Version.V0.getVersion());
        CommandFlagUtils.setCompressType(hdr, CompressType.NONE);
        CommandFlagUtils.setSerializeType(hdr, SerializeType.JSON);
        CommandFlagUtils.setEncyptType(hdr, EncryptType.NONE);
        return hdr;
    }

    /**
     * create the response message
     *
     * @param code      the response code
     * @param requestId the request id of this response
     * @return the response message
     */
    public static BinaryMessage createResponseCommand(int code, byte[] body, int requestId) {
        BinaryMessage message = createResponseCommand(code, requestId);
        message.body = body;
        return message;
    }


    public static BinaryMessage createPingCommand() {
        return createRequestCommand(RequestCode.HEARTBEAT_PING,Constants.PING_MESSAGE.getBytes());
    }


    public static BinaryMessage createPongCommand(int requestId){
        BinaryMessage message = createResponseCommand(ResponseCode.HEARTBEAT_PONG, requestId);
        message.body = Constants.PONG_MESSAGE.getBytes();
        return message;
    }


    public void markResponseType() {
        int remotingType = this.header.getRemotingType();
        this.header.setRemotingType(remotingType | MessageType.RESPONSE.getType());
    }

    public boolean isResponseType() {
        //第0位代表是否为request/response,因此只需要获取第0位的值
        int remotingType = this.header.getRemotingType() & 1;
        return remotingType == MessageType.RESPONSE.getType();
    }

    public void markOnewayRPC() {
        int remotingType = header.getRemotingType();
        header.setRemotingType(remotingType|(1<<Header.RPC_ONEWAY));
    }

    public boolean isOnewayRPC() {
        int remotingType = header.getRemotingType();
        int rpcOneWay = 1 << Header.RPC_ONEWAY;
        return (remotingType & rpcOneWay) == rpcOneWay;
    }

    public int getCode() {
        return this.header.getCode();
    }

    public void setCode(int code) {
        this.header.setCode(code);
    }

    public MessageType getType() {
        if (this.isResponseType()) {
            return MessageType.RESPONSE;
        }
        return MessageType.REQUEST;
    }

    public byte[] getBody() {
        return this.body;
    }

    public void setBody(byte[] body) {
        if (null != body && body.length > Constants.DEFAULT_COMPRESS_LENGTH) {
            CommandFlagUtils.setCompressType(header, CompressType.QUICK_LZ);
            Compress compress = CompressFactory.createCompress(CommandFlagUtils.getCompressType(this.header));
            if (null != compress) {
                this.body = compress.compress(body);
            }
        } else {
            this.body = body;
        }
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }


    public int getPacketLength() {
        return packetLength;
    }

    public void setPacketLength(int packetLength) {
        this.packetLength = packetLength;
    }

    public int getHeaderLength() {
        return headerLength;
    }

    public void setHeaderLength(int headerLength) {
        this.headerLength = headerLength;
    }

    @Override
    public String toString() {
        return "WebSocketCommand{" +
                "header=" + header +
                ", headerLength=" + headerLength +
                ", packetLength=" + packetLength +
                '}';
    }
}
