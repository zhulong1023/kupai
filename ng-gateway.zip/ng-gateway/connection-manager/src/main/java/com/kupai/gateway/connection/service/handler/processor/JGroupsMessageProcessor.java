/**
 * 
 */
package com.kupai.gateway.connection.service.handler.processor;

import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.connection.protocol.Command;

/**
 * @author zhouqisheng
 * 2017年3月28日
 */
public interface JGroupsMessageProcessor {
    
    /**
     * 处理jgroups消息
     * @param jmsg
     * @return
     */
    Command<?> process(JGroupMessage jmsg);

}
