/**
 * 
 */
package com.kupai.gateway.connection.netty.handler;

import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kupai.gateway.connection.netty.NettyEvent;
import com.kupai.gateway.connection.netty.NettyEventType;
import com.kupai.gateway.connection.netty.NettyServerConfig;
import com.kupai.gateway.connection.netty.PingPongEvent;
import com.kupai.gateway.connection.remoting.ChannelEventListener;
import com.kupai.gateway.connection.remoting.RemotingHelper;
import com.kupai.gateway.connection.remoting.RemotingUtil;

import io.netty.channel.Channel;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;

/**
 * @author zhouqisheng
 * 2017年4月12日
 */
@Sharable
public class NettyConnectManageHandler extends ChannelDuplexHandler {
    private static final Logger log = LoggerFactory.getLogger(NettyConnectManageHandler.class);
    /**
     * the total connection number of the config server
     */
    private final AtomicInteger totalConnectionNumber;
    private NettyServerConfig nettyServerConfig;
    private ChannelEventListener channelEventListener;
    
    public NettyConnectManageHandler(NettyServerConfig nettyServerConfig, ChannelEventListener channelEventListener, AtomicInteger totalConnectionNumber) {
        super();
        this.nettyServerConfig = nettyServerConfig;
        this.channelEventListener = channelEventListener;
        this.totalConnectionNumber = totalConnectionNumber;
    }

    @Override
    public void channelRegistered(ChannelHandlerContext ctx) throws Exception {
        final String remoteAddress = RemotingHelper.parseChannelRemoteAddress(ctx.channel());
        log.info("NettyConnectManageHandler channelRegistered {}", remoteAddress);
        super.channelRegistered(ctx);
        
        if (channelEventListener != null) {
            channelEventListener.onChannelConnect(new NettyEvent(
                    NettyEventType.CONNECT, remoteAddress, ctx
                    .channel(), null));
        }
    }

    @Override
    public void channelUnregistered(ChannelHandlerContext ctx) throws Exception {
        final String remoteAddress = RemotingHelper.parseChannelRemoteAddress(ctx.channel());
        log.info("NettyConnectManageHandler channelUnregistered, the channel {}", remoteAddress);
        super.channelUnregistered(ctx);
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        int connectionCount = totalConnectionNumber.incrementAndGet();
        String channelId = RemotingHelper.getChannelId(ctx.channel());
        if (connectionCount > nettyServerConfig.getServerMaxConnectionNumbers()) {
            //close the channel
            RemotingUtil.closeChannel(ctx.channel());
            //throw an runtime exception
            throw new RuntimeException(String.format("channel connection exceeds the max_connection_number %s. close the channel %s", nettyServerConfig.getServerMaxConnectionNumbers(), channelId));
        }
        log.info(String.format("channel %s is connected to server. the total connection count is %s", channelId, connectionCount));

        final String remoteAddress = RemotingHelper.parseChannelRemoteAddress(ctx.channel());
        log.info("NettyConnectManageHandler channelActive, the channel {}", remoteAddress);
        super.channelActive(ctx);

        if (channelEventListener != null) {
            channelEventListener.onChannelActive(new NettyEvent(
                    NettyEventType.ACTIVE, remoteAddress, ctx
                    .channel(), null));
        }
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        final String remoteAddress = RemotingHelper.parseChannelRemoteAddress(ctx.channel());
        log.info("NettyConnectManageHandler channelInactive, the channel {}", remoteAddress);
        super.channelInactive(ctx);
        decrementConnection(ctx.channel());
        if (channelEventListener != null) {
            channelEventListener.onChannelClose(new NettyEvent(
                    NettyEventType.CLOSE, remoteAddress, ctx
                    .channel(), null));
        }
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent event = (IdleStateEvent) evt;
            if (event.state().equals(IdleState.ALL_IDLE)) {
                final String remoteAddress = RemotingHelper
                        .parseChannelRemoteAddress(ctx.channel());
                log.warn("NettyConnectManageHandler IDLE exception {}",
                        remoteAddress);
                if (channelEventListener != null) {
                    channelEventListener.onChannelIdle(new NettyEvent(
                            NettyEventType.IDLE, remoteAddress,
                            ctx.channel(), null));
                }
            }
        } else if (evt instanceof PingPongEvent){
            final String remoteAddress = RemotingHelper
                    .parseChannelRemoteAddress(ctx.channel());
            if (channelEventListener != null) {
                channelEventListener.onChannelHeartbeat(new NettyEvent(
                        evt == PingPongEvent.PING ? NettyEventType.PING : NettyEventType.PONG
                                , remoteAddress,
                        ctx.channel(), null));
            }
        }

        ctx.fireUserEventTriggered(evt);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        final String remoteAddress = RemotingHelper
                .parseChannelRemoteAddress(ctx.channel());
        log.warn("NettyConnectManageHandler exceptionCaught remoteAddress {} exception {}.", remoteAddress, cause);

        if (channelEventListener != null) {
            channelEventListener.onChannelException(new NettyEvent(
                    NettyEventType.EXCEPTION, remoteAddress, ctx
                    .channel(), cause));
        }
    }

    private void decrementConnection(Channel channel) {
        int connectionCount = totalConnectionNumber.decrementAndGet();
        //reset the connection number
        if (totalConnectionNumber.get() < 0) {
            totalConnectionNumber.set(0);
        }
        log.info(String.format("channel %s is closed from server. the total connection count is %s", RemotingHelper.getChannelId(channel), connectionCount));
    }

}
