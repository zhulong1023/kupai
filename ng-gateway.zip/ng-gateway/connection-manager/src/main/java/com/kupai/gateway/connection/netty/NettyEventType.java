package com.kupai.gateway.connection.netty;

/**
 * Date: 16/12/25
 * Time: 下午3:17
 *
 * @author lintc
 */
public enum NettyEventType {
    CONNECT, CLOSE, IDLE, EXCEPTION, ACTIVE, PING, PONG;
}
