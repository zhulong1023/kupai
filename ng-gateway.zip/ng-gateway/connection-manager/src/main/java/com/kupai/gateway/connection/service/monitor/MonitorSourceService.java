package com.kupai.gateway.connection.service.monitor;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.util.DateUtils;
import com.kupai.gateway.connection.domain.ProtocolType;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.service.session.SessionService;
import com.kupai.gateway.connection.util.Constants;

/**
 * 用于对session来源进行监控
 * Created by Administrator on 2017/3/25.
 */
@Service
public class MonitorSourceService {

    @Autowired
    private SessionService sessionService;

    /**
     * 获得所有的
     *
     * @return
     */
    public String getAllSource() {
        JSONArray jsonArray = new JSONArray();
        Map<Integer, Map<Long, Map<Integer, Session>>> sourceUserSessionMap = sessionService.getUserSessionMap();
        Set<Integer> sourceSet = sourceUserSessionMap.keySet();
        Iterator<Integer> iterator = sourceSet.iterator();
        while (iterator.hasNext()) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("source", iterator.next());
            jsonObject.put("counter", sourceUserSessionMap.get(iterator.next()).size());
            jsonArray.add(jsonObject);
        }
        return jsonArray.toJSONString();
    }

    /**
     * 根据source获得来源的所有的在线的uid
     *
     * @param source
     * @return
     */
    public String getOnlineUsersBySource(Integer source) {
        JSONArray jsonArray = new JSONArray();
        Map<Integer, Map<Long, Map<Integer, Session>>> allSourceUserSessionMap = sessionService.getUserSessionMap();
        Map<Long, Map<Integer, Session>> sourceUserSessionMap = allSourceUserSessionMap.get(source);
        if (null != sourceUserSessionMap && sourceUserSessionMap.size() > 0) {
            int totalSize = sourceUserSessionMap.size();
            for (Map.Entry<Long, Map<Integer, Session>> entry : sourceUserSessionMap.entrySet()) {
                Long uid = entry.getKey();
                Session userSession = entry.getValue().get(0);
                //每个房间的某个具体用户的session信息
                JSONObject sessionJsonObject = new JSONObject();
                //系统来源
                sessionJsonObject.put("source", userSession.getSource());
                //用户ID
                sessionJsonObject.put("userId", uid);
                //用户连接创立时间
                String connectionTime = DateUtils.long2String(userSession.getConnectionCreatedTime(), Constants.DATE_FORMAT_YYYYMMDDHHMMSS);
                sessionJsonObject.put("createdTime", connectionTime);
                //用户在线时长(s)
                sessionJsonObject.put("onlineTime", (System.currentTimeMillis() - userSession.getConnectionCreatedTime()) / 1000);
                //协议类型
                sessionJsonObject.put("protocolType", ProtocolType.parser(userSession.getProtocolType().intValue()).getDesc());
                //clientType
                sessionJsonObject.put("clientType", userSession.getClientType());
                //角色
                sessionJsonObject.put("role", Session.RoleEnum.valueOf(userSession.getRole()).getDesc());
                jsonArray.add(sessionJsonObject);
            }
        }
        return jsonArray.toJSONString();
    }
}
