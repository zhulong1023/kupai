package com.kupai.gateway.connection.remoting;

import com.kupai.gateway.connection.exception.RemotingSendRequestException;
import com.kupai.gateway.connection.exception.RemotingTimeoutException;
import com.kupai.gateway.connection.exception.RemotingTooMuchRequestException;
import com.kupai.gateway.connection.protocol.Command;

import io.netty.channel.Channel;

/**
 * Date: 16/12/25
 * Time: 下午3:05
 *
 * @author lintc
 */
public interface RemotingServer extends RemotingService {
    int localPort();

    Command<?> invokeSync(final Channel channel, final Command<?> request, final long timeoutMillis) throws InterruptedException, RemotingSendRequestException, RemotingTimeoutException;

    void invokeAsync(Channel channel, Command<?> request, long timeoutMillis, InvokeCallback invokeCallback) throws InterruptedException, RemotingTooMuchRequestException, RemotingTimeoutException, RemotingSendRequestException;

    void invokeOneway(final Channel channel, final Command<?> request, final long timeoutMillis) throws InterruptedException, RemotingTooMuchRequestException, RemotingTimeoutException, RemotingSendRequestException;

}
