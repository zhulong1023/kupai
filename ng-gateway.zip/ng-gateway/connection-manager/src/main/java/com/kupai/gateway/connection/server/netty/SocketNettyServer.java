package com.kupai.gateway.connection.server.netty;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.util.StatisticsLog;
import com.kupai.gateway.common.util.ThreadFactoryImpl;
import com.kupai.gateway.connection.netty.NettyRemotingServer;
import com.kupai.gateway.connection.netty.NettyServerConfig;
import com.kupai.gateway.connection.remoting.ChannelEventListener;
import com.kupai.gateway.connection.remoting.RequestProcessor;
import com.kupai.gateway.connection.util.Constants;

/**
 * 基于netty实现的自定义二进制传输协议消息网关服务器
 * Date: 16/12/25
 * Time: 下午3:49
 *
 * @author lintc
 */
@Service("socketNettyServer")
public class SocketNettyServer{
    @Resource(name = "defaultRequestProcessor")
    private RequestProcessor defaultRequestProcessor;
    @Resource(name = "authRequestProcessor")
    private RequestProcessor authRequestProcessor;
    @Resource(name = "inOutRoomRequestProcessor")
    private RequestProcessor inOutRoomRequestProcessor;
    @Resource(name = "appStateRequestProcessor")
    private RequestProcessor appStateRequestProcessor;

    @Autowired
    private ChannelEventListener nettyChannelEventListener;
    @Value("${netty.socket.port}")
    private int port;
    @Value("${netty.socket.ssl.port}")
    private int sslPort;

    @PostConstruct
    public void start() {
        NettyServerConfig nettyServerConfig = new NettyServerConfig();
        if(port > 0){
            nettyServerConfig.setListenPort(port);
            NettyRemotingServer remotingServer = new NettyRemotingServer(nettyServerConfig, nettyChannelEventListener);
            //limit the max queue size of the thread pool
            ExecutorService remoteExecutor = new ThreadPoolExecutor(nettyServerConfig.getServerWorkerThreads(),
                    nettyServerConfig.getServerWorkerThreads(), 0L, TimeUnit.MILLISECONDS,
                    new LinkedBlockingQueue<>(Constants.DEFAULT_MAX_QUEUE_ITEM), new ThreadFactoryImpl("SocketServerExecutorThread-"));
            StatisticsLog.registerExecutor("socket-request-pool", (ThreadPoolExecutor) remoteExecutor);
            
            remotingServer.registerDefaultProcessor(defaultRequestProcessor, remoteExecutor);
            remotingServer.registerProcessor(RequestCode.AUTH, authRequestProcessor, remoteExecutor);
            remotingServer.registerProcessor(RequestCode.ROOM, inOutRoomRequestProcessor, remoteExecutor);
            remotingServer.registerProcessor(RequestCode.APP_STATE, appStateRequestProcessor, remoteExecutor);
            remotingServer.start();
        }
        
        if(sslPort > 0){
            nettyServerConfig.setSslListenPort(sslPort);
            nettyServerConfig.setSslSupport(true);
            NettyRemotingServer remotingSSLServer = new NettyRemotingServer(nettyServerConfig, nettyChannelEventListener);
            //limit the max queue size of the thread pool
            ExecutorService remoteExecutor = new ThreadPoolExecutor(nettyServerConfig.getServerWorkerThreads(),
                    nettyServerConfig.getServerWorkerThreads(), 0L, TimeUnit.MILLISECONDS,
                    new LinkedBlockingQueue<>(Constants.DEFAULT_MAX_QUEUE_ITEM), new ThreadFactoryImpl("SocketSSLServerExecutorThread-"));
            StatisticsLog.registerExecutor("socketSSL-request-pool", (ThreadPoolExecutor) remoteExecutor);
            
            remotingSSLServer.registerDefaultProcessor(defaultRequestProcessor, remoteExecutor);
            remotingSSLServer.registerProcessor(RequestCode.AUTH, authRequestProcessor, remoteExecutor);
            remotingSSLServer.registerProcessor(RequestCode.ROOM, inOutRoomRequestProcessor, remoteExecutor);
            remotingSSLServer.registerProcessor(RequestCode.APP_STATE, appStateRequestProcessor, remoteExecutor);
            remotingSSLServer.start();
        }
    }
}
