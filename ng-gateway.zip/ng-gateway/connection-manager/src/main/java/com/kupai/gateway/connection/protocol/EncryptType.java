package com.kupai.gateway.connection.protocol;

/**
 * Date: 16/12/25
 * Time: 下午1:45
 *
 * @author lintc
 */
public enum EncryptType {
    NONE(0),
    AES(1),
    DES(2),
    RSA(3);
    private int type;

    EncryptType(int type) {
        this.type = type;
    }

    public int getType() {
        return this.type;
    }

    public static EncryptType getEncryptType(int type) {
        switch (type) {
            case 0:
                return NONE;
            case 1:
                return DES;
            case 2:
                return RSA;
            default:
                return NONE;
        }
    }
}
