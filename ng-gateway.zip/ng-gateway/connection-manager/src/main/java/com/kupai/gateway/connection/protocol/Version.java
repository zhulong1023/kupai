package com.kupai.gateway.connection.protocol;

/**
 * Date: 16/12/25
 * Time: 下午1:48
 *
 * @author lintc
 */
public enum Version {
    V0(0, "the first version");
    private int version;
    private String description;

    Version(int version, String description) {
        this.version = version;
        this.description = description;
    }

    public int getVersion() {
        return this.version;
    }

    @Override
    public String toString() {
        return "Version{" +
                "version=" + version +
                ", description='" + description + '\'' +
                '}';
    }
}
