package com.kupai.gateway.connection.exception;

/**
 * Date: 16/12/25
 * Time: 下午3:09
 *
 * @author lintc
 */
public class RemotingConnectException extends RemotingException {
    private static final long serialVersionUID = -5565366231695911316L;

    public RemotingConnectException(String address) {
        this(address, null);
    }

    public RemotingConnectException(String address, Throwable cause) {
        super("connect to <" + address + "> failed", cause);
    }
}
