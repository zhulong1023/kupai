package com.kupai.gateway.connection.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.netty.NettyEvent;
import com.kupai.gateway.connection.netty.NettyEventType;
import com.kupai.gateway.connection.remoting.ChannelEventListener;
import com.kupai.gateway.connection.service.session.SessionService;
import com.kupai.gateway.connection.util.Constants;

import io.netty.util.Attribute;

/**
 * Created by lintc on 17/1/13.
 */
@Service("nettyChannelEventListener")
public class NettyChannelEventListener implements ChannelEventListener {
    private Logger log = LoggerFactory.getLogger(getClass());
    @Autowired
    private SessionService sessionService;

    @Override
    public void onChannelConnect(NettyEvent event) {
        event.getChannel().attr(Constants.LAST_ACTIVE_TIME_ATTR_KEY).set(System.currentTimeMillis());
        sessionService.addNewConnection(event.getChannel());
    }

    @Override
    public void onChannelClose(NettyEvent event) {
        Session session = sessionService.getSessionByChannel(event.getChannel());
        if (null != session) {
            log.info("channelClose event  session={}", session);
            sessionService.removeSession(session);
        }
    }

    @Override
    public void onChannelException(NettyEvent event) {

    }

    @Override
    public void onChannelIdle(NettyEvent event) {

    }

    @Override
    public void onChannelActive(NettyEvent event) {

    }

    @Override
    public void onChannelHeartbeat(NettyEvent event) {
        try {
            Session session = sessionService.getSessionByChannel(event.getChannel());
            if (session != null) {
                Attribute<Long> lastActiveTime = event.getChannel().attr(Constants.LAST_ACTIVE_TIME_ATTR_KEY);
                lastActiveTime.set(System.currentTimeMillis());
                if (event.getType() == NettyEventType.PING) {
                    log.info("ping event  session={}", session);
                } else {
                    session.onPongEvent();
                    log.info("pong event  session={}", session);
                }
            } else {
                log.info("ping-pong event {}，  but can not find session", event);
            }
        } catch (Exception e) {
            log.error("process message error", e);
        }
        
    }
}
