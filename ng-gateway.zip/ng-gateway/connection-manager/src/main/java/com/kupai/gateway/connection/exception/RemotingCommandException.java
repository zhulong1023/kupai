package com.kupai.gateway.connection.exception;

/**
 * Date: 16/12/25
 * Time: 下午1:57
 *
 * @author lintc
 */
public class RemotingCommandException extends RemotingException {
    private static final long serialVersionUID = -6061365915274953096L;

    public RemotingCommandException(String message) {
        super(message, null);
    }

    public RemotingCommandException(String message, Throwable cause) {
        super(message, cause);
    }
}
