package com.kupai.gateway.connection.exception;

/**
 * Date: 16/12/25
 * Time: 下午3:07
 *
 * @author lintc
 */
public class RemotingTimeoutException extends RemotingException {

    private static final long serialVersionUID = 4106899185095245979L;

    public RemotingTimeoutException(String message) {
        super(message);
    }

    public RemotingTimeoutException(String address, long timeoutMillis) {
        this(address, timeoutMillis, null);
    }

    public RemotingTimeoutException(String address, long timeoutMillis,
                                    Throwable cause) {
        super("wait response on the channel <" + address + "> timeout, "
                + timeoutMillis + "(ms)", cause);
    }
}
