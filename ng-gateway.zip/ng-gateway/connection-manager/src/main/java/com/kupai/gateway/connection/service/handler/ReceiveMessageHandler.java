package com.kupai.gateway.connection.service.handler;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.data.DataMeta;
import com.kupai.gateway.common.data.Media;
import com.kupai.gateway.common.data.Syc;
import com.kupai.gateway.common.data.Text;
import com.kupai.gateway.common.data.enumpac.ChatTypeEnum;
import com.kupai.gateway.common.data.enumpac.RoleEnum;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.JGroupsMessageHandler;
import com.kupai.gateway.common.registry.AbstractRegistry;
import com.kupai.gateway.common.unread.UnReadNumService;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.service.MessageDispatchService;
import com.kupai.gateway.connection.service.handler.processor.JGroupsMessageProcessor;
import com.kupai.gateway.connection.service.monitor.MonitorService;
import com.kupai.gateway.connection.service.session.SessionRoomService;
import com.kupai.gateway.connection.service.session.SessionService;

/**
 * 处理从connection-manager中获取的消息
 * Created by Administrator on 2017/3/21.
 */
@Service("jgroupsMessageHandler")
public class ReceiveMessageHandler extends AbstractRegistry<JGroupsMessageProcessor> implements JGroupsMessageHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReceiveMessageHandler.class);

    @Autowired
    private MessageDispatchService messageDispatchService;
    @Autowired
    private MonitorService monitorService;
    @Autowired
    private SessionService sessionService;
    @Autowired
    private SessionRoomService sessionRoomService;
    @Resource(name = "defaultJGroupsMessageProcessor")
    private JGroupsMessageProcessor defaultProcessor;

    private AtomicLong requestId = new AtomicLong(0L);

    @Autowired
    private UnReadNumService unReadNumService;

    /**
     * 对jgroups中接收到的消息进行处理
     * 在cm中只接受来自rm的群发消息
     *
     * @param jGroupMessage
     */
    @Override
    public void messageHandler(JGroupMessage jGroupMessage) {
        LOGGER.info("receive message info:" + jGroupMessage);
        monitorService.incrementJgroupReceiveMessage();

        try {
            Command<?> msg = null;
            TreeMap<Integer, JGroupsMessageProcessor> processors = this.registrants.get(jGroupMessage.getCode());
            if (processors == null) {
                msg = this.defaultProcessor.process(jGroupMessage);
            } else {
                msg = processors.firstEntry().getValue().process(jGroupMessage);
            }

            if (msg == null) {
                return;
            }

            //分发消息
            dispatchMessage(jGroupMessage, msg);

            //处理at消息
            dispatchAtMessage(jGroupMessage);

        } catch (Exception ex) {
            LOGGER.error("jgroup node receive message failed. content {}", jGroupMessage, ex);
        }
    }

    /**
     * 分发消息
     *
     * @param jGroupMessage
     * @param msg
     */
    private void dispatchMessage(JGroupMessage jGroupMessage, Command<?> msg) {
        int messageType = jGroupMessage.getSendType();
        if (JGroupMessage.SendType.MULTI == JGroupMessage.SendType.getSendType(messageType)) {//群发消息
            if (jGroupMessage.getRoomId() != null) {//发送给某个房间
                //判断发送消息用户是否在房间内，如果没有则自动加入房间
                if ((jGroupMessage.getCode() == RequestCode.MSG_MEDIA || jGroupMessage.getCode() == RequestCode.MSG_TEXT || jGroupMessage.getCode() == RequestCode.SYC)
                        && jGroupMessage.getFrom() > 0 && jGroupMessage.getClientType() != -1) {
                    Session session = sessionService.getOnlineUsersByUid(jGroupMessage.getSource(), jGroupMessage.getFrom(), jGroupMessage.getClientType());
                    if (session != null) {
                        Long roomId = sessionRoomService.getRoomIdBySession(session);
                        if (roomId == null || roomId.longValue() != jGroupMessage.getRoomId().longValue()) {
                            sessionRoomService.addSessionToRoom(session, jGroupMessage.getRoomId());
                        }
                    }
                }
                //发送给房间内用户
                Map<Long, Set<Session>> roomUserSessionMap = sessionRoomService.getOnlineUsersByRoomId(jGroupMessage.getRoomId());
                for (Entry<Long, Set<Session>> entry : roomUserSessionMap.entrySet()) {
                    for (Session session : entry.getValue()) {
                        //发送syc消息
                        Command<?> reMmsg = this.sycNotice(msg, session.getUid(), jGroupMessage.getMsgId());
                        messageDispatchService.forwardToClient(session, reMmsg);
                    }
                }

                //发送给主持人后台
                if (msg.getCode() == RequestCode.MSG_TEXT || msg.getCode() == RequestCode.MSG_MEDIA) {
                    Set<Session> roleSet = this.sessionService.getRoleSession(jGroupMessage.getSource(), RoleEnum.OBSERVER.getValue());
                    for (Session session : roleSet) {
                        Long roomId = this.sessionRoomService.getRoomIdBySession(session);
                        if (roomId == null || roomId.longValue() == jGroupMessage.getRoomId().longValue()) {
                            messageDispatchService.forwardToClient(session, msg);
                        }
                    }
                }

            } else if (jGroupMessage.getToUid() != null) {//发送给多个用户
                //发消息给客户端
                for (long uid : jGroupMessage.getToUid()) {
                    Map<Integer, Session> clientSessionMap = sessionService.getOnlineUsersByUid(jGroupMessage.getSource(), uid);
                    if (clientSessionMap != null) {
                        for (Session session : clientSessionMap.values()) {
                            //发送syc消息
                            Command<?> reMmsg = this.sycNotice(msg, session.getUid(), jGroupMessage.getMsgId());
                            messageDispatchService.forwardToClient(session, reMmsg);
                        }
                    }
                }
            } else {//发送给所有在线用户
                Map<Long, Map<Integer, Session>> userSessionMap = sessionService.getOnlineUsersBySource(jGroupMessage.getSource());
                for (Entry<Long, Map<Integer, Session>> entry : userSessionMap.entrySet()) {
                    for (Session session : entry.getValue().values()) {
                        //发送syc消息
                        Command<?> reMmsg = this.sycNotice(msg, session.getUid(), jGroupMessage.getMsgId());
                        messageDispatchService.forwardToClient(session, reMmsg);
                    }
                }
            }
        } else {//发送给指定某个人，点对点发送
            for (long uid : jGroupMessage.getToUid()) {
                Map<Integer, Session> sessionMap = sessionService.getOnlineUsersByUid(jGroupMessage.getSource(), uid);
                if (sessionMap != null && sessionMap.size() > 0) {
                    for (Session session : sessionMap.values()) {
                        if (session.getSource().intValue() == jGroupMessage.getSource().intValue()) {
                            //发送syc消息
                            Command<?> reMmsg = this.sycNotice(msg, session.getUid(), jGroupMessage.getMsgId());
                            messageDispatchService.forwardToClient(session, reMmsg);
                        }
                    }
                }
            }
        }
    }


    /**
     * 组装syc通知
     */
    private Command<?> sycNotice(Command<?> msg, long uid, long messageId) {
        //发送syc消息
        if (msg.getCode() == RequestCode.MSG_MEDIA || msg.getCode() == RequestCode.MSG_TEXT) {

            DataMeta dataMeta = null;
            if (msg.getCode() == RequestCode.MSG_TEXT) {
                Text text = (Text) msg.getData();
                dataMeta = text.getMeta();
            } else {
                Media media = (Media) msg.getData();
                dataMeta = media.getMeta();
            }
            DataMeta sycMeta = new DataMeta();
            String sessionId = "";
            if (dataMeta.getChatType() == ChatTypeEnum.ROOM.getType()) {
                sessionId = String.valueOf(dataMeta.getTo());
                sycMeta.setFrom(dataMeta.getTo()); //从哪里来的通知 由系统发出
            } else if (dataMeta.getChatType() == ChatTypeEnum.SINGLE.getType()) {
                sessionId = String.valueOf(dataMeta.getFrom() >= dataMeta.getTo() ? dataMeta.getFrom() + "_" + dataMeta.getTo() : dataMeta.getTo() + "_" + dataMeta.getFrom());
                long fromUid = dataMeta.getFrom();
                if (fromUid == uid) {
                    fromUid = dataMeta.getTo();
                }
                sycMeta.setFrom(fromUid); //从哪里来的通知 由系统发出
            }
            //组装syc的notice元信息
            Syc responseSyc = new Syc();
            sycMeta.setTo(uid);                //给谁的通知，用户uid
            sycMeta.setEvent("syc_notice");
            sycMeta.setCode(RequestCode.SYC);
            sycMeta.setChatType(dataMeta.getChatType());

            //设置到syc对象中
            responseSyc.setMeta(sycMeta);
            responseSyc.setMessageId(String.valueOf(messageId));
            responseSyc.setUnReadNum(unReadNumService.getUnReadNum(sessionId, String.valueOf(uid)));

            Command<?> command = new Command<>(RequestCode.SYC, responseSyc, msg.getRequestId());
            command.setOneway(msg.getOneway());
            return command;
        }
        return msg;
    }

    /**
     * 处理at动作
     *
     * @param jGroupMessage
     */
    private void dispatchAtMessage(JGroupMessage jGroupMessage) {
        if (jGroupMessage.getAtUid() != null && (jGroupMessage.getCode() == RequestCode.MSG_MEDIA || jGroupMessage.getCode() == RequestCode.MSG_TEXT)) {
            DataMeta dataMeta = null;
            if (jGroupMessage.getCode() == RequestCode.MSG_TEXT) {
                Text text = (Text) jGroupMessage.getData();
                dataMeta = text.getMeta();
            } else {
                Media media = (Media) jGroupMessage.getData();
                dataMeta = media.getMeta();
            }
            DataMeta meta = new DataMeta();
            meta.setChatType(dataMeta.getChatType());
            if (dataMeta.getChatType() == ChatTypeEnum.ROOM.getType()) {
                meta.setFrom(jGroupMessage.getRoomId());
            } else {
                meta.setFrom(jGroupMessage.getFrom());
            }

            meta.setType(DataMeta.Type.AT.getValue());
            meta.setEvent(DataMeta.Event.AT.getValue());
            meta.setCode(RequestCode.MSG_NOTICE);
            meta.setExt(dataMeta.getExt());

            com.kupai.gateway.common.data.Command data = new com.kupai.gateway.common.data.Command();
            data.setMeta(meta);
            data.setContent(jGroupMessage.getFrom());

            Command<?> msg = new Command<>(RequestCode.MSG_NOTICE, data, requestId.incrementAndGet());
            msg.markOneway();

            for (long uid : jGroupMessage.getAtUid()) {
                Map<Integer, Session> sessionMap = sessionService.getOnlineUsersByUid(jGroupMessage.getSource(), uid);
                if (sessionMap != null && sessionMap.size() > 0) {
                    for (Session session : sessionMap.values()) {
                        meta.setTo(uid);
                        messageDispatchService.forwardToClient(session, msg);
                    }
                }
            }
        }
    }
}
