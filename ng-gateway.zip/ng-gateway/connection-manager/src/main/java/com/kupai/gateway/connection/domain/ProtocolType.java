package com.kupai.gateway.connection.domain;

/**
 * 协议类型
 * Created by Administrator on 2017/3/25.
 */
public enum ProtocolType {
    TCP(1, "TCP"),
    WS(2, "WS");

    private int type;
    private String desc;

    ProtocolType(int type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    public int getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }

    public static ProtocolType parser(int type) {
        if (1 == type) {
            return TCP;
        } else if (2 == type) {
            return WS;
        } else {
            throw new IllegalArgumentException("not support protocol type " + type);
        }
    }
}
