package com.kupai.gateway.connection.exception;

/**
 * Date: 16/12/25
 * Time: 下午3:08
 *
 * @author lintc
 */
public class RemotingTooMuchRequestException extends RemotingException {
    private static final long serialVersionUID = 4326919581254519654L;

    public RemotingTooMuchRequestException(String message) {
        super(message);
    }
}