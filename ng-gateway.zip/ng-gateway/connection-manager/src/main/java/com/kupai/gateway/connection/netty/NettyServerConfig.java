package com.kupai.gateway.connection.netty;

/**
 * Date: 16/12/25
 * Time: 下午3:18
 *
 * @author lintc
 */
public class NettyServerConfig {
    private int listenPort = 8888;
    private int serverWorkerThreads = 32;
    private int serverCallbackExecutorThreads = 16;
    private int serverSelectorThreads = 3;
    private int serverChannelMaxIdleTimeSeconds = 120;
    private int serverMaxConnectionNumbers = 10*1000;
    private boolean sslSupport = false;
    private int sslListenPort = 8884;

    public int getListenPort() {
        return listenPort;
    }

    public void setListenPort(int listenPort) {
        this.listenPort = listenPort;
    }

    public int getServerWorkerThreads() {
        return serverWorkerThreads;
    }

    public void setServerWorkerThreads(int serverWorkerThreads) {
        this.serverWorkerThreads = serverWorkerThreads;
    }

    public int getServerSelectorThreads() {
        return serverSelectorThreads;
    }

    public void setServerSelectorThreads(int serverSelectorThreads) {
        this.serverSelectorThreads = serverSelectorThreads;
    }

    public int getServerCallbackExecutorThreads() {
        return serverCallbackExecutorThreads;
    }

    public void setServerCallbackExecutorThreads(
            int serverCallbackExecutorThreads) {
        this.serverCallbackExecutorThreads = serverCallbackExecutorThreads;
    }

    public int getServerChannelMaxIdleTimeSeconds() {
        return serverChannelMaxIdleTimeSeconds;
    }

    public void setServerChannelMaxIdleTimeSeconds(
            int serverChannelMaxIdleTimeSeconds) {
        this.serverChannelMaxIdleTimeSeconds = serverChannelMaxIdleTimeSeconds;
    }

    public int getServerMaxConnectionNumbers() {
        return serverMaxConnectionNumbers;
    }

    public void setServerMaxConnectionNumbers(int serverMaxConnectionNumbers) {
        this.serverMaxConnectionNumbers = serverMaxConnectionNumbers;
    }

    public boolean isSslSupport() {
        return sslSupport;
    }

    public void setSslSupport(boolean sslSupport) {
        this.sslSupport = sslSupport;
    }

    public int getSslListenPort() {
        return sslListenPort;
    }

    public void setSslListenPort(int sslListenPort) {
        this.sslListenPort = sslListenPort;
    }
}
