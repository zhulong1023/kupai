package com.kupai.gateway.connection.exception;

/**
 * Date: 16/12/25
 * Time: 下午3:09
 *
 * @author lintc
 */
public class RemotingSendRequestException extends RemotingException {
    private static final long serialVersionUID = 5391285827332471674L;


    public RemotingSendRequestException(String address) {
        this(address, null);
    }


    public RemotingSendRequestException(String address, Throwable cause) {
        super("send request to <" + address + "> failed", cause);
    }
}