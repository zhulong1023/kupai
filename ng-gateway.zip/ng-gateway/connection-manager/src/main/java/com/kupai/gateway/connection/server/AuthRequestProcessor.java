/**
 * 
 */
package com.kupai.gateway.connection.server;

import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.contants.MessageType;
import com.kupai.gateway.common.contants.KeyRepertory;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.common.data.Authorization;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.model.SourceConfig;
import com.kupai.gateway.common.retrofit.ServiceGenerator;
import com.kupai.gateway.connection.domain.Session;
import com.kupai.gateway.connection.protocol.Command;
import com.kupai.gateway.connection.remoting.RemotingProcessor;
import com.kupai.gateway.connection.remoting.RequestProcessor;
import com.kupai.gateway.connection.service.MessageDispatchService;
import com.kupai.gateway.connection.service.httpClient.AuthVerify;
import com.kupai.gateway.connection.service.session.SessionService;

import io.netty.channel.ChannelHandlerContext;
import redis.clients.jedis.JedisCluster;
import retrofit2.Call;

/**
 * @author zhouqisheng
 * 2017年3月29日
 */
@Component("authRequestProcessor")
public class AuthRequestProcessor implements RequestProcessor {
    private Logger log = LoggerFactory.getLogger(getClass());
    
    @Autowired
    private SessionService sessionService;
    @Autowired
    private MessageDispatchService messageDispatchService;
    @Autowired
    private JedisCluster jedisCluster;
    

    /* (non-Javadoc)
     * @see com.kupai.gateway.connection.remoting.RequestProcessor#processRequest(io.netty.channel.ChannelHandlerContext, com.kupai.gateway.connection.protocol.Command)
     */
    @Override
    public Command<?> processRequest(RemotingProcessor remotingProcessor, ChannelHandlerContext ctx, Command<?> request) throws Exception {
        try {
            log.info("process auth message : {}", request);
            com.kupai.gateway.common.data.Command cmd = ((JSONObject) request.getData()).toJavaObject(com.kupai.gateway.common.data.Command.class);
            Authorization auth =((JSONObject)cmd.getContent()).toJavaObject(Authorization.class);
            
            if(StringUtils.isBlank(auth.getPassport())){
                Command<String> response = new Command<String>(request.getRequestId(), ResponseCode.AUTH_FAILED, MessageType.RESPONSE.getType());
                response.setData("passport 不能为空");
                return response;
            }
            
           
            String config = jedisCluster.hget(KeyRepertory.SOURCE_CONFIG, String.valueOf(auth.getSource()));
            
            if(StringUtils.isBlank(config)){
                Command<String> response = new Command<String>(request.getRequestId(), ResponseCode.AUTH_FAILED, MessageType.RESPONSE.getType());
                response.setData("source非法");
                return response;
            }
            
            SourceConfig sourceConfig = JSON.parseObject(config, SourceConfig.class);
            
            URL callback = new URL(sourceConfig.getCallbackUrl());
            String baseUrl = callback.getProtocol() + "://" + callback.getHost();
            int port = callback.getPort();
            if(port > 0){
                baseUrl = baseUrl + ":" + port;
            }
            String path = callback.getPath();
            
            AuthVerify authVerify = ServiceGenerator.createService(AuthVerify.class, baseUrl, 2000);
            
            Call<AuthVerifyResult> verfyRet = authVerify.verify(path, auth.getPassport());
            
            AuthVerifyResult result = verfyRet.execute().body();
            if(result.getPass() <= 0){
                Command<String> response = Command.buildResponse(ResponseCode.AUTH_FAILED, "token 验证失败", request.getRequestId(), request.getVersion());
                return response;
            }
            //获取uid
            long uid = result.getUid();
            auth.setUid(uid);
            
            Session session = sessionService.getSessionByChannel(ctx.channel());
            if (session == null) {
                session = new Session(auth.getUid(), ctx.channel(), auth.getSource());
                session.setName(result.getName());
                session.setExt(result.getExt());
                session.setClientType(auth.getClientType());
                session.setRole(auth.getRole());
                session.setProtocolType(request.getProtocolType());
                session.setRemotingProcessor(remotingProcessor);
                sessionService.addSession(session);
                
                //设置新会话创建时间，用作剔除重复会话
                auth.setNewSessionCreateTime(session.getConnectionCreatedTime());
                //发送登录信息到rm，踢掉同端登录
                JGroupMessage jmsg = new JGroupMessage(JGroupMessage.SendType.P2P.getValue(), request.getCode(), session.getUid(), request.getRequestId());
                jmsg.setData(auth);
                jmsg.setSource(session.getSource());
                jmsg.setVersion(request.getVersion());
                jmsg.setClientType(session.getClientType());
                messageDispatchService.forwardToRM(session, jmsg);
            } 
            
            Command<String> response = Command.buildResponse(ResponseCode.AUTH_OK, "登录成功", request.getRequestId(), request.getVersion());
            return response;
        } catch (MalformedURLException e) {
            Command<String> response = Command.buildResponse(ResponseCode.AUTH_FAILED, "平台配置有误", request.getRequestId(), request.getVersion());
            return response;
        } catch (Exception e) {
            log.error("process message error and the code is {}" , request.getCode(), e);
            Command<String> _response = Command.buildResponse(ResponseCode.SYSTEM_ERROR, ResponseMessage.SYSTEM_ERROR, request.getRequestId(), request.getVersion());
            return  _response;
        }
    }
    
    public class AuthVerifyResult{
        private long uid;
        private String name;
        private int pass;
        private Object ext;
        
        public long getUid() {
            return uid;
        }
        public void setUid(long uid) {
            this.uid = uid;
        }
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public int getPass() {
            return pass;
        }
        public void setPass(int pass) {
            this.pass = pass;
        }
        public Object getExt() {
            return ext;
        }
        public void setExt(Object ext) {
            this.ext = ext;
        }
    }

}
