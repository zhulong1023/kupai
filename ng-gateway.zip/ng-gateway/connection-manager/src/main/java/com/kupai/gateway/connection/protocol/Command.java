package com.kupai.gateway.connection.protocol;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;
import com.kupai.gateway.common.contants.MessageType;

/**
 * the base communicating unit between client and server Date: 16/12/25 Time:
 * 下午1:36
 *
 * @author lintc
 */
public class Command<T> {
    private Long requestId;
    private int version;
    private T data;
    private int code;
    private int oneway;
    private int type;//请求还是回应
    private int priority = 0;//消息优先级默认为最低优先级
    @JSONField(serialize = false)
    private int protocolType;

    public Command() {
        super();
    }

    public Command(int code, long requestId) {
        this.code = code;
        this.requestId = requestId;
    }

    public Command(int code, T data, Long requestId) {
        super();
        this.requestId = requestId;
        this.data = data;
        this.code = code;
    }
    
    public Command(int code, T data) {
        super();
        this.code = code;
        this.data = data;
    }

    public Command(Long requestId, int code, int type) {
        super();
        this.requestId = requestId;
        this.code = code;
        this.type = type;
    }

    public int getType() {
        return this.type;
    }

    public void markResponseType() {
        this.type = MessageType.RESPONSE.getType();
    }

    public void markOneway() {
        this.oneway = 1;
    }

    public boolean isOneway() {
        return oneway == 1;
    }
    
    public static <T> Command<T> buildResponse(int code, T data, Long requestId, int version){
        Command<T> response = new Command<T>(code, data, requestId);
        response.setVersion(version);
        response.markOneway();
        response.markResponseType();
        
        return response;
    }

    @Override
    public String toString() {
        return "Message [requestId=" + requestId + ", version=" + version + ", code=" + code
                + ", oneway=" + oneway + ", type=" + type + ", data=" + JSONObject.toJSONString(data) + "]";
    }

    public Long getRequestId() {
        return requestId;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setOneway(int oneway) {
        this.oneway = oneway;
    }

    public int getOneway() {
        return oneway;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getProtocolType() {
        return protocolType;
    }

    public void setProtocolType(int protocolType) {
        this.protocolType = protocolType;
    }

}
