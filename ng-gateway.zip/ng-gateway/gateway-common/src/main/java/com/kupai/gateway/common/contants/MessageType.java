package com.kupai.gateway.common.contants;

/**
 * Date: 16/12/25 Time: 下午1:49
 *
 * @author lintc
 */
public enum MessageType {
    REQUEST(0, "request"), RESPONSE(1, "response");

    public int getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    private int type;
    private String description;

    MessageType(int type, String description) {
        this.type = type;
        this.description = description;
    }

    public static MessageType parse(int type) {
        switch (type) {
        case 0:
            return REQUEST;
        case 1:
            return RESPONSE;
        default:
            return null;
        }
    }

    @Override
    public String toString() {
        return "[type=" + type + ",desc=" + description + "]";
    }
}
