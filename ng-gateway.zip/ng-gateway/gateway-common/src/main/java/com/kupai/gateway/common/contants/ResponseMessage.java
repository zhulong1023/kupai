package com.kupai.gateway.common.contants;

/**
 * 用于给客户端返回提示信息
 * Created by Administrator on 2017/3/30.
 */
public class ResponseMessage {
    public static final String SUCCESS = "SUCCESS";
    public static final String NOT_SUPPORT_MEDIA_MESSAGE = "不支持的媒体类型文件";
    public static final String NOT_SUPPORT_CHAT_MESSAGE = "不支持的聊天类型";
    public static final String USER_IN_BLACK = "您已经被禁言";
    public static final String NOT_SUPPORT_SOURCE = "不支持的来源";

    public static final String NOT_LOGIN = "未登录";
    public static final String LOGIN_CONLICT = "用户在其他设备登录";
    public static final String SYSTEM_ERROR = "系统内部错误";
    public static final String APP_STATE_FOREGROUND = "前台运行成功";
    public static final String APP_STATE_BACKGROUND = "后台运行成功";
    public static final String ROOM_NOT_EXIST = "房间不存在";
    public static final String ROOMID_NOT_NULL = "roomId不能为空";
    public static final String TYPE_CAST_ERROR = "类型转换错误，roomId请输入数字";
}
