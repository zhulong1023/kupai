package com.kupai.gateway.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Date: 16/12/25
 * Time: 下午3:38
 *
 * @author lintc
 */
public class ThreadUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(ThreadUtils.class);

    /**
     * gracefully shutdown the ExecutorService
     *
     * @param pool the executor service that will being shutdown
     */
    public static void shutdownAndAwaitTermination(ExecutorService pool) {
        if (null != pool) {
            // Disable new tasks from being submitted
            pool.shutdown();
            try {
                // Wait a while for existing tasks to terminate
                if (!pool.awaitTermination(60, TimeUnit.SECONDS)) {
                    pool.shutdownNow(); // Cancel currently executing tasks
                    // Wait a while for tasks to respond to being cancelled
                    if (!pool.awaitTermination(60, TimeUnit.SECONDS)) {
                        LOGGER.warn(String.format("Pool %s did not terminate", pool));
                    }
                }
            } catch (InterruptedException ex) {
                // (Re-)Cancel if current thread also interrupted
                pool.shutdownNow();
                // Preserve interrupt status
                Thread.currentThread().interrupt();
            }
        }
    }

    public static void safeSleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            //ignore it
        }
    }
}
