package com.kupai.gateway.common.util;

import java.text.DecimalFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * @author zqd
 * @date 2016/3/8
 * @time 12:15
 */
public class TimeUtil {


    public static long getCurrentSeconds() {
        return TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
    }

    public static long getDailySeconds() {
        return (TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) + TimeUnit.HOURS.toSeconds(8)) % TimeUnit.DAYS.toSeconds(1);
    }


    public static long getDailyLeftSeconds() {
        return getCurrentDateEnd() - getCurrentSeconds() + 1;
    }

    public static long getMinuteLeftSeconds() {
        return (getCurrentMinuteEnd() - getCurrentSeconds()) % 60;
    }


    /**
     * 获取传入时间的23:59:59秒的long值
     *
     * @param time 秒单位
     * @return
     */
    public static long getLastTime(long time) {
        Calendar c = Calendar.getInstance();
        c.setTime(new Date(time * 1000));
        c.set(Calendar.HOUR_OF_DAY, 23);
        c.set(Calendar.MINUTE, 59);
        c.set(Calendar.SECOND, 59);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis() / 1000;
    }

    public static long getCurrentDateBegin() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis() / 1000;
    }

    public static long getCurrentDateEnd() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 23);
        c.set(Calendar.MINUTE, 59);
        c.set(Calendar.SECOND, 59);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis() / 1000;
    }

    public static long getCurrentMinuteEnd() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.MINUTE, +1);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis() / 1000;
    }

    /**
     * 获取传入时间的0:0:0秒的long值
     *
     * @param time 秒单位
     * @return
     */
    public static long getFirstTime(long time) {
        Calendar c = Calendar.getInstance();
        Date date = new Date(time * 1000);
        c.setTime(date);
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        System.out.println(month);
        int day = c.get(Calendar.DAY_OF_MONTH);
        System.out.println(day);
        c.set(year, month, day, 0, 0, 0);
        return c.getTimeInMillis() / 1000;
    }

    public static int getDaysBetween(Date startDate, Date endDate) {
        Calendar fromCalendar = Calendar.getInstance();
        fromCalendar.setTime(startDate);
        fromCalendar.set(Calendar.HOUR_OF_DAY, 0);
        fromCalendar.set(Calendar.MINUTE, 0);
        fromCalendar.set(Calendar.SECOND, 0);
        fromCalendar.set(Calendar.MILLISECOND, 0);

        Calendar toCalendar = Calendar.getInstance();
        toCalendar.setTime(endDate);
        toCalendar.set(Calendar.HOUR_OF_DAY, 0);
        toCalendar.set(Calendar.MINUTE, 0);
        toCalendar.set(Calendar.SECOND, 0);
        toCalendar.set(Calendar.MILLISECOND, 0);

        return (int)((toCalendar.getTime().getTime() - fromCalendar.getTime().getTime()) / (1000 * 60 * 60 * 24));
    }

    /**
     * 获取传入时间的0:0:0秒的long值的月份
     *
     * @param time 秒单位
     * @return
     */
    public static long getTimeMonth(long time) {
        Calendar c = Calendar.getInstance();
        Date date = new Date(time * 1000);
        c.setTime(date);
        return c.get(Calendar.MONTH)+1;
    }

    /**
     * 获取传入时间的0:0:0秒的long值的日
     *
     * @param time 秒单位
     * @return
     */
    public static long getTimeDay(long time) {
        Calendar c = Calendar.getInstance();
        Date date = new Date(time * 1000);
        c.setTime(date);
        return c.get(Calendar.DAY_OF_MONTH);
    }



    /**
     * 获取当天对应的是当年的第几周
     *
     * @return
     * @throws ParseException
     */
    public static String getTodayWeek() throws ParseException {
        //获取当前日期对应的第几周
        Format f2 = new DecimalFormat("00");
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String today = df.format(new Date());
        Date date = df.parse(today);
        Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        calendar.setTime(date);
        String todayWeek = f2.format(calendar.get(Calendar.WEEK_OF_YEAR));
        return todayWeek;
    }

    /**
     * 获取上一年的最后一天是当年的第几周
     * @return
     * @throws ParseException
     */
    public static Integer getLastYearLastDay() throws ParseException {
        Calendar calendar = Calendar.getInstance();
        Integer year = Calendar.getInstance().get(Calendar.YEAR) - 1;
        calendar.clear();
        calendar.set(Calendar.YEAR, year);
        calendar.roll(Calendar.DAY_OF_YEAR, -1);
        Date currYearLast = calendar.getTime();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = sdf.parse(sdf.format(currYearLast));

        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(date);
        int weekOfMonth = calendar1.get(Calendar.WEEK_OF_YEAR);
        return weekOfMonth;
    }

    /**
     * 传入秒返回X分钟X秒
     *
     * @param time 秒单位
     * @return
     */
    public static String getTimeText(int time) {
        StringBuilder sb=new StringBuilder();
        int minute=time/60;
        int second=time%60;
        if(minute>0){
            sb.append(minute).append("分钟");
        }
        if(second>0){
            sb.append(second).append("秒");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.println(TimeUtil.getTimeText(15));
    }

}
