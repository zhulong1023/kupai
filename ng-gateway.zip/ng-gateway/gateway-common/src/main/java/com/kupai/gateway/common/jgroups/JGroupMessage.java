package com.kupai.gateway.common.jgroups;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jgroups.Address;

import com.kupai.gateway.common.contants.MessageType;
import com.kupai.gateway.common.contants.ResponseMessage;

/**
 * 网关集群间的消息实体
 * Date: 16/11/21
 * Time: 下午9:04
 *
 * @author lintc
 */
@SuppressWarnings("serial")
public class JGroupMessage implements Serializable{
    private int sendType;
    private int code;
    private long from;
    private Long requestId;
    private List<Long> toUid;
    private List<Long> atUid;
    private Long roomId;
    private Object data;
    private int type = 0;//消息是请求还是响应 0-请求，1-响应
    private boolean oneWay = true;//是否需要回执，0-需要，1-不需要
    //来自哪个系统
    private Integer source;
    private int version;//版本
    private int clientType = -1;//from client type
    private transient Address sourceAdd;

    /**historyMessage ID*/
    private long msgId;

    public long getMsgId() {
        return msgId;
    }

    public void setMsgId(long msgId) {
        this.msgId = msgId;
    }

    
    public JGroupMessage() {
        super();
    }

    public JGroupMessage(Integer sendType, int code, long from) {
        super();
        this.sendType = sendType;
        this.code = code;
        this.from = from;
    }
    
    public JGroupMessage(Integer sendType, int code, long from, long requestId) {
        super();
        this.sendType = sendType;
        this.code = code;
        this.from = from;
        this.requestId = requestId;
    }


    public int getSendType() {
        return sendType;
    }

    public void setSendType(int sendType) {
        this.sendType = sendType;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public long getFrom() {
        return from;
    }

    public void setFrom(long from) {
        this.from = from;
    }

    public Long getRequestId() {
        return requestId;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Address getSourceAdd() {
        return sourceAdd;
    }

    public void setSourceAdd(Address sourceAdd) {
        this.sourceAdd = sourceAdd;
    }
    
    public List<Long> getToUid() {
        return toUid;
    }

    public void setToUid(List<Long> toUid) {
        this.toUid = toUid;
    }

    public List<Long> getAtUid() {
        return atUid;
    }

    public void setAtUid(List<Long> atUid) {
        this.atUid = atUid;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public boolean isOneWay() {
        return oneWay;
    }

    public void setOneWay(boolean oneWay) {
        this.oneWay = oneWay;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getClientType() {
        return clientType;
    }

    public void setClientType(int clientType) {
        this.clientType = clientType;
    }


    @Override
    public String toString() {
        return "JGroupMessage [sendType=" + sendType + ", code=" + code + ", from=" + from + ", requestId=" + requestId
                + ", toUid=" + toUid + ", atUid=" + atUid + ", roomId=" + roomId + ", type=" + type + ", oneWay="
                + oneWay + ", source=" + source + ", version=" + version + ", clientType=" + clientType + ", msgId="
                + msgId + "]";
    }


    public enum SendType{
        MULTI(0)//群发
        ,P2P(1);//1 定向发送到route-manager
        
        private int value;
        
        private SendType(int value){
            this.value = value;
        }
        
        public int getValue() {
            return value;
        }

        public static SendType getSendType(int value){
            switch (value) {
                case 0: return MULTI;
                case 1: return P2P;
                default : return MULTI;
            }
        }
    }

    /**
     * 构建从rm---》cm的回执消息
     * @param jGroupMessage
     * @param fromUid
     * @param responseCode  响应码
     * @return
     */
    
    public static JGroupMessage buildResponse(JGroupMessage jGroupMessage, Long fromUid, int responseCode) {
        return buildResponse(jGroupMessage, fromUid, responseCode, ResponseMessage.SUCCESS);
    }
    public static JGroupMessage buildResponse(JGroupMessage jGroupMessage, Long fromUid, int responseCode, Object data) {
        JGroupMessage jGroupMessageRes = new JGroupMessage();
        jGroupMessageRes.setCode(responseCode);
        jGroupMessageRes.setData(data);
        List<Long> toUids = new ArrayList<>(1);
        toUids.add(fromUid);
        jGroupMessageRes.setRoomId(jGroupMessage.getRoomId());
        jGroupMessageRes.setToUid(toUids);
        jGroupMessageRes.setSource(jGroupMessage.getSource());
        jGroupMessageRes.setSourceAdd(jGroupMessage.getSourceAdd());
        jGroupMessageRes.setOneWay(true);
        jGroupMessageRes.setType(MessageType.RESPONSE.getType());
        jGroupMessageRes.setSendType(JGroupMessage.SendType.P2P.getValue());
        jGroupMessageRes.setRequestId(jGroupMessage.getRequestId());
        jGroupMessageRes.setClientType(jGroupMessage.getClientType());
        jGroupMessageRes.setVersion(jGroupMessage.getVersion());
        return jGroupMessageRes;
    }

    /**
     * 创建相应点对点聊天消息
     * @param jGroupMessage
     * @param toUid
     * @param maxMsgId
     * @return
     */
    public static JGroupMessage buildToUidResponse(JGroupMessage jGroupMessage, List<Long> toUid, long maxMsgId) {
        JGroupMessage jGroupMessageRes = new JGroupMessage();
        jGroupMessageRes.setCode(jGroupMessage.getCode());
        jGroupMessageRes.setData(jGroupMessage.getData());
        jGroupMessageRes.setToUid(toUid);
        jGroupMessageRes.setSource(jGroupMessage.getSource());
        jGroupMessageRes.setOneWay(true);
        jGroupMessageRes.setType(MessageType.RESPONSE.getType());
        jGroupMessageRes.setSendType(SendType.MULTI.getValue());
        jGroupMessageRes.setClientType(jGroupMessage.getClientType());
        jGroupMessageRes.setMsgId(maxMsgId);
        jGroupMessageRes.setVersion(jGroupMessage.getVersion());
        return jGroupMessageRes;
    }
}
