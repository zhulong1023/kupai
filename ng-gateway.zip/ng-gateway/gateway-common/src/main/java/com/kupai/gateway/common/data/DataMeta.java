/**
 *
 */
package com.kupai.gateway.common.data;

import java.io.Serializable;
import java.util.List;

/**
 * @author zhouqisheng
 *         2017年3月25日
 */
@SuppressWarnings("serial")
public class DataMeta implements Serializable {
    private Integer type;
    private String event;
    private Long from;
    private Long to;
    private int code;
    private int chatType;  //聊天類型
    private Object ext;
    private List<Long> atUid;
    
    public enum Type {
        AT(1);
        
        private int value;
        
        Type(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }
    
    
    public enum Event {
        AT("at");

        private String value;

        Event(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

    }
    
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public String getEvent() {
        return event;
    }
    public void setEvent(String event) {
        this.event = event;
    }
    public Long getFrom() {
        return from;
    }
    public void setFrom(Long from) {
        this.from = from;
    }
    public Long getTo() {
        return to;
    }
    public void setTo(Long to) {
        this.to = to;
    }
    public int getCode() {
        return code;
    }
    public void setCode(int code) {
        this.code = code;
    }
    public int getChatType() {
        return chatType;
    }
    public void setChatType(int chatType) {
        this.chatType = chatType;
    }
    public Object getExt() {
        return ext;
    }
    public void setExt(Object ext) {
        this.ext = ext;
    }
    public List<Long> getAtUid() {
        return atUid;
    }
    public void setAtUid(List<Long> atUid) {
        this.atUid = atUid;
    }

}
