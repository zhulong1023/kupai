package com.kupai.gateway.common.util;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
//import me.weimi.api.commons.util.ApiLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * A tool convert Traditional Chinese character to Simplified or vice versa. The conversion is base on Unicode,
 * it means that if the character source is other encoding (e.g. gbk or gb2313) have to convert to Unicode
 * before performing conversion
 *
 * @author sofn
 * @version 1.0 Created at: 2014-05-20 15:37
 */
public class JChineseConvertor {

    private BiMap<Character, Character> ts = HashBiMap.create();
    private BiMap<Character, Character> st;
    private static JChineseConvertor convertor;

    /**
     * Get a JChineseConvertor instance.
     * <br><br>
     * Actually, JChineseConvertor just load the Conversion Table from disk once
     * while the first JChineseConvertor be instanced, and sequential call of the method will get a same instance
     *
     * @throws IOException if the conversion table cannot be loaded
     */
    public static JChineseConvertor getInstance() {
        if (convertor == null) convertor = new JChineseConvertor();
        return convertor;
    }

    /**
     * Convert all the characters of given String from Traditional Chinese to Simplified
     */
    public String t2s(final String s) {
        char[] cs = new char[s.length()];
        for (int i = 0; i < s.length(); i++) {
            cs[i] = t2s(s.charAt(i));
        }
        return new String(cs);
    }

    /**
     * Convert all the characters of given String from Simplified Chinese to Traditional
     */
    public String s2t(final String s) {
        char[] cs = new char[s.length()];
        for (int i = 0; i < s.length(); i++) {
            cs[i] = s2t(s.charAt(i));
        }
        return new String(cs);
    }

    /**
     * Convert a character from Traditional Chinese to Simplified.
     * <br>
     * if the given character cannot be converted, simple return the given character
     */
    public char t2s(final char c) {
        Character result = ts.get(c);
        return result == null ? c : result;
    }

    /**
     * Convert a character from Simplified Chinese to Traditional
     * <br>
     * if the given character cannot be converted, simple return the given character
     */
    public char s2t(final char c) {
        Character result = st.get(c);
        return result == null ? c : result;
    }

    private List<Character> loadTable() {
        List<Character> cs = loadChar("/conver/ts.tab", "UTF-8");
        if ((cs.size() % 2) != 0) throw new RuntimeException("The conversion table may be damaged or not exists");
        else return cs;
    }

    private JChineseConvertor() {
        List<Character> cs = loadTable();
        for (int i = 0; i < cs.size(); i = i + 2) {
            ts.put(cs.get(i), cs.get(i + 1));
        }
        st = ts.inverse();
    }

    private List<Character> loadChar(String file, String charset) {
        List<Character> content = new ArrayList<>();
        try {
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(this.getClass().getResourceAsStream(file), charset));
            int c;
            while ((c = in.read()) != -1) content.add((char) c);
            in.close();
            return (content);
        } catch (IOException e) {
            //ApiLogger.error("JChineseConvertor 词库文件不存在");
        }
        return null;
    }


}
