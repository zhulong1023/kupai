package com.kupai.gateway.common.jgroups;

import java.io.InputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.jgroups.Address;
import org.jgroups.JChannel;
import org.jgroups.Message;
import org.jgroups.ReceiverAdapter;
import org.jgroups.View;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.util.NetUtils;

/**
 * 网关服务器组播节点
 * Date: 16/11/19
 * Time: 下午2:47
 *
 * @author lintc
 */
@Service("jgroupsNode")
public class JGroupsNode extends ReceiverAdapter {
    private static final Logger LOGGER = LoggerFactory.getLogger(JGroupsNode.class);
    private static final Logger messageLogger = LoggerFactory.getLogger("message");

    private static final String CONFIG_XML = "jgroups-network-tcp.xml";

    private String clusterName = "NG-GATEWAY";

    private JChannel channel;

    private volatile boolean bStarted = false;

    @Value("${jgroups.tcpping.initial_hosts}")
    private String initialHosts;
    @Value("${jgroups.jchannel.name.prefix}")
    private String namePrefix;
    @Value("${jgroups.jchannel.rm.name.prefix}")
    private String rmNameprefix;
    
    private List<Address> routeManagerAddress = new ArrayList<>();
    private Random random = new Random();

    @Autowired(required = false)
    private JGroupsMessageHandler jGroupsMessageHandler;

    @PostConstruct
    public void initialize() {
        if (!bStarted) {
            Properties properties = System.getProperties();
            String systemPropertiesHosts = properties.getProperty(JGroupsContants.INITIAL_HOSTS_KEY);
            if (StringUtils.isBlank(systemPropertiesHosts)) {
                LOGGER.info(String.format("%s does not in system properties", JGroupsContants.INITIAL_HOSTS_KEY));
                if (StringUtils.isNotBlank(initialHosts)) {
                    LOGGER.info(String.format("using user property to replace  system properties, key %s, value %s"
                            , JGroupsContants.INITIAL_HOSTS_KEY, initialHosts));
                    properties.setProperty(JGroupsContants.INITIAL_HOSTS_KEY, initialHosts);
                } else {
                    LOGGER.error(JGroupsContants.INITIAL_HOSTS_KEY + " is not set, please check it");
                    throw new RuntimeException(JGroupsContants.INITIAL_HOSTS_KEY + " is not set, please check it");
                }
            }

            String systemBindAddress = properties.getProperty(JGroupsContants.BIND_ADDRESS_KEY);
            if (StringUtils.isBlank(systemBindAddress)) {
                InetAddress localAddr = NetUtils.getLocalAddress();
                systemBindAddress = localAddr.getHostAddress();
                LOGGER.info("{} does not in system properties, using {} to replace", JGroupsContants.BIND_ADDRESS_KEY, systemBindAddress);
                properties.setProperty(JGroupsContants.BIND_ADDRESS_KEY, systemBindAddress);
            }
            
            InputStream is = this.getClass().getClassLoader().getResourceAsStream(CONFIG_XML);
            try {
                channel = new JChannel(is);
                channel.setName(namePrefix + "-" + systemBindAddress);
                channel.setReceiver(this);
                channel.connect(clusterName);
                channel.setDiscardOwnMessages(true);
                channel.getState(null, 1000);
                bStarted = true;
                LOGGER.info(String.format("start jgroup node successfully, address=%s", channel.getAddress()));
            } catch (Exception ex) {
                LOGGER.error("node start failed", ex);
                throw new RuntimeException("jgroup node start failed", ex);
            }
        }
    }


    @Override
    public void receive(Message msg) {
        if(msg == null) {
            return;
        }
        Object messageObject = msg.getObject();
        messageLogger.info(String.format("[jgroup-node-message] receive message from other node: %s", messageObject));
        //接收到的消息进行处理
        if (messageObject instanceof JGroupMessage) {
           ( (JGroupMessage) messageObject).setSourceAdd(msg.getSrc());
            doProcessJgroupsMessage((JGroupMessage) messageObject);
        }else {
            messageLogger.warn("[jgroup-node-message] error msg type !");
        }
    }

    @Override
    public void viewAccepted(View view) {
        LOGGER.info("current_node[" + this.channel.getAddressAsString() + "]");
        LOGGER.info(String.format("creator %s", view.getCreator()));
        List<Address> addrList = view.getMembers();
        LOGGER.info("members=" + addrList);

        List<Address> temp = new ArrayList<>(); 
        for(Address addr :  addrList){
            if(addr.toString().startsWith(rmNameprefix)) {
                temp.add(addr);
            }
        }
        this.routeManagerAddress = temp;
        LOGGER.info("route-manager members={}", routeManagerAddress);
    }


    /**
     * 向指定的地址发送消息
     *
     * @param message     需要发送的消息
     */
    public void sendMessage(Address dest, JGroupMessage message) {
        Message msg = null;
        LOGGER.info("jgroups send to {} msg : {}",dest, message);
        if (dest != null) {
            msg = new Message(dest, null, message);
        } else if(JGroupMessage.SendType.getSendType(message.getSendType()) == JGroupMessage.SendType.MULTI){
            msg = new Message(null, null, message);
        } else  if(JGroupMessage.SendType.getSendType(message.getSendType()) == JGroupMessage.SendType.P2P){
            Address rmadd = this.routeManagerAddress.get(random.nextInt(routeManagerAddress.size()));
            msg = new Message(rmadd, null, message);
        } else {
            throw new RuntimeException("message type " + message.getSendType() + " do not support!");
        }
        
        try {
            channel.send(msg);
        } catch (Exception e) {
            LOGGER.error("send message failed! msg={}", message, e);
        }
    }
    
    /**
     * 发送消息到所有RM
     * @param message
     */
    public void sendMessageToRM (JGroupMessage message) {
        LOGGER.info("jgroups send to RM msg : {}", message);
        for (Address rm : routeManagerAddress) {
            Message msg = new Message(rm, null, message);
            try {
                channel.send(msg);
            } catch (Exception e) {
                LOGGER.error("send message failed!， msg={}", message, e);
            }
        }
    }

    /**
     * 处理来自其他集群节点广播过来的消息
     *
     * @param jgroupMessage
     */
    private void doProcessJgroupsMessage(JGroupMessage jgroupMessage) {
        try {
            jGroupsMessageHandler.messageHandler(jgroupMessage);
        } catch (Exception ex) {
            LOGGER.error("jgroup node push message to clients failed. content {},error {}", jgroupMessage, ex);
        }
    }
}
