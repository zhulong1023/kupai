package com.kupai.gateway.common.retrofit;

import com.google.gson.JsonObject;
import okhttp3.OkHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by Administrator on 2017/2/23.
 */
public class ServiceGenerator {
    private static Logger httpAccessLogger = LoggerFactory.getLogger("http_access");
    // 默认的连接超时时间
    private static final int DEFAULT_CONN_TIME_OUT = 2000;
    // 设置读取超时
    private static final int DEFAULT_SO_TIME_OUT = 5000;

    //构建httpclientBuilder
    private static OkHttpClient.Builder httpClientBuilder = new OkHttpClient.Builder();
    //构建RetrofitBuilder
    private static Retrofit.Builder builder = new Retrofit.Builder().addConverterFactory(GsonConverterFactory.create());

    /**
     * 创建对应的调用接口的服务service
     *
     * @param serviceClass 接口类
     * @param baseUrl      域名 必须以/结尾
     * @param timeOut      超时时间 单位毫秒
     * @param <S>
     * @return
     */
    public static <S> S createService(Class<S> serviceClass, String baseUrl, int timeOut) {
        if (!baseUrl.endsWith("/")) {
            baseUrl = baseUrl + "/";
        }
        //控制time out阀值, 默认2s超时
        if (timeOut <= 0 || timeOut > 8000) {
            timeOut = DEFAULT_CONN_TIME_OUT;
        }

        httpClientBuilder.connectTimeout(timeOut, TimeUnit.MILLISECONDS).readTimeout(DEFAULT_SO_TIME_OUT, TimeUnit.MILLISECONDS);
        //构造器
        builder.baseUrl(baseUrl);
        Retrofit retrofit = builder.client(httpClientBuilder.build()).build();
        return retrofit.create(serviceClass);
    }

    /**
     * 执行http方法，并返回JsonObject对象
     *
     * @param call
     * @return
     */
    public static JsonObject execute(Call<JsonObject> call, Map<String, String> params) {
        String url = call.request().url().url().getPath();
        try {
            //开始时间
            long startTime = System.currentTimeMillis();
            Response<JsonObject> responseBody = call.execute();
            if (!responseBody.isSuccessful()) {
                throw new IOException("Unexpected code " + responseBody);
            }
            JsonObject jsonObject = responseBody.body();
            //打印日志
            httpAccessLogger.info("http request url:" + url + " params:" + params.toString() + " result:" + jsonObject.toString() + " useTime:" + (System.currentTimeMillis() - startTime));
            return jsonObject;
        } catch (Exception e) {
            httpAccessLogger.error("http request url failed, url: " + url + " params:" + params.toString() + ",error:" + e);
        }
        return null;
    }

    /**
     * 异步执行http请求，但不返回值
     *
     * @param call
     * @return
     */
    public static void asyExecute(Call<JsonObject> call, Map<String, String> params, ResponseProcessor responseProcessor, Object... objects) {
        String url = call.request().url().url().getPath();
        try {
            //开始时间
            long startTime = System.currentTimeMillis();
            call.enqueue(new Callback<JsonObject>() {
                @Override
                public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                    JsonObject jsonObject = null;
                    try {
                        jsonObject = response.body();
                        if (null != responseProcessor) {
                            responseProcessor.processor(jsonObject.toString(), objects);
                        }
                        httpAccessLogger.info("http asy request url:" + url + " params:" + params.toString() + " result:" + jsonObject.toString() + " useTime:" + (System.currentTimeMillis() - startTime));
                    } catch (Exception e) {
                        httpAccessLogger.error("http asy request exception,url:" + url + " params:" + params + " e:" + e);
                    }
                }

                @Override
                public void onFailure(Call<JsonObject> call, Throwable t) {
                    httpAccessLogger.error("http asy request url failed, url: " + url + " params:" + params.toString() + ",error:" + t);
                }
            });
            //打印日志
        } catch (Exception e) {
        }
    }
}
