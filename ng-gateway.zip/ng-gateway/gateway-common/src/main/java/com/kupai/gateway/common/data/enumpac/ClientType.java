/**
 * 
 */
package com.kupai.gateway.common.data.enumpac;

/**
 * @author zhouqisheng 2017年3月31日
 */
public enum ClientType {
    APP(0), H5(1);

    private int value;

    ClientType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

}
