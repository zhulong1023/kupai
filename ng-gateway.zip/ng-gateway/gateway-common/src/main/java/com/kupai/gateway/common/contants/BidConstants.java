package com.kupai.gateway.common.contants;

/**
 * Created by Administrator on 2017/3/22.
 */
public class BidConstants {
    public static final String BID_ROOM_ID = "toUid";
    public static final String BID_FROM_UID = "fromUid";
}
