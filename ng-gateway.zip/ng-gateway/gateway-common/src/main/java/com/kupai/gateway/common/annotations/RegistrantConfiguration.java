/**
 * 
 */
package com.kupai.gateway.common.annotations;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

@Retention(RUNTIME)
@Target(TYPE)
/**
 * 业务处理注册配置
 * 
 * @author zhouqisheng
 * 2017年3月28日
 */
public @interface RegistrantConfiguration {
    
    /**
     * code 业务码
     * @return
     */
    public int[] code();
    
    /**
     * 执行顺序
     * @return
     */
    public int order() default Integer.MAX_VALUE;
    
    /**
     * 是否为唯一处理器
     * 若为真则多个注册器会在启动时抛出异常
     * @return
     */
    public boolean unique() default false;

}
