package com.kupai.gateway.common.util;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Date: 16/11/29
 * Time: 下午6:36
 *
 * @author lintc
 */
public class ThreadFactoryImpl implements ThreadFactory {

    /**
     * thread counter
     */
    public final static AtomicLong THREAD_ID = new AtomicLong(0);

    /**
     * thread name
     */
    private String name;
    /**
     * whether thread is daemon
     */
    private boolean bDaemon;

    public ThreadFactoryImpl(String threadName) {
        this(threadName, true);
    }

    public ThreadFactoryImpl(String threadName, boolean daemon) {
        this.name = threadName;
        this.bDaemon = daemon;
    }

    @Override
    public Thread newThread(Runnable r) {
        Thread t = new Thread(r, name + "-" + THREAD_ID.incrementAndGet());
        t.setDaemon(bDaemon);
        return t;
    }
}