package com.kupai.gateway.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Date: 16/6/23
 * Time: 下午4:10
 *
 * @author lintc
 */
public class DateUtils {
    private static Logger LOGGER = LoggerFactory.getLogger(DateUtils.class);

    public static String long2String(long dateTime, String dateFormat) {
        DateFormat format = new SimpleDateFormat(dateFormat);
        Date date = new Date(dateTime);
        return format.format(date);
    }

    public static long string2Long(String date, String dateFormat) {
        DateFormat df = new SimpleDateFormat(dateFormat);
        try {
            return df.parse(date).getTime();
        } catch (Exception ex) {
            LOGGER.error(String.format("format date error, date=%s", date), ex);
            return 0;
        }
    }

    public static long string2Long(String date, String dateFormat, Locale locale) {
        DateFormat df = new SimpleDateFormat(dateFormat, locale);
        try {
            return df.parse(date).getTime();
        } catch (Exception ex) {
            return 0;
        }
    }
}
