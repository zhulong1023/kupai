package com.kupai.gateway.common.jgroups;

/**
 * 对接收的消息进行处理
 * Created by Administrator on 2017/3/21.
 */
public interface JGroupsMessageHandler {
    /**
     * 对jgroups中接收到的消息进行处理
     * @param jGroupMessage
     */
    void messageHandler(JGroupMessage jGroupMessage);
}
