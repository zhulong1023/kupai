package com.kupai.gateway.common.jgroups;

import java.util.concurrent.atomic.AtomicLong;

/**
 * 生成服务端返回吗
 * Created by zhangrui on 16/4/5.
 */
public class ResponseIdGen {

    private static final AtomicLong index = new AtomicLong(1);

    public static Long getResponseId() {
        return index.getAndIncrement();
    }
}
