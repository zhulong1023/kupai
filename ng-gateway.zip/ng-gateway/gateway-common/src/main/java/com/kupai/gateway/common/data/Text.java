/**
 * 
 */
package com.kupai.gateway.common.data;

import java.io.Serializable;

/**
 * @author zhouqisheng
 * 2017年3月25日
 */
@SuppressWarnings("serial")
public class Text implements Serializable {
    private String content;
    private long messageId;
    private DataMeta meta;
    
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public DataMeta getMeta() {
        return meta;
    }
    public void setMeta(DataMeta meta) {
        this.meta = meta;
    }

    public long getMessageId() {
        return messageId;
    }

    public void setMessageId(long messageId) {
        this.messageId = messageId;
    }
}
