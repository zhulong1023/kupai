package com.kupai.gateway.common.data.enumpac;

/**
 * Created by Administrator on 2017/4/1.
 */
public enum MediaTypeEnum {

    PIC(0),   //图片
    VOICE(1), //语音
    VIDEO(2); //视频

    private int value;

    MediaTypeEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public static MediaTypeEnum parser(int value) {
        if (0 == value) {
            return PIC;
        } else if (1 == value) {
            return VOICE;
        } else if (2 == value) {
            return VIDEO;
        } else {
            throw new IllegalArgumentException("not support mediaType " + value);
        }
    }
}
