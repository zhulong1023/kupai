package com.kupai.gateway.common.contants;

/**
 * Date: 16/11/9
 * Time: 下午5:57
 *
 * @author lintc
 */
public class Constants {
    public static final String FROM_UID = "fromuid";
    public static final String ROOM_ID = "room_id";
    public static final String COMMENT_TEXT = "text";
    public static final String COMMENT_EXT = "ext";
    public static final String SOURCE = "source";
}
