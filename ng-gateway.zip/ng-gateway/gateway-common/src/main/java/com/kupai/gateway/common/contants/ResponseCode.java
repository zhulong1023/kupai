package com.kupai.gateway.common.contants;

/**
 * Date: 16/12/25
 * Time: 下午7:46
 *
 * @author lintc
 */
public class ResponseCode {
    // Success
    public static final int SUCCESS = 0;
    // the uncaught exception has happened
    public static final int SYSTEM_ERROR = -1;
    // the system is busy because of the thread pool is overflow
    public static final int SYSTEM_BUSY = -2;
    // the request code doesn't support
    public static final int CODE_NOT_SUPPORTED = -3;
    
    
    public static final int AUTH_OK = 110;
    public static final int AUTH_FAILED = 111;
    public static final int AUTH_UNIQUE_CONFLICT = 112;


    public static final int INOUT_ROOM_OK = 120;
    public static final int INOUT_ROOM_FAILED = 121;
    public static final int NONE_ROOM = 122;

    public static final int APP_STATE_OK = 130; //前后台运行成功
    public static final int APP_STATE_FAILED = 131;  //前后台运行失败
    
    public static final int HEARTBEAT_PONG = 140;

    //给客户端相应获取消息列表
    public static final int SYC_MESSAGE_SUCCESS = 301;
    /**消息类*/
    public static final int MSG_TEXT_OK = 400;
    //消息含有敏感词
    public static final int MSG_TEXT_FORBIDWORD = 401;
    //在黑名单中，发言失败
    public static final int USER_IN_BLACK = 402;
    
    public static final int MSG_MEDIA_OK = 410;
    //媒体类型不支持
    public static final int MSG_MEDIA_UNSUPPORT = 411;
    //聊天类型不支持
    public static final int MSG_CHAT_UNSUPPORT = 412;
    //通知消息
    public static final int MSG_NOTICE_OK = 420;
    
    
    /**叫价类*/
    // 叫价服务
    public static final int BID_OK = 500;
    public static final int BID_FAILED = 501;
   
}
