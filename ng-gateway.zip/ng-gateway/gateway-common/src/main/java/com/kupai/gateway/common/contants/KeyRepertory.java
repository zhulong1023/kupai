package com.kupai.gateway.common.contants;

/**
 * 常量key管理器
 * Created by zhaoshengqi on 2017/3/23.
 */
public class KeyRepertory {
    private KeyRepertory(){

    }
    /**消息列表*/
    public static final String HISTORY_MESSAGE_LIST = "ng_history_message_list_";

    /**消息查询对象游标*/
    public static final String CURSOR = "ng_cursor_";

    /**消息查询分页游标*/
    public static final String CURSOR_PAGE = "ng_cursor_page_";

    /**用来存放各个房间中的session列表**/
    public static final String ROOM_SESSION_KEY_PRE = "ng_room_session_";
    
    /**平台（source）相关设置*/
    public static final String SOURCE_CONFIG = "ng_source_config";
}
