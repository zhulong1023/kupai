/**
 * 
 */
package com.kupai.gateway.common.registry;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;

import java.util.TreeMap;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.kupai.gateway.common.annotations.RegistrantConfiguration;

/**
 * @author zhouqisheng
 * 2017年3月28日
 * @param <T>
 */
public abstract class AbstractRegistry<T> implements Registrable<T>, ApplicationContextAware {
    
    protected final Map<Integer, TreeMap<Integer, T>> registrants = new HashMap<>();
    
    private ApplicationContext applicationContext;
    
    
    @PostConstruct
    @Override
    public void scanRegistrant() {
        //注册消息过滤器
        Type superclass = getClass().getGenericSuperclass();
        ParameterizedType type = (ParameterizedType) superclass;
        @SuppressWarnings("unchecked")
        Class<T> entityClass = (Class<T>) type.getActualTypeArguments()[0];
        Map<String, T> beans = this.applicationContext.getBeansOfType(entityClass);
        if(beans == null || beans.size() == 0) {
            return;
        }
        
        for(T bean : beans.values()){
            RegistrantConfiguration mfc = bean.getClass().getAnnotation(RegistrantConfiguration.class);
            if(mfc == null){
                continue;
            }
            for(int code : mfc.code()){
                TreeMap<Integer, T> codeRegistrants = this.registrants.get(code);
                if(codeRegistrants == null){
                    codeRegistrants = new TreeMap<>();
                    registrants.put(code, codeRegistrants);
                }
                if (mfc.order() == Integer.MAX_VALUE){//没有定义执行顺序的，随机排序
                    codeRegistrants.put(mfc.order() - codeRegistrants.size(), bean);
                } else {
                   if (codeRegistrants.containsKey(mfc.order())){
                       throw new RuntimeException("register message filter error : order conflict and filter name=" + bean.getClass().getName());
                   } else {
                       codeRegistrants.put(mfc.order(), bean);
                   }
                }
            }
        }
        
        //检查唯一注册是否合法
        for(Entry<Integer, TreeMap<Integer, T>>  entry : this.registrants.entrySet()){
            TreeMap<Integer, T> codeRegistrants = entry.getValue();
            int size = codeRegistrants.size();
            for(T t : codeRegistrants.values()){
                RegistrantConfiguration mfc = t.getClass().getAnnotation(RegistrantConfiguration.class);
                if(mfc.unique() && size > 1){
                    throw new RuntimeException("registant is unique, but get more than one, code=" + entry.getKey());
                }
            }
            
        }
    }
    
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

}
