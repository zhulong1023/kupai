package com.kupai.gateway.common.contants;

/**
 * Date: 16/12/25 Time: 下午7:45
 *
 * @author lintc
 */
public class RequestCode {
    /*
     * 0~39预留给系统用
     */
    
    public static final int AUTH = 11;
    public static final int ROOM = 12; //聊天室消息
    public static final int APP_STATE = 13; //前后台运行
    public static final int HEARTBEAT_PING = 14;
    public static final int DELETE_MESSAGE = 15;//消息删除 缓存同步
    //客户端syc消息
    public static final int SYC = 30;

    /**消息类code 40-49*/
    //文本聊天消息
    public static final int MSG_TEXT = 40;
    //媒体类消息
    public static final int MSG_MEDIA = 41;
    //通知消息
    public static final int MSG_NOTICE = 42;
    /**叫价类code 50-59*/
    // 叫价服务
    public static final int BID = 50;

}
