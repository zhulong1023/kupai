package com.kupai.gateway.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DecimalFormat;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Date: 16/12/25
 * Time: 下午3:31
 *
 * @author lintc
 */
public class StatisticsLog implements Runnable {
    private static Logger log = LoggerFactory.getLogger("debug_stat");
    private static AtomicBoolean outOfMemory = new AtomicBoolean(false);
    private static AtomicBoolean pausePrint = new AtomicBoolean(false);
    private static Map<String, ThreadPoolExecutor> executors = new ConcurrentHashMap<>();

    static {
        printStat(5000);
    }

    private static long startTime;
    private static long interval;

    public StatisticsLog(long startTime2, long interval2) {
        startTime = startTime2;
        interval = interval2;
    }

    public static void setPausePrint(boolean print) {
        pausePrint.set(print);
    }

    public static void registerExecutor(String name, ThreadPoolExecutor executor) {
        executors.put(name, executor);
    }

    /**
     * print stat info on the screen, this method will block until total is reached,
     *
     * @param interval how long (second) to print a stat log
     */
    public static StatisticsLog printStat(long interval) {
        log.info("Start statistics log thread.");
        StatisticsLog t = new StatisticsLog(System.currentTimeMillis(), interval);
        Thread thread = new Thread(t, "Statistics-Thread-");
        thread.setDaemon(true);
        thread.start();
        return t;
    }

    public void run() {
        while (true) {
            try {
                synchronized (this) {
                    wait(interval);
                }
                if (pausePrint.get())
                    continue;

                long time2 = System.currentTimeMillis();
                if (time2 == startTime)
                    continue;
                log.info("---------------------------");
                log.info("JAVA HEAP: " + memoryReport() + ", UP TIME: " + ((time2 - startTime) / 1000) + ", min: " + ((time2 - startTime) / 60000));
                StringBuilder sb = new StringBuilder("thread-pool:[");
                StringBuilder jsonLog = new StringBuilder();
                jsonLog.append("[");
                int i = 0;
                for (Map.Entry<String, ThreadPoolExecutor> entry : executors.entrySet()) {
                    sb.append(statExecutor(entry.getKey(), entry.getValue())).append(", ");
                    if (i++ > 0) {
                        jsonLog.append(",");
                    }
                    jsonLog.append(statJsonExecutor(entry.getKey(), entry.getValue()));
                }
                jsonLog.append("]");
                sb.append(jsonLog);
                log.info(sb.append(" ]").toString());
            } catch (InterruptedException e) {
                e.printStackTrace();
                break;
            }
        }
        log.info("Stat log stop");
        log.info("---------------------------");
    }

    public static String memoryReport() {
        Runtime runtime = Runtime.getRuntime();
        double freeMemory = (double) runtime.freeMemory() / (1024 * 1024);
        double maxMemory = (double) runtime.maxMemory() / (1024 * 1024);
        double totalMemory = (double) runtime.totalMemory() / (1024 * 1024);
        double usedMemory = totalMemory - freeMemory;
        double percentFree = ((maxMemory - usedMemory) / maxMemory) * 100.0;
        if (percentFree < 10) {
            outOfMemory.set(true);
            log.error("Detected OutOfMemory potential memory > 90%, stop broadcast presence !!!!!!");
        } else if (outOfMemory.get() && percentFree > 20) {
            outOfMemory.set(false);
            log.error("Detected memory return to normal, memory < 80%, resume broadcast presence.");
        }

        double percentUsed = 100 - percentFree;
        DecimalFormat mbFormat = new DecimalFormat("#0.00");
        DecimalFormat percentFormat = new DecimalFormat("#0.0");

        return " " + mbFormat.format(usedMemory) + "MB of " + mbFormat.format(maxMemory) + " MB (" + percentFormat.format(percentUsed) + "%) used";
    }

    public static boolean isOutOfMemory() {
        return outOfMemory.get();
    }

    private String statExecutor(String name, ThreadPoolExecutor executor) {
        return name + "{" + executor.getQueue().size() + "," + executor.getCompletedTaskCount() + "," + executor.getTaskCount() + "," + executor.getActiveCount() + "," + executor.getCorePoolSize() + "}\n";
    }

    private String statJsonExecutor(String name, ThreadPoolExecutor executor) {
        return "{\"name\":" + name + "," + "\"act\":" + executor.getActiveCount() + "," + "\"max\":" + executor.getCorePoolSize() + "}";
    }
}
