package com.kupai.gateway.common.retrofit;

/**
 * Created by Administrator on 2017/3/3.
 */
public interface ResponseProcessor {
    /**
     * 处理返回的结果
     * @param object
     */
    void processor(Object object1, Object... object);
}
