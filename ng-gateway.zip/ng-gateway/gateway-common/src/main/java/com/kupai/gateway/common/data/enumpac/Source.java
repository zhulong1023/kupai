/**
 * 
 */
package com.kupai.gateway.common.data.enumpac;

/**
 * @author zhouqisheng
 * 2017年3月31日
 */
public enum Source {
    TEST(0), OPEN_FLAT(1), KUPAI(2);
    private int value;

    Source(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public static Source parser(int value) {
        if (0 == value) {
            return KUPAI;
        } else if (1 == value) {
            return OPEN_FLAT;
        } else {
            throw new IllegalArgumentException("not support source " + value);
        }
    }

}
