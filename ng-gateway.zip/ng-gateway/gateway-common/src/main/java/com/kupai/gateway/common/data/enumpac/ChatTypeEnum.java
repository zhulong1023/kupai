package com.kupai.gateway.common.data.enumpac;

/**
 * Created by Administrator on 2017/3/31.
 */
public enum ChatTypeEnum {
    SINGLE(1, "个人对个人"),
    ROOM(2, "聊天室");

    private int type;
    private String desc;

    ChatTypeEnum(int type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    public int getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }

    public static ChatTypeEnum parser(int chatType) {
        if (1 == chatType) {
            return SINGLE;
        } else if (2 == chatType) {
            return ROOM;
        } else {
            throw new IllegalArgumentException("not support chatType " + chatType);
        }
    }
}
