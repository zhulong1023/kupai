package com.kupai.gateway.common.data;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/3/31.
 */
@SuppressWarnings("serial")
public class Syc implements Serializable {

    /**
     * 拉取方向  0 拉取最新的数据  1 拉取历史数据
     */
    private int pullType;

    /**
     * 每页拉取多少条,默认20条，可由客户端控制
     */
    private int pageSize = 20;

    /**
     * 需要syc的开始的messageId
     */
    private String messageId;

    /**
     * 未读消息数
     */
    private long unReadNum;

    /**
     *  消息内容【json列表 toString】
     */
    private Object message;

    /**
     * 元数据信息
     */
    private DataMeta meta;

    public int getPullType() {
        return pullType;
    }

    public void setPullType(int pullType) {
        this.pullType = pullType;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public DataMeta getMeta() {
        return meta;
    }

    public void setMeta(DataMeta dataMeta) {
        this.meta = dataMeta;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public long getUnReadNum() {
        return unReadNum;
    }

    public void setUnReadNum(long unReadNum) {
        this.unReadNum = unReadNum;
    }
}
