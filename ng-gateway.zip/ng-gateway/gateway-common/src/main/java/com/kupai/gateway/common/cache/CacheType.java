package com.kupai.gateway.common.cache;

/**
 * Created by zhaoshengqi on 2017/3/22.
 */
public class CacheType {
    /**
     * 游标缓存,有效期5分
     */
    public static final String GETMESSAGECURSOR = "getMessageCursor";
    /**
     * 缺省1天 5000条数据
     */
    public static final String GETMESSAGEDEFAULT = "getMessageDefault";
    /**
     * 最大容量10000,五分
     */
    public static final String GETMESSAGESIZE = "getMessageSize";

    /**
     * 存放请求列表
     */
    public static final String REQUEST_AND_RESPONSE= "requestAndResponse";

}
