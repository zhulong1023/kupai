/**
 * 
 */
package com.kupai.gateway.common.registry;

/**
 * @author zhouqisheng
 * 2017年3月28日
 */
public interface Registrable<T> {
    
    /**
     * 扫描可注册类并注册
     */
    public void scanRegistrant();
    
}
