/**
 * 
 */
package com.kupai.gateway.common.data;

import java.io.Serializable;

/**
 * @author zhouqisheng
 * 2017年3月25日
 */
@SuppressWarnings("serial")
public class Media implements Serializable {
    private DataMeta meta;
    private long messageId;
    private String mediaId;
    private int mediaType;
    private String desc;
    private String url;
    
    public DataMeta getMeta() {
        return meta;
    }
    public void setMeta(DataMeta meta) {
        this.meta = meta;
    }
    public String getMediaId() {
        return mediaId;
    }
    public void setMediaId(String mediaId) {
        this.mediaId = mediaId;
    }
    public int getMediaType() {
        return mediaType;
    }
    public void setMediaType(int mediaType) {
        this.mediaType = mediaType;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }

    public long getMessageId() {
        return messageId;
    }

    public void setMessageId(long messageId) {
        this.messageId = messageId;
    }
}
