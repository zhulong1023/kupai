package com.kupai.gateway.common.unread;

import com.kupai.gateway.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import redis.clients.jedis.JedisCluster;

/**
 * 用于维护用户未读消息数
 *
 * Created by shichen on 2017/4/24.
 */
@Service
public class UnReadNumService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(UnReadNumService.class);

    private static final String CHAT_UN_READ_NUM = "chat_un_read_num_";

    @Autowired
    private JedisCluster jedisCluster;

    /**
     * 维护用户的未读消息数
     *
     * @param sessionId 会话id
     * @param toUid 被增加未读消息数的用户的uid
     * @return
     */
    public long incrUserUnReadNum(String sessionId, String toUid) {
        Long unReadNum = jedisCluster.hincrBy(CHAT_UN_READ_NUM + sessionId, toUid, 1);
        LOGGER.info("incr user un read num, sessionId {}, toUid {}, unReadNum {}", sessionId, toUid, unReadNum);
        if (null == unReadNum) {
            unReadNum = 1L;
        }
        return unReadNum;
    }

    /**
     * 更新用户的未读消息数为0
     *
     * @param sessionId 会话id
     * @param fromUid 来更新未读数的用户的uid
     * @return
     */
    public boolean updateUserUnReadNumTo0(String sessionId, String fromUid) {
        LOGGER.info("update user un read num to 0, sessionId {}, fromUid {}", sessionId, fromUid);
        return jedisCluster.hset(CHAT_UN_READ_NUM + sessionId, fromUid, "0") > 0;
    }

    /**
     * 获取未读消息数
     *
     * @param sessionId
     * @param fromUid
     * @return
     */
    public long getUnReadNum(String sessionId, String fromUid) {
        String unReadNum = jedisCluster.hget(CHAT_UN_READ_NUM + sessionId, fromUid);
        LOGGER.info("get user un read num, sessionId {}, fromUid {}, unReadNum {}", sessionId, fromUid, unReadNum);
        return StringUtils.isNotEmpty(unReadNum) ? Long.parseLong(unReadNum) : 0;
    }
}
