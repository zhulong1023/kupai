/**
 * 
 */
package com.kupai.gateway.common.data;

import java.io.Serializable;

/**
 * @author zhouqisheng
 * 2017年3月25日
 */
@SuppressWarnings("serial")
public class Bid implements Serializable {
    private DataMeta meta;
    private String bidId;
    private long price;
    private int anonymous;
    private String ext;
    
    public DataMeta getMeta() {
        return meta;
    }
    public void setMeta(DataMeta meta) {
        this.meta = meta;
    }
    public String getBidId() {
        return bidId;
    }
    public void setBidId(String bidId) {
        this.bidId = bidId;
    }
    public long getPrice() {
        return price;
    }
    public void setPrice(long price) {
        this.price = price;
    }
    public int getAnonymous() {
        return anonymous;
    }
    public void setAnonymous(int anonymous) {
        this.anonymous = anonymous;
    }
    public String getExt() {
        return ext;
    }
    public void setExt(String ext) {
        this.ext = ext;
    }
    
}
