/**
 * 
 */
package com.kupai.gateway.common.data;

import java.io.Serializable;

/**
 * @author zhouqisheng
 * 2017年3月25日
 */
@SuppressWarnings("serial")
public class Command implements Serializable {
    private Object content;
    private DataMeta meta;
    
    public Object getContent() {
        return content;
    }
    public void setContent(Object content) {
        this.content = content;
    }
    public DataMeta getMeta() {
        return meta;
    }
    public void setMeta(DataMeta meta) {
        this.meta = meta;
    }

}
