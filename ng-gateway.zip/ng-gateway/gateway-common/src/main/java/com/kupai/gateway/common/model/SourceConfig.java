/**
 * 
 */
package com.kupai.gateway.common.model;

/**
 * @author zhouqisheng 2017年4月10日
 */
public class SourceConfig {
    private Integer source;
    private String callbackUrl;

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public String getCallbackUrl() {
        return callbackUrl;
    }

    public void setCallbackUrl(String callbackUrl) {
        this.callbackUrl = callbackUrl;
    }

}
