package com.kupai.gateway.common.redis;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPoolConfig;

/**
 * Created by zhaoshengqi on 2017/3/21.
 */
@Configuration
@EnableAutoConfiguration
public class RedisConfig {

    @Value("${redis.config.maxTotal}")
    private int maxTotal;
    @Value("${redis.config.minIdle}")
    private int minIdle;
    @Value("${redis.config.maxWaitMillis}")
    private long maxWaitMillis;
    @Value("${redis.cluster.addr}")
    private String ipAndPorts;


    @Bean    
    public JedisCluster getJedisCluster(){
        Set<HostAndPort> jedisClusterNodes = new HashSet<HostAndPort>();
        if (StringUtils.isBlank(ipAndPorts)) {
            throw new RuntimeException("JedisCluster config has error");
        }
        String[] hostPortArr = ipAndPorts.split(",");
        
        JedisPoolConfig redisConfig = new JedisPoolConfig();
        
        redisConfig.setBlockWhenExhausted(true);
        redisConfig.setLifo(false);
        redisConfig.setTestOnBorrow(false);
        redisConfig.setTestOnReturn(false);
        redisConfig.setTestWhileIdle(true);
        redisConfig.setNumTestsPerEvictionRun(-2);
        redisConfig.setTimeBetweenEvictionRunsMillis(30000);
        redisConfig.setSoftMinEvictableIdleTimeMillis(3600000);
        redisConfig.setMinEvictableIdleTimeMillis(-1);

        for (String hostAndPort : hostPortArr) {
            String[] arr = hostAndPort.split(":");
            // Jedis Cluster will attempt to discover cluster nodes automatically
            jedisClusterNodes.add(new HostAndPort(arr[0], Integer.valueOf(arr[1])));
        }
    
        return new JedisCluster(jedisClusterNodes, redisConfig);
    }

}
