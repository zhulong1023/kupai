/**
 * 
 */
package com.kupai.gateway.common.data;

import java.io.Serializable;

/**
 * @author zhouqisheng
 * 2017年3月27日
 */
@SuppressWarnings("serial")
public class Authorization implements Serializable {
    private long uid;
    private String passport;
    private int clientType;
    private int source;
    private short role;
    //新会话创建时间
    private long newSessionCreateTime;
    
    public long getUid() {
        return uid;
    }
    public void setUid(long uid) {
        this.uid = uid;
    }
    public String getPassport() {
        return passport;
    }
    public void setPassport(String passport) {
        this.passport = passport;
    }
    public int getClientType() {
        return clientType;
    }
    public void setClientType(int clientType) {
        this.clientType = clientType;
    }
    public int getSource() {
        return source;
    }
    public void setSource(int source) {
        this.source = source;
    }
    public short getRole() {
        return role;
    }
    public void setRole(short role) {
        this.role = role;
    }
    public long getNewSessionCreateTime() {
        return newSessionCreateTime;
    }
    public void setNewSessionCreateTime(long newSessionCreateTime) {
        this.newSessionCreateTime = newSessionCreateTime;
    }
}
