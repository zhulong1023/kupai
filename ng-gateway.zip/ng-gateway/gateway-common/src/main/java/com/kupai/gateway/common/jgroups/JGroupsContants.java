package com.kupai.gateway.common.jgroups;

/**
 * Created by Administrator on 2017/3/20.
 */
public class JGroupsContants {
    public final static String INITIAL_HOSTS_KEY="jgroups.tcpping.initial_hosts";
    public final static String BIND_ADDRESS_KEY="jgroups.bind_addr";
}
