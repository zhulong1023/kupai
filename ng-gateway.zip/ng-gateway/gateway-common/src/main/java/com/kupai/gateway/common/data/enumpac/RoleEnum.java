/**
 * 
 */
package com.kupai.gateway.common.data.enumpac;

/**
 * @author zhouqisheng 2017年4月5日
 */
public enum RoleEnum {
    NORMAL((short)0), // 普通用户
    COMPERE((short)1),// 主持人
    OBSERVER((short)2);//观察者，主持人后台用

    private short value;

    RoleEnum(short value) {
        this.value = value;
    }

    public short getValue() {
        return this.value;
    }

    public static RoleEnum prarse(short value) {
        switch (value) {
        case 0:
            return RoleEnum.NORMAL;
        case 1:
            return RoleEnum.COMPERE;
        default:
            return null;
        }
    }
}
