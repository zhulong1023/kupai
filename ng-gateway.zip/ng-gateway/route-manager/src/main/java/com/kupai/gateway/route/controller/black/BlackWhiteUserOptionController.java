package com.kupai.gateway.route.controller.black;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kupai.gateway.route.annocations.ApiStatus;
import com.kupai.gateway.route.annocations.AuthType;
import com.kupai.gateway.route.annocations.BaseInfo;
import com.kupai.gateway.route.annocations.SignType;
import com.kupai.gateway.route.data.Result;
import com.kupai.gateway.route.service.BlackWhiteUserOptionService;

/**
 * 黑白名单维护操作
 * 列表维护
 * Created by Administrator on 2017/3/29.
 */
@RestController
@RequestMapping(value = "/route/api/blackWhite")
public class BlackWhiteUserOptionController {

    @Autowired
    private BlackWhiteUserOptionService blackWhiteUserOptionService;

    /**
     * 维护黑白名单用户
     *
     * @param source 系统
     * @param org    机构
     * @param uids   用户uid列表
     * @param type   类型 1 黑名单  2 白名单
     * @param status 0 取消禁言  1 禁言
     * @param gagTime 禁言时长 默认900s -1为永久性禁言
     * @return
     */
    @RequestMapping(value = "/user/set.json", method = RequestMethod.POST, produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> setBlackWhiteUser(
            @RequestParam(name = "source", required = true) String source,
            @RequestParam(name = "org", required = true) String org,
            @RequestParam(name = "uids", required = true) String uids,
            @RequestParam(name = "type", required = false, defaultValue = "1") Integer type,
            @RequestParam(name = "status", required = true) Integer status,
            @RequestParam(name = "gagTime", required = false, defaultValue = "900") Long gagTime) {
        blackWhiteUserOptionService.setBlackWhiteUser(source, org, uids, type, status, gagTime);
        return new Result<>(true);
    }

    /**
     * 维护黑白名单列表与房间之间的关系
     *
     * @param source 系统
     * @param org    机构
     * @param rooms  用户uid列表
     * @param type   类型 1 黑名单  2 白名单
     * @param status 0 取消禁言  1 禁言
     * @return
     */
    @RequestMapping(value = "/room/set.json", method = RequestMethod.POST, produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> setBlackWhiteRoom(
            @RequestParam(name = "source", required = true) String source,
            @RequestParam(name = "org", required = true) String org,
            @RequestParam(name = "rooms", required = true) String rooms,
            @RequestParam(name = "type", required = false, defaultValue = "1") Integer type,
            @RequestParam(name = "status", required = true) Integer status) {
        blackWhiteUserOptionService.setBlackWhiteRoom(source, org, rooms, type, status);
        return new Result<>(true);
    }
}
