package com.kupai.gateway.route.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.route.dao.HistoryMessageDao;
import com.kupai.gateway.route.exception.ErrorResultCode;
import com.kupai.gateway.route.exception.RouteManagerExceptionUtils;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.model.HistoryMessage;
import com.kupai.gateway.route.service.HistoryMessageService;
import com.kupai.gateway.route.service.MessageDispatchService;

/**
 * Created by zhaoshengqi on 2017/3/21.
 */
@Service
public class HistoryMessageServiceImpl implements HistoryMessageService {

    @Autowired
    private HistoryMessageDao historyMessageDao;
    
    @Resource(name = "historyMessageCache")
    private CaffeineCache historyMessageCache;

    @Autowired
    private MessageDispatchService messageDispatchService;


    /**
     * 查询消息列表
     *
     * @param msgId     游标 消息ID
     * @param sessionId 场景ID(roomID/toid+uid)
     * @param pageSize
     * @return
     */
    @Override
    public List<HistoryMessage> queryHistoryMessage(long msgId, String sessionId, int pageSize) {
        List<HistoryMessage> historyMessageList = this.getHistoryMessageList(sessionId);
        if (CollectionUtils.isNotEmpty(historyMessageList)) {
            //分页
            if (msgId > 0) {
                historyMessageList = historyMessageList.stream()
                        .filter(h -> h.getId() < msgId)
                        .collect(Collectors.toList());
            }
            if (pageSize >= historyMessageList.size()) {
                return historyMessageList;
            }
            return historyMessageList.stream().skip(historyMessageList.size() - pageSize).collect(Collectors.toList());
        }
        return null;
    }

    /**
     * 查询syc消息列表
     *
     * @param msgId     游标 消息ID
     * @param sessionId 场景ID(roomID/toid+uid)
     * @param pageSize
     * @return
     */
    @Override
    public List<HistoryMessage> sycMessage(int pullType, long msgId, int pageSize, String sessionId) {
        //返回的结果List
        List<HistoryMessage> resultList = new ArrayList<>(pageSize);
        //查询到的消息列表
        List<HistoryMessage> historyMessageList = this.getHistoryMessageList(sessionId);
        //查询符合条件的pageSize的条数
        if (CollectionUtils.isNotEmpty(historyMessageList)) {
            int size = historyMessageList.size();
            //如果msgId = 0,则永远拉取最新的20条数据
            if (msgId == 0) {
                int toIndex = size;
                if (toIndex > pageSize) {
                    resultList = historyMessageList.subList(toIndex - pageSize, toIndex);
                } else {
                    resultList = historyMessageList;
                }
            } else {//mesId != 0 则按照客户端发送的pullType来拉取消息
                if (pullType == 0) { //拉取最新数据
                    int toIndex = size;
                    for (int i = size - 1; i >= 0; i--) {
                        HistoryMessage historyMessage = historyMessageList.get(i);
                        if (historyMessage.getId() == msgId) {
                            if (size - (i + 1) > pageSize) {
                                toIndex = i + 1 + pageSize;
                            }
                            resultList = historyMessageList.subList(i + 1, toIndex);
                            break;
                        }
                    }
                } else if (pullType == 1) {//拉取历史数据
                    int toIndex = 0;
                    int startIndex = 0;
                    for (int i = size - 1; i >= 0; i--) {
                        HistoryMessage historyMessage = historyMessageList.get(i);
                        if (historyMessage.getId() == msgId) {
                            toIndex = i;
                            if (toIndex - pageSize > 0) {
                                startIndex = toIndex - pageSize;
                            } else {
                                startIndex = 0;
                            }
                            resultList = historyMessageList.subList(startIndex, toIndex);
                            break;
                        }
                    }
                }
            }
        }
        return resultList;
    }

    /**
     * 接收消息
     *
     * @param historyMessage
     */
    @Override
    public boolean receiveMessage(HistoryMessage historyMessage) {

        try {

            boolean dbResult = this.addMessage(historyMessage);
            // 更新cache
            @SuppressWarnings("unchecked")
            List<HistoryMessage> list = (List<HistoryMessage>) historyMessageCache.getNativeCache().asMap().get(historyMessage.getSessionId());
            if (dbResult) {
                // 第一次receive处理,防止宕机cache数据不同步
                if (CollectionUtils.isNotEmpty(list)) {
                    list.add(historyMessage);
                    ApiLogger.info("HistoryMessageServiceImpl receiveMessage add CaffeineCache SUCCESS, sessionId=:" + historyMessage.getSessionId() + "," +
                            "uid=:" + historyMessage.getUserId() + ",content=:" + historyMessage.getContent());
                } else {
                    list = historyMessageDao.queryHistoryMessage(0, historyMessage.getSessionId(), 0, -1, 1);
                    //更新cache
                    historyMessageCache.put(historyMessage.getSessionId(), list);
                }

            } else {
                ApiLogger.info("HistoryMessageServiceImpl addMessage DB failure");
            }
            return true;
        } catch (Exception e) {
            ApiLogger.error("HistoryMessageServiceImpl receiveMessage error", e);
            return false;
        }

    }

    /**
     * 消息删除
     *
     * @param msgIds
     * @return
     */
    @Override
    public boolean deleteMessage(String msgIds) {

        boolean dResult = historyMessageDao.updateStatusByIds(msgIds);
        if (dResult) {
            ApiLogger.info("HistoryMessageService deleteMessage SUCCESS,msgIds=:" + msgIds);

            List<HistoryMessage> historyMessageList = historyMessageDao.getHistoryMessageByIds(msgIds);
            if (CollectionUtils.isEmpty(historyMessageList)){
                throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.NO_RESULT_FIND_ERROR);
            }
            //更新缓存
            for (HistoryMessage hm : historyMessageList){
                if (hm != null) {
                    List<HistoryMessage> list = (List<HistoryMessage>) historyMessageCache.getNativeCache().asMap().get(hm.getSessionId());
                    if (CollectionUtils.isNotEmpty(list)) {
                        list.remove(hm);
                        ApiLogger.info("HistoryMessageService deleteMessage delete cache SUCCESS,id=:" + hm.getId());
                    }
                    //多rm缓存同步
                    JGroupMessage jGroupMessage = new JGroupMessage();
                    jGroupMessage.setMsgId(hm.getId());
                    jGroupMessage.setSendType(JGroupMessage.SendType.MULTI.getValue());
                    jGroupMessage.setCode(RequestCode.DELETE_MESSAGE);
                    messageDispatchService.forwardToRm(jGroupMessage);
                }
            }
            return dResult;
        }else{
            throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.NO_RESULT_FIND_ERROR);
        }

    }

    /**
     * 查询已删除消息数据
     * @param sessionId
     * @return
     */
    @Override
    public List<HistoryMessage> queryInvalidHistoryMessage(String sessionId) {
        return historyMessageDao.queryHistoryMessage(0, sessionId, 0, -1, 0);
    }

    /**
     * 获得当前会话中最大的messageId
     *
     * @param sessionId 会话id
     * @return
     */
    @Override
    public String getHistoryMaxMessageId(String sessionId) {
        @SuppressWarnings("unchecked")
        List<HistoryMessage> historyMessageList = (List<HistoryMessage>) historyMessageCache.getNativeCache().asMap().get(sessionId);
        if (CollectionUtils.isNotEmpty(historyMessageList)) {
            return String.valueOf(historyMessageList.get(historyMessageList.size() - 1).getId());
        }
        return "0";
    }


    /**
     * 添加消息
     *
     * @param historyMessage
     * @return
     */
    private boolean addMessage(HistoryMessage historyMessage) {
        return historyMessageDao.addHistoryMessage(historyMessage);
    }

    /**
     * 从本地缓存中获取数据【本地缓存获取不到则从数据库中拉取】
     *
     * @param sessionId
     * @return
     */
    private List<HistoryMessage> getHistoryMessageList(String sessionId) {
        //先查询cache
        @SuppressWarnings("unchecked")
        List<HistoryMessage> historyMessageList = (List<HistoryMessage>) historyMessageCache.getNativeCache().asMap().get(sessionId);
        if (CollectionUtils.isEmpty(historyMessageList)) {
            //数据库
            historyMessageList = historyMessageDao.queryHistoryMessage(0, sessionId, 0, -1, 1);
            //cache
            if (CollectionUtils.isNotEmpty(historyMessageList)) {
                historyMessageCache.put(sessionId, historyMessageList);
            }
        }
        return historyMessageList;
    }
}
