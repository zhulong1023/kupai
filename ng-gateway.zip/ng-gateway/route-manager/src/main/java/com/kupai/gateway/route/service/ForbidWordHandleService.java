package com.kupai.gateway.route.service;

import com.kupai.gateway.route.model.ForbidModule;

/**
 * Created by zhulong on 2017/3/27.
 * 过滤敏感词接口
 */
public interface ForbidWordHandleService {

    ForbidModule.Result checkForbidWords( String text,int source);


}
