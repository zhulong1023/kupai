/**
 * 
 */
package com.kupai.gateway.route.cache;

import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kupai.gateway.common.contants.KeyRepertory;

import redis.clients.jedis.JedisCluster;

/**
 * @author zhouqisheng
 * 2017年4月10日
 */
@Component
public class RoomStorage {
    
    @Autowired
    private JedisCluster jedisCluster;
    
    /**
     * 获取房间内所有的session列表
     *
     * @param roomId 房间id
     * @return
     */
    public Set<String> listRoomSession(long roomId) {
        String key = getRoomSessionKeyPre(roomId);
        Set<String> set = jedisCluster.smembers(key);
        if (CollectionUtils.isNotEmpty(set)) {
            return set;
        }
        return null;
    }
    
    /**
     * 获得room session的key
     *
     * @param roomId
     * @return
     */
    private static String getRoomSessionKeyPre(long roomId) {
        return KeyRepertory.ROOM_SESSION_KEY_PRE + roomId;
    }

}
