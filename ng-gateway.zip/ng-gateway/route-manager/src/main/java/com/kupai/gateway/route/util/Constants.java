package com.kupai.gateway.route.util;

/**
 * Date: 16/11/9
 * Time: 下午5:57
 *
 * @author lintc
 */
public class Constants {
    public static final String X_Client_ID_HEADER = "X-Client-ID";
    public static final String X_Client_ID = "1-20119-f36892c6a26908e6e1b8e15f98d16ba7";
    public static final String X_Matrix_UID_HEADER="X-Matrix-UID";
    public static final String X_Matrix_UID = "1000";
    public static final String APP_ID="20119";
    public static final String Authorization_HEADER = "Authorization";
    public static final String BAOKU_TOKEN_HEADER="_bkAccessToken_";
    public static final String BAOKU_TOKEN_VERSION_HEADER="_tokenVersion_";
    public static final String BAOKU_X_MATRIX_FROM_HEADER="x-matrix-from";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS="yyyy-MM-dd HH:mm:ss";
}
