package com.kupai.gateway.route.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by yiyh on 2/13/14.
 */

@SuppressWarnings("serial")
public class ForbidWord implements Serializable {
    private long id;
    private String name;
    private String type;
    private int level;
    private WordStatus status;
    private Timestamp startTime;
    private Timestamp endTime;
    private int source;
    private Timestamp createTime;

    public ForbidWord() {
    }

    public ForbidWord(String name, String type, int level, WordStatus status, Timestamp startTime, Timestamp endTime, int source) {
        this.name = name;
        this.type = type;
        this.level = level;
        this.status = status;
        this.startTime = startTime;
        this.endTime = endTime;
        this.source = source;
    }
    public ForbidWord(long id,String name, String type, int level, WordStatus status, Timestamp startTime, Timestamp endTime) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.level = level;
        this.status = status;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public WordStatus getStatus() {
        return status;
    }

    public void setStatus(WordStatus status) {
        this.status = status;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

//@Override
    /*public String toJSONString() {
        JSONObject jb = new JSONObject();
        jb.append("id", this.id);
        jb.append("name", this.name);
        jb.append("type", this.type);
        jb.append("level", this.level);
        jb.append("status", this.getStatus().getValue());
        if(null != this.startTime){
            jb.append("startTime", this.startTime.toString());
        }
        if(null != this.endTime){
            jb.append("endTime", this.endTime.toString());
        }
        jb.append("source", this.source);
        jb.append("createTime", this.createTime.toString());

        return jb.toJSONString();
    }*/

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ForbidWord that = (ForbidWord) o;

        if (id != that.id) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return (int) (id ^ (id >>> 32));
    }

    public static enum WordStatus {
        invalid(0), valid(1);
        private int value;

        WordStatus(int status) {
            this.value = status;
        }

        private static Map<Integer, WordStatus> valueTypes = new HashMap<>();

        static {
            for (WordStatus rs : WordStatus.values()) {
                valueTypes.put(rs.value, rs);
            }
        }
        //@JsonValue
        public int getValue() {
            return this.value;
        }

        public static WordStatus parseValue(int status){
            return valueTypes.get(status);
        }

        //@Override
        /*public String toJSONString() {
            return JsonSerializerUtils.serialize(this.getValue());
        }*/
    }

}