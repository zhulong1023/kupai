package com.kupai.gateway.route.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.common.data.DataMeta;
import com.kupai.gateway.common.data.Media;
import com.kupai.gateway.common.data.enumpac.ChatTypeEnum;
import com.kupai.gateway.common.data.enumpac.MediaTypeEnum;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.util.IdWorker;
import com.kupai.gateway.route.handler.processor.DefaultRequestProcessor;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.model.HistoryMessage;
import com.kupai.gateway.route.service.HistoryMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;

/**
 * Created by Administrator on 2017/3/28.
 */
@Component
public class ChatMediaProcessHandler extends AbstractProcessHandler {

    @Autowired
    private HistoryMessageService historyMessageService;

    @Autowired
    private IdWorker idWorker;

    /**
     * 注册该处理器
     */
    @PostConstruct
    protected void registerHandler() {
        DefaultRequestProcessor.registerProcessHandler(RequestCode.MSG_MEDIA, this);
    }

    /**
     * 处理消息的转发
     *
     * @param jGroupMessage
     */
    @Override
    protected JGroupMessage doProcess0(JGroupMessage jGroupMessage) {
        ApiLogger.message(String.format("do process chat media message start, message info %s", jGroupMessage.toString()));
        // 判断必须为Media类型
        Media media = (Media) jGroupMessage.getData();
        DataMeta dataMeta = media.getMeta();
        try {
            ChatTypeEnum.parser(dataMeta.getChatType());
        } catch (Exception e) {
            jGroupMessage.setCode(ResponseCode.MSG_CHAT_UNSUPPORT);
            jGroupMessage.setData(ResponseMessage.NOT_SUPPORT_CHAT_MESSAGE);
            return jGroupMessage;
        }
        try {
            MediaTypeEnum.parser(media.getMediaType());
        } catch (Exception e) {
            jGroupMessage.setCode(ResponseCode.MSG_MEDIA_UNSUPPORT);
            jGroupMessage.setData(ResponseMessage.NOT_SUPPORT_MEDIA_MESSAGE);
            return jGroupMessage;
        }

        // 存入到数据库中
        HistoryMessage historyMessage = new HistoryMessage();

        long messageId = idWorker.nextId();
        jGroupMessage.setMsgId(messageId);
        historyMessage.setId(messageId);

        //防止ext为string类型
        JSONObject ext = null;
        if (dataMeta.getExt() instanceof JSONObject) {
            ext = (JSONObject) dataMeta.getExt();
        } else {
            ext = JSON.parseObject((String) dataMeta.getExt());
        }
        dataMeta.setExt(ext);

        //at消息处理
        List<Long> atUidList = dataMeta.getAtUid();
        if (atUidList != null) {
            jGroupMessage.setAtUid(atUidList);
            dataMeta.setAtUid(null);//历史不存at信息，减少信息长度
        }

        //将media转换为jsonObject类型，以防存入数据库后，产生转义字符
        JSONObject mediaJson = JSONObject.parseObject(JSONObject.toJSONString(media));
        mediaJson.put("messageId", String.valueOf(messageId));

        historyMessage.setContent(mediaJson.toJSONString());
        historyMessage.setSource(jGroupMessage.getSource());
        historyMessage.setType(dataMeta.getChatType());
        historyMessage.setCreateTime(System.currentTimeMillis());
        historyMessage.setUserId(dataMeta.getFrom());
        historyMessage.setStatus(1);
        if (jGroupMessage.getToUid() != null) {
            for (long uid : jGroupMessage.getToUid()) {
                historyMessage.setSessionId(dataMeta.getFrom() >= uid ? dataMeta.getFrom() + "_" + uid : uid + "_" + dataMeta.getFrom());
                historyMessageService.receiveMessage(historyMessage);
            }
        } else {
            if (dataMeta.getChatType() == ChatTypeEnum.ROOM.getType()) {
                historyMessage.setSessionId(String.valueOf(dataMeta.getTo()));
            } else {
                historyMessage.setSessionId(dataMeta.getFrom() >= dataMeta.getTo() ? dataMeta.getFrom() + "_" + dataMeta.getTo() : dataMeta.getTo() + "_" + dataMeta.getFrom());
            }
            historyMessageService.receiveMessage(historyMessage);
        }

        //在此处发送回执
        this.doResponse0(jGroupMessage, dataMeta.getFrom(), ResponseCode.MSG_MEDIA_OK);

        // 设置转发类型
        jGroupMessage.setSourceAdd(null);
        jGroupMessage.setSendType(JGroupMessage.SendType.MULTI.getValue());

        return jGroupMessage;
    }
}
