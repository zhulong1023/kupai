package com.kupai.gateway.route.handler;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.contants.MessageType;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.data.DataMeta;
import com.kupai.gateway.common.data.Syc;
import com.kupai.gateway.common.data.enumpac.ChatTypeEnum;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.unread.UnReadNumService;
import com.kupai.gateway.route.handler.processor.DefaultRequestProcessor;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.model.HistoryMessage;
import com.kupai.gateway.route.service.syc.SycSessionRootMessageFolderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 客户端发起syc请求
 * Created by Administrator on 2017/3/31.
 */
@Component
public class SycMessageProcessHandler extends AbstractProcessHandler {

    @Autowired
    private SycSessionRootMessageFolderService sycSessionRootMessageFolderService;

    @Autowired
    private UnReadNumService unReadNumService;

    /**
     * 注册该处理器
     */
    @PostConstruct
    protected void registerHandler() {
        DefaultRequestProcessor.registerProcessHandler(RequestCode.SYC, this);
    }


    /**
     * 处理消息的转发
     *
     * @param jGroupMessage
     */
    @Override
    protected JGroupMessage doProcess0(JGroupMessage jGroupMessage) {
        ApiLogger.message("syc message start, message info " + jGroupMessage.toString());
        Syc syc = (Syc) jGroupMessage.getData();
        DataMeta dataMeta = syc.getMeta();
        //获取消息列表，和最新的id
        Integer source = jGroupMessage.getSource();
        String messageId = syc.getMessageId();
        String sessionId = "";
        int chatType = dataMeta.getChatType();
        if (ChatTypeEnum.parser(chatType) == ChatTypeEnum.ROOM) {
            sessionId = String.valueOf(dataMeta.getTo());
        } else if (ChatTypeEnum.parser(chatType) == ChatTypeEnum.SINGLE) {
            sessionId = dataMeta.getFrom() >= dataMeta.getTo() ? dataMeta.getFrom() + "_" + dataMeta.getTo() : dataMeta.getTo() + "_" + dataMeta.getFrom();
            unReadNumService.updateUserUnReadNumTo0(sessionId, String.valueOf(dataMeta.getFrom()));
        }
        Map<String, Object> map = sycSessionRootMessageFolderService.getMessageListByMessageId(String.valueOf(source), sessionId, syc.getPullType(), messageId, syc.getPageSize(), String.valueOf(dataMeta.getFrom()));
        JSONArray jsonArray = new JSONArray();
        if (null != map && map.size() > 0) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            syc.setMessageId((String) map.get("messageId"));
            @SuppressWarnings("unchecked")
            List<HistoryMessage> list = (List<HistoryMessage>) map.get("messageList");
            for (int i = 0; i < list.size(); i++) {
                HistoryMessage message = list.get(i);
                JSONObject jsonObject = JSONObject.parseObject(message.getContent());
                jsonObject.put("createTime", simpleDateFormat.format(new Date(message.getCreateTime())));
                jsonArray.add(jsonObject);
            }
            syc.setMessage(jsonArray);
        } else {
            syc.setMessageId(sycSessionRootMessageFolderService.getHistoryMaxMessageId(sessionId));
            syc.setMessage(jsonArray);
        }
        dataMeta.setEvent("syc_message");

        syc.setMeta(dataMeta);
        jGroupMessage.setFrom(dataMeta.getFrom());
        List<Long> toUids = new ArrayList<>(1);
        toUids.add(dataMeta.getFrom());
        jGroupMessage.setCode(ResponseCode.SYC_MESSAGE_SUCCESS);
        jGroupMessage.setToUid(toUids);
        jGroupMessage.setData(syc);
        jGroupMessage.setOneWay(true);
        jGroupMessage.setType(MessageType.RESPONSE.getType());
        return jGroupMessage;
    }
}
