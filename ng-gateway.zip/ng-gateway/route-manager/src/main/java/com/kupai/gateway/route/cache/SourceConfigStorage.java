/**
 * 
 */
package com.kupai.gateway.route.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.kupai.gateway.common.contants.KeyRepertory;
import com.kupai.gateway.common.model.SourceConfig;

import redis.clients.jedis.JedisCluster;

/**
 * @author zhouqisheng 2017年4月10日
 */
@Component
public class SourceConfigStorage {

    @Autowired
    private JedisCluster jedisCluster;

    public void setSourceConfig(int source, SourceConfig sourceConfig) {
          this.jedisCluster.hset(KeyRepertory.SOURCE_CONFIG, String.valueOf(source), JSON.toJSONString(sourceConfig));
    }

}
