package com.kupai.gateway.route.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicLong;

/**
 * 服务内部运行状态监控服务类
 * <p>
 * 1. 监控JVM运行状态(内存,CPU使用率等)
 * 2. 统计每个拍卖间的连接数,在线时长等
 * 3. 统计消息发送量以及接受量
 * </p>
 * Date: 16/11/22
 * Time: 下午5:15
 *
 * @author lintc
 */

@Service("monitorService")
public class MonitorService {
    private static final Logger LOGGER = LoggerFactory.getLogger(MonitorService.class);
    /**
     * IM服务器的消息计数器
     */
    private AtomicLong imMessageCounter = new AtomicLong(0);

    /**
     * 网关推送的消息计数器
     */
    private AtomicLong pushMessageCounter = new AtomicLong(0);

    /**
     * 接收来自其他集群广播的消息计数器
     */
    private AtomicLong jgroupReceiveMessageCounter = new AtomicLong(0);


    /**
     * 向其他集群发送的消息计数器
     */
    private AtomicLong jgroupSendMessageCounter = new AtomicLong(0);

    /**
     * 叫价服务发送的消息量
     */
    private AtomicLong bidServicePostMessageCounter = new AtomicLong(0);

    /**
     * 发送评论的消息计数器
     */
    private AtomicLong commentMessageCounter = new AtomicLong(0);

    /**
     * 出价的消息计数器
     */
    private AtomicLong bidAddMessageCounter = new AtomicLong(0);

    public void incrementImMessage() {
        imMessageCounter.incrementAndGet();
    }

    public void incrementPushMessage() {
        pushMessageCounter.incrementAndGet();
    }

    public void incrementJgroupSendMessage() {
        jgroupSendMessageCounter.incrementAndGet();
    }

    public void incrementJgroupReceiveMessage() {
        jgroupReceiveMessageCounter.incrementAndGet();
    }


    public void incrementBidServicePostMessage() {
        bidServicePostMessageCounter.incrementAndGet();
    }

    public void incrementBidAddMessage() {
        bidAddMessageCounter.incrementAndGet();
    }

    public void incrementCommentMessage() {
        commentMessageCounter.incrementAndGet();
    }

    public String statisticsMessageCounter() {
        JSONArray counterArray = new JSONArray();
        JSONObject imMessageJsonObject = new JSONObject();
        imMessageJsonObject.put("type", "imMessage");
        imMessageJsonObject.put("counter", imMessageCounter.get());
        counterArray.add(imMessageJsonObject);

        JSONObject pushMessageJsonObject = new JSONObject();
        pushMessageJsonObject.put("type", "pushMessage");
        pushMessageJsonObject.put("counter", pushMessageCounter.get());
        counterArray.add(pushMessageJsonObject);

        JSONObject jgroupSendMessageJsonObject = new JSONObject();
        jgroupSendMessageJsonObject.put("type", "jgroupSendMessage");
        jgroupSendMessageJsonObject.put("counter", jgroupSendMessageCounter.get());
        counterArray.add(jgroupSendMessageJsonObject);

        JSONObject jgroupReceiveMessageJsonObject = new JSONObject();
        jgroupReceiveMessageJsonObject.put("type", "jgroupReceiveMessage");
        jgroupReceiveMessageJsonObject.put("counter", jgroupReceiveMessageCounter.get());
        counterArray.add(jgroupReceiveMessageJsonObject);

        JSONObject commentMessageJsonObject = new JSONObject();
        commentMessageJsonObject.put("type", "commentMessage");
        commentMessageJsonObject.put("counter", commentMessageCounter.get());
        counterArray.add(commentMessageJsonObject);

        JSONObject bidAddMessageJsonObject = new JSONObject();
        bidAddMessageJsonObject.put("type", "bidAddMessage");
        bidAddMessageJsonObject.put("counter", bidAddMessageCounter.get());
        counterArray.add(bidAddMessageJsonObject);
        return counterArray.toJSONString();
    }

    /**
     * 每隔五分钟打印一次系统的消息状态信息
     */
    @Scheduled(initialDelay = 60 * 1000l, fixedDelay = 5 * 60 * 1000l)
    public void displayMessageCounter() {
        LOGGER.info(String.format("[message-counter] details=%s", statisticsMessageCounter()));
    }
}
