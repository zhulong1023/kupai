package com.kupai.gateway.route.dao;


import com.kupai.gateway.route.model.ForbidWord;

import java.util.List;
import java.util.Map;

/**
 * Created by zhulong on 2017/3/24.
 * 敏感词Dao
 */
public interface ForbidWordDao {
    /**
     * 增加ForbidWord
     * @param forbidWord
     * @return
     */
    boolean add(ForbidWord forbidWord);

    /**
     *批量增加ForbidWord
     * @param forbidWordList
     * @return
     */
    boolean batchAdd(List<ForbidWord> forbidWordList);

    /**
     * 修改ForbidWord
     * @param word
     * @return
     */
    boolean updateInfor(ForbidWord word);

    /**
     * 根据类型删除敏感词
     * @param type
     * @return
     */
    boolean delByType(String type);

    /**
     * 查询所有ForbidWord
     * @param source
     * @return
     */
    List<ForbidWord> queryAll(int source) ;

    /**
     * 分页查询
     * @param name
     * @param page
     * @param num
     * @return
     */
    List<Map<String, Object>> queryForbidWords(String name, int page, int num);

    /**
     * 统计数据
     * @param name
     * @return
     */
    long queryCountForbid(String name) ;


}
