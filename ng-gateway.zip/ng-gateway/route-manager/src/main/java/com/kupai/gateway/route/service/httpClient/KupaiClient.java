package com.kupai.gateway.route.service.httpClient;

import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.Map;

/**
 * Created by Administrator on 2017/2/23.
 */
public interface KupaiClient{
    /**
     * post请求接口
     * @param headerMap header列表
     * @param fieldMap 参数列表
     * @return
     */
    @FormUrlEncoded
    @POST
    Call<JsonObject> sendPrice(@Url String url, @HeaderMap Map<String, String> headerMap, @FieldMap Map<String, String> fieldMap);
}
