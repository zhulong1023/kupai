/**
 * 
 */
package com.kupai.gateway.route.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.util.IdWorker;

/**
 * @author zhouqisheng
 * 2017年3月30日
 */
@RestController
@RequestMapping("/mock")
public class MockController {
    @Autowired
    private IdWorker idWorker;

    /**
     *
     * @param passport
     * @return
     */
    @RequestMapping(value = "/auth/callback", produces = {"application/json;charset=UTF-8"}, method=RequestMethod.GET)
    @ResponseBody
    public Object mockAuthCallback(String passport){
        JSONObject ret = new JSONObject();
        ret.put("uid", idWorker.nextId());
        ret.put("pass", 1);
        ret.put("name", "测试用户");
        JSONObject ext = new JSONObject();
        ext.put("pic", "sadfasdsdafasd");
        ret.put("ext", ext);
        return ret;
    }

}
