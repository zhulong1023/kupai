package com.kupai.gateway.route.annocations;

/**
 * Created by zhangrui on 16/3/14.
 */
public enum AuthType {
    OPTION(false),  //访客调用接口使用该控
    REQUIRED(true); //需要验证需要该控制，用于app接口

    //授权失败是否抛出异常
    private boolean authFailThrowException;

    private AuthType(boolean authFailThrowException) {
        this.authFailThrowException = authFailThrowException;
    }

    public boolean authFailThrowException() {
        return this.authFailThrowException;
    }
}