package com.kupai.gateway.route.handler;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.data.DataMeta;
import com.kupai.gateway.common.data.Media;
import com.kupai.gateway.common.data.Text;
import com.kupai.gateway.common.data.enumpac.ChatTypeEnum;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.ResponseIdGen;
import com.kupai.gateway.common.unread.UnReadNumService;
import com.kupai.gateway.route.service.MessageDispatchService;
import com.kupai.gateway.route.service.syc.SycSessionRootMessageFolderService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/3/28.
 */
public abstract class AbstractProcessHandler implements ProcessHandler {

    @Autowired
    private MessageDispatchService messageDispatchService;

    @Autowired
    private SycSessionRootMessageFolderService sycSessionRootMessageFolderService;

    @Autowired
    private UnReadNumService unReadNumService;

    /**
     * 处理接收到的消息
     *
     * @param jGroupMessage
     * @return
     */
    @Override
    public void doProcess(JGroupMessage jGroupMessage) {
        if (null != jGroupMessage) {
            JGroupMessage ret = this.doProcess0(jGroupMessage);
            ret = this.sycNotice(ret);
            if (ret == null) {
                return;
            }
            //如果是广播类型的消息，则重新由服务端生成requestId
            if (jGroupMessage.getSendType() == JGroupMessage.SendType.MULTI.getValue()) {
                jGroupMessage.setRequestId(ResponseIdGen.getResponseId());
            }
            messageDispatchService.forward(ret);
        }
    }

    /**
     * 处理消息的转发
     *
     * @param jGroupMessage
     */
    protected abstract JGroupMessage doProcess0(JGroupMessage jGroupMessage);

    /**
     * 回执，消息问success
     *
     * @param jGroupMessage
     * @param fromUid
     * @param responseCode
     */
    protected void doResponse0(JGroupMessage jGroupMessage, Long fromUid, int responseCode) {
        if (jGroupMessage.getSourceAdd() == null)
            return;
        JGroupMessage jGroupMessageRes = JGroupMessage.buildResponse(jGroupMessage, fromUid, responseCode);
        messageDispatchService.forward(jGroupMessageRes);
    }

    /**
     * 回执
     *
     * @param jGroupMessage
     * @param fromUid
     * @param responseCode
     * @param data
     */
    protected void doResponse0(JGroupMessage jGroupMessage, Long fromUid, int responseCode, Object data) {
        if (jGroupMessage.getSourceAdd() == null)
            return;
        JGroupMessage jGroupMessageRes = JGroupMessage.buildResponse(jGroupMessage, fromUid, responseCode, data);
        messageDispatchService.forward(jGroupMessageRes);
    }

    /**
     * 组装syc通知
     */
    protected JGroupMessage sycNotice(JGroupMessage jGroupMessage) {
        //发送syc消息
        if (null != jGroupMessage && (jGroupMessage.getCode() == RequestCode.MSG_TEXT || jGroupMessage.getCode() == RequestCode.MSG_MEDIA)) {
            //得到用户读取到的位置
            String sessionId = "";
            DataMeta dataMeta = null;
            if (jGroupMessage.getCode() == RequestCode.MSG_MEDIA) {
                Media media = (Media) jGroupMessage.getData();
                dataMeta = media.getMeta();
            } else {
                Text text = (Text) jGroupMessage.getData();
                dataMeta = text.getMeta();
            }

            //获得sessionId
            if (jGroupMessage.getToUid() == null) {
                if (dataMeta.getChatType() == ChatTypeEnum.ROOM.getType()) {
                    sessionId = String.valueOf(dataMeta.getTo());
                    jGroupMessage.setRoomId(dataMeta.getTo());
                } else if (dataMeta.getChatType() == ChatTypeEnum.SINGLE.getType()) {
                    sessionId = String.valueOf(dataMeta.getFrom() >= dataMeta.getTo() ? dataMeta.getFrom() + "_" + dataMeta.getTo() : dataMeta.getTo() + "_" + dataMeta.getFrom());
                    List<Long> to = new ArrayList<>(2);
                    to.add(dataMeta.getFrom());
                    to.add(dataMeta.getTo());
                    jGroupMessage.setToUid(to);
                    //增加消息未读数
                    unReadNumService.incrUserUnReadNum(sessionId, String.valueOf(dataMeta.getTo()));
                }
            } else {
                List<Long> toUidArr = jGroupMessage.getToUid();
                for (Long toUid : toUidArr) {
                    List<Long> toUids = new ArrayList<>(1);
                    toUids.add(toUid);
                    sessionId = dataMeta.getFrom() >= toUid ? dataMeta.getFrom() + "_" + toUid : toUid + "_" + dataMeta.getFrom();
                    //获得用户未读的最大消息messageId
                    String maxMessageId = sycSessionRootMessageFolderService.getHistoryMaxMessageId(sessionId);
                    JGroupMessage _jGroupMessage = JGroupMessage.buildToUidResponse(jGroupMessage, toUids, Long.valueOf(maxMessageId));
                    messageDispatchService.forward(_jGroupMessage);
                }
                return null;
            }

            //获得用户未读的最大消息messageId
            String maxMessageId = sycSessionRootMessageFolderService.getHistoryMaxMessageId(sessionId);

            jGroupMessage.setMsgId(Long.valueOf(maxMessageId));
            return jGroupMessage;
        }
        return jGroupMessage;
    }
}
