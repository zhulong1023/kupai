package com.kupai.gateway.route.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.contants.RequestCode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.kupai.gateway.route.annocations.ApiStatus;
import com.kupai.gateway.route.annocations.AuthType;
import com.kupai.gateway.route.annocations.BaseInfo;
import com.kupai.gateway.route.annocations.SignType;
import com.kupai.gateway.route.data.Result;
import com.kupai.gateway.route.exception.ErrorResultCode;
import com.kupai.gateway.route.exception.RouteManagerExceptionUtils;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.service.GwPushMessageService;
import com.kupai.gateway.route.service.MonitorService;


/**
 * Created by zhaoshengqi on 2017/3/30.
 */
@RestController
@RequestMapping(value = "/route/api/")
public class GwPushMessageController {

    @Autowired
    private MonitorService monitorService;

    @Autowired
    private GwPushMessageService pushMessageService;

    /**
     * 为外部服务提供推送消息接口
     *
     * @param source   来源系统
     * @param chatType 聊天类型 1个人 2房间
     * @param code     requestCode
     * @param event    事件
     * @param from     发送者UID
     * @param roomId   房间ID
     * @param toIds    接收ID(支持多个)
     * @param data     内容
     * @param ext      扩展信息 【json格式】
     * @return
     */
    @RequestMapping(value = "handleMessage", method = RequestMethod.POST, produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> handleMessage(HttpServletRequest request,
                                        @RequestParam(name = "source", required = true) int source,
                                        @RequestParam(name = "chatType", required = true) int chatType,
                                        @RequestParam(name = "code", required = true) int code,
                                        @RequestParam(name = "event", required = true, defaultValue = "query") String event,
                                        @RequestParam(name = "from", required = true) long from,
                                        @RequestParam(name = "roomId", required = false,defaultValue = "0") long roomId,
                                        @RequestParam(name = "toIds", required = false) String toIds,
                                        @RequestParam(name = "data", required = true) String data,
                                        @RequestParam(name = "ext", required = false) String ext) {
        Result<Object> result = new Result<>(true);

        ApiLogger.info(String.format("[message-service-message] receive message from other service server, source=%s, event=%s" +
                ", data=%s, from=%s,roomId=%s, toIds=%s, ext=%s", source, event, data, from,roomId, toIds, data, ext));
        monitorService.incrementBidServicePostMessage();
        if ((roomId==0 && StringUtils.isBlank(toIds)) || (roomId!=0 && StringUtils.isNotBlank(toIds))){
            throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.PARAM_ID_ERROR);
        }

        if(code!= RequestCode.MSG_TEXT && code != RequestCode.MSG_NOTICE){
            throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.PARAM_CODE_ERROR);
        }
        //如果ext存在，则验证ext是否是json
        JSONObject jsonObject = null;
        if (StringUtils.isNotBlank(ext)) {
            try {
                jsonObject = JSON.parseObject(ext);
            } catch (Exception e) {
                throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.PARAM_JSON_ERROR);
            }
        }

        Map<String, Object> resultMap = pushMessageService.handleMessage(source,event,from,roomId,toIds,data,jsonObject,code,chatType);

        result.setData(resultMap);
        return result;
    }
}
