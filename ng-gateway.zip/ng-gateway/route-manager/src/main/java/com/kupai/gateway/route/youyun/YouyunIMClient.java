package com.kupai.gateway.route.youyun;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.net.InetSocketAddress;

/**
 * 又云的IM客户端
 */
//@Service("youyunIMClient")
public class YouyunIMClient {
    private static Logger LOGGER = LoggerFactory.getLogger(LoggerFactory.class);

    @Autowired
    private MessageHandler messageHandler;
    @Value("${youyun.client.ip}")
    private String host;
    @Value("${youyou.client.port}")
    private int port;

    private GWConnection gwConnection;

    @PostConstruct
    public void start() {
        gwConnection = new GWConnection();
        LOGGER.info(String.format("begin to connect host %s, port %s", host, port));
        if (gwConnection.start(new InetSocketAddress(host, port), messageHandler)) {
            LOGGER.info("start youyun IM client");
        } else {
            LOGGER.error(String.format("IM client start failed, host %s, port %s", host, port));
        }
    }


    @PreDestroy
    public void stop() {
        if (null != gwConnection) {
            gwConnection.stop();
        }
    }

}
