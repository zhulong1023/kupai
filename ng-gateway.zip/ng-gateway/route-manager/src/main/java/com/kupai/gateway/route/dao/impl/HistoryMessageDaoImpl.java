package com.kupai.gateway.route.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.util.StringUtils;
import com.kupai.gateway.route.dao.HistoryMessageDao;
import com.kupai.gateway.route.model.HistoryMessage;

/**
 * Created by zhaoshengqi on 2017/3/21.
 */
@Service
public class HistoryMessageDaoImpl implements HistoryMessageDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static final String SELECT_ITEM = "SELECT * FROM history_message where 1=1 ";
    private static final String SELECT_BY_ID = "SELECT * FROM history_message where id=? ";
    private static final String SELECT_BY_IDS = "SELECT * FROM history_message where id in ( ";
    private static final String UPDATE_STATUS = "UPDATE history_message SET STATUS=0 WHERE id IN ( ";
    private static final String INSERT_MESSAGE = "INSERT INTO history_message (id,type,content,session_id," +
            "user_id,create_time,source) VALUES (?,?,?,?,?,?,?)";

    @Override
    public List<HistoryMessage> queryHistoryMessage(long msgId, String sessionId, long userId, int type,int status) {
        StringBuilder sql = new StringBuilder(SELECT_ITEM);
        List<Object> params = new ArrayList<>();

        if(msgId > 0){
            sql.append(" and id=?");
            params.add(msgId);
        }   
        if(StringUtils.isNotBlank(sessionId)){
            sql.append(" and session_id=?");
            params.add(sessionId);
        }

        if(userId > 0){
            sql.append(" and user_id=?");
            params.add(userId);
        }
        if(type > -1){
            sql.append(" and type=?");
            params.add(type);
        }
        if(status > -1){
            sql.append(" and status=?");
            params.add(status);
        }

        sql.append(" order by id ");
        return jdbcTemplate.query(sql.toString(),params.toArray(), new BeanPropertyRowMapper<HistoryMessage>(HistoryMessage.class));
    }

    @Override
    /**
     * 添加数据
     */
    public boolean addHistoryMessage(HistoryMessage historyMessage) {

        return jdbcTemplate.update(INSERT_MESSAGE,new Object[]{historyMessage.getId(),historyMessage.getType(), historyMessage
                .getContent(), historyMessage.getSessionId(), historyMessage.getUserId(), historyMessage
                .getCreateTime(),historyMessage.getSource()})>0 ;

    }

    @Override
    public boolean updateStatusByIds(String msgIds) {
        StringBuilder sql = new StringBuilder(UPDATE_STATUS);
        sql.append(msgIds);
        sql.append(")");
        return jdbcTemplate.update(sql.toString(),new Object[]{})>0;
    }

    @Override
    public List<HistoryMessage> getHistoryMessageByIds(String msgIds) {
        StringBuilder sql = new StringBuilder(SELECT_BY_IDS);
        sql.append(msgIds);
        sql.append(")");
        return jdbcTemplate.query(sql.toString(),new Object[]{}, new BeanPropertyRowMapper<HistoryMessage>(HistoryMessage.class));
    }

    @Override
    public HistoryMessage getHistoryMessageById(long msgId) {

        return jdbcTemplate.queryForObject(SELECT_BY_ID,new Object[]{msgId},new BeanPropertyRowMapper<HistoryMessage>(HistoryMessage.class));
    }
}
