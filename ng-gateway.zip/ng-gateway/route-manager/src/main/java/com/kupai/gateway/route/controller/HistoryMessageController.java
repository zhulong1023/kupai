package com.kupai.gateway.route.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.route.data.Result;
import com.kupai.gateway.route.exception.ErrorResultCode;
import com.kupai.gateway.route.exception.RouteManagerExceptionUtils;
import com.kupai.gateway.route.model.HistoryMessage;
import com.kupai.gateway.route.service.HistoryMessageService;

/**
 * Created by zhaoshengqi on 2017/3/21.
 */
@RestController
@RequestMapping(value = "/route/message")
public class HistoryMessageController {

    @Autowired
    private HistoryMessageService historyMessageService;

    /**
     * 查询消息列表
     * @param sessionId 场景ID(roomID/toid+uid)
     * @param msgId 消息查询标识(传最后一条消息的ID,传0或不传查询最新消息)
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "selectMessageList",method = RequestMethod.POST,
            produces = {"application/json;charset=UTF-8"})
    public Object selectMessageList(HttpServletRequest request,
                                    @RequestParam(name = "msgId", required = false, defaultValue = "0") long msgId,
                                    @RequestParam(name = "sessionId", required = true) String sessionId,
                                    @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize){
        if (pageSize <= 0){
            throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.PAGE_FORMAT_ERROR);
        }
        Result<Object> result = new Result<>(true);
        List<HistoryMessage> historyMessageList = historyMessageService.queryHistoryMessage(msgId,sessionId,pageSize);
        if(CollectionUtils.isNotEmpty(historyMessageList)) {
            result.setData(JSONObject.toJSON(historyMessageList));
            return result;
        }
        throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.NO_RESULT_FIND_ERROR);

    }

    /**
     * 消息删除
     * @param msgIds
     * @return
     */
    @RequestMapping(value = "deleteMessage",method = RequestMethod.POST, produces = {"application/json;charset=UTF-8"})
    public Result<Object> deleteMessage(@RequestParam(name = "msgIds", required = true) String msgIds){
        boolean result = historyMessageService.deleteMessage(msgIds);

        return new Result<>(result);
    }

    /**
     * 查询已删除消息
     * @param sessionId 场景ID(roomID/toid+uid)
     * @return
     */
    @RequestMapping(value = "selectInvalidMessageList",method = RequestMethod.POST,
            produces = {"application/json;charset=UTF-8"})
    public Object selectInvalidMessageList(@RequestParam(name = "sessionId", required = true) String sessionId){

        Result<Object> result = new Result<>(true);
        List<HistoryMessage> historyMessageList = historyMessageService.queryInvalidHistoryMessage(sessionId);
        if(CollectionUtils.isNotEmpty(historyMessageList)) {
            result.setData(JSONObject.toJSON(historyMessageList));
            return result;
        }
        throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.NO_RESULT_FIND_ERROR);

    }
}
