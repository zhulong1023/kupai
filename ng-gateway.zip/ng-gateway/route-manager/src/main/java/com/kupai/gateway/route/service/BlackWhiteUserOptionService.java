package com.kupai.gateway.route.service;

import java.util.Map;

/**
 * Created by Administrator on 2017/3/29.
 */
public interface BlackWhiteUserOptionService {

    /**
     * 维护黑白名单用户
     *
     * @param source 系统
     * @param org    机构
     * @param uids   用户uid列表
     * @param type   类型 1 黑名单  2 白名单
     * @param status 0 取消禁言  1 禁言
     * @return
     */
    boolean setBlackWhiteUser(String source, String org, String uids, Integer type, Integer status, Long gagTime);

    /**
     * 维护机构对应的黑白名单房间list
     *
     * @param source 系统
     * @param org    机构
     * @param rooms  房间列表
     * @param type   类型 1 黑名单  2 白名单
     * @param status 0 取消禁言  1 禁言
     * @return
     */
    boolean setBlackWhiteRoom(String source, String org, String rooms, Integer type, Integer status);

    /**
     * 获得黑白名单列表
     *
     * @param source 系统
     * @param room  房间列表
     * @param type   类型 1 黑名单  2 白名单
     * @return
     */
    Map<String, String> getUserList(String source, String room, Integer type);

    /**
     * 获得黑白名单列表
     *
     * @param source 系统
     * @param room  房间列表
     * @param type   类型 1 黑名单  2 白名单
     * @return
     */
    boolean isBlackUser(String uid, String source, String room, Integer type);
}
