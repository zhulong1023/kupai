package com.kupai.gateway.route.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 黑名单数据对象---》对应数据库
 * Created by Administrator on 2017/3/23.
 */
@SuppressWarnings("serial")
public class BlackUserDO implements Serializable{
    private Long id;
    private String source;
    private String uid;
    private Long gagTime;
    private Long invalidTime;
    private String createUser;
    private Date createTime;
    private Date modifyTime;
    private String modifyUser;
    private Integer yn;

    public BlackUserDO() {
    }

    public BlackUserDO(String source, String uid, Long gagTime, Long invalidTime, String createUser) {
        this.source = source;
        this.uid = uid;
        this.gagTime = gagTime;
        this.invalidTime = invalidTime;
        this.createUser = createUser;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public Long getGagTime() {
        return gagTime;
    }

    public void setGagTime(Long gagTime) {
        this.gagTime = gagTime;
    }

    public Long getInvalidTime() {
        return invalidTime;
    }

    public void setInvalidTime(Long invalidTime) {
        this.invalidTime = invalidTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Integer getYn() {
        return yn;
    }

    public void setYn(Integer yn) {
        this.yn = yn;
    }
}
