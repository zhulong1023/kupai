package com.kupai.gateway.route.interceptor;


import com.kupai.gateway.route.context.RouteManagerContext;
import com.kupai.gateway.route.log.ApiLogger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 所有拦截器都正确执行后的请求日志记录，拦截器抛出异常后由ApiHandlerExceptionResolver打印request日志
 * Created by zhangrui on 16/3/31.
 */
public class ActionLogInterceptor extends HandlerInterceptorAdapter {

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        ApiLogger.request(request, response);
        RouteManagerContext.clear();
    }

}
