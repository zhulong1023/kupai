package com.kupai.gateway.route.handler;

import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.data.*;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.JGroupsMessageHandler;
import com.kupai.gateway.common.jgroups.JGroupsNode;
import com.kupai.gateway.common.registry.AbstractRegistry;
import com.kupai.gateway.route.dao.HistoryMessageDao;
import com.kupai.gateway.route.filter.MessageFilter;
import com.kupai.gateway.route.handler.processor.DefaultRequestProcessor;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.model.HistoryMessage;
import com.kupai.gateway.route.service.MonitorService;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.TreeMap;

/**
 * 处理从connection-manager中获取的消息 Created by Administrator on 2017/3/21.
 */
@Service("jgroupsMessageHandler")
public class ReceiveMessageHandler extends AbstractRegistry<MessageFilter> implements JGroupsMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReceiveMessageHandler.class);

    @Autowired
    private MonitorService monitorService;

    @Autowired
    private DefaultRequestProcessor defaultRequestProcessor;

    @Autowired
    private JGroupsNode jGroupsNode;

    @Resource(name = "historyMessageCache")
    private CaffeineCache historyMessageCache;

    @Autowired
    private HistoryMessageDao historyMessageDao;

    /**
     * 对jgroups中接收到的消息进行处理 在route-manager中只处理connection-manager中过来的点对点消息
     *
     * @param jGroupMessage
     */
    @Override
    public void messageHandler(JGroupMessage jGroupMessage) {
        int messageType = jGroupMessage.getSendType();
        JGroupMessage.SendType type = JGroupMessage.SendType.getSendType(messageType);
        try {
            if (type == JGroupMessage.SendType.P2P) {
                monitorService.incrementJgroupReceiveMessage();

                //反序列化
                this.deserialize(jGroupMessage);
                // 消息发送
                TreeMap<Integer, MessageFilter> codeFilters = this.registrants.get(jGroupMessage.getCode());
                if (codeFilters != null) {
                    for (MessageFilter filter : codeFilters.values()) {
                        if (!filter.preHandler(jGroupsNode, jGroupMessage)) {
                            return;
                        }
                    }
                }

                Throwable ex = null;
                try {
                    defaultRequestProcessor.processRequest(jGroupMessage);
                } catch (Exception e) {
                    ex = e;
                    LOGGER.error("handler message error, msg = {}", jGroupMessage, e);
                } finally {
                    if (codeFilters != null) {
                        for (MessageFilter filter : codeFilters.descendingMap().values()) {// 消息处理后过滤与处理前过滤反序，即安filter
                            // order的降序执行
                            if (!filter.afterHandler(jGroupsNode, jGroupMessage, ex)) {
                                return;
                            }
                        }
                    }
                }
            } else {
                // 多rm缓存同步
                if (jGroupMessage.getCode() == RequestCode.MSG_TEXT || jGroupMessage.getCode() == RequestCode.MSG_MEDIA) {
                    HistoryMessage historyMessage = historyMessageDao.getHistoryMessageById(jGroupMessage.getMsgId());

                    @SuppressWarnings("unchecked")
                    List<HistoryMessage> list = (List<HistoryMessage>) historyMessageCache.getNativeCache().asMap().get(historyMessage.getSessionId());
                    if (CollectionUtils.isNotEmpty(list)) {
                        list.add(historyMessage);
                        ApiLogger.info("ReceiveMessageHandler messageHandler add CaffeineCache SUCCESS, sessionId=:" + historyMessage.getSessionId() + "," +
                                "uid=:" + historyMessage.getUserId() + ",content=:" + historyMessage.getContent());
                    } else {
                        list = historyMessageDao.queryHistoryMessage(0, historyMessage.getSessionId(), 0, -1, 1);
                        //更新cache
                        historyMessageCache.put(historyMessage.getSessionId(), list);
                    }
                }else if(jGroupMessage.getCode() == RequestCode.DELETE_MESSAGE){
                    HistoryMessage historyMessage = historyMessageDao.getHistoryMessageById(jGroupMessage.getMsgId());

                    @SuppressWarnings("unchecked")
                    List<HistoryMessage> list = (List<HistoryMessage>) historyMessageCache.getNativeCache().asMap().get(historyMessage.getSessionId());
                    if (CollectionUtils.isNotEmpty(list)) {
                        list.remove(historyMessage);
                        ApiLogger.info("ReceiveMessageHandler messageHandler add CaffeineCache SUCCESS, sessionId=:" + historyMessage.getSessionId() + "," +
                                "uid=:" + historyMessage.getUserId() + ",content=:" + historyMessage.getContent());
                    } else {
                        list = historyMessageDao.queryHistoryMessage(0, historyMessage.getSessionId(), 0, -1, 1);
                        //更新cache
                        historyMessageCache.put(historyMessage.getSessionId(), list);
                    }

                }

            }
        } catch (Exception ex) {
            ApiLogger.error(String.format("jgroup node push message to clients failed. content %s, messageType %s",
                    jGroupMessage.getData(), messageType), ex);
        }
    }

    /**
     * 数据反序列化
     *
     * @param jmsg
     */
    public void deserialize(JGroupMessage jmsg) {

        if (jmsg.getData() == null || !(jmsg.getData() instanceof JSONObject)) {
            return;
        }
        JSONObject data = (JSONObject) jmsg.getData();
        switch (jmsg.getCode()) {
            case RequestCode.AUTH:
                jmsg.setData(data.toJavaObject(Authorization.class));
                break;
            case RequestCode.BID:
                Bid bid = data.toJavaObject(Bid.class);
                bid.getMeta().setFrom(jmsg.getFrom());
                jmsg.setData(bid);
                break;
            case RequestCode.MSG_MEDIA:
                Media media = data.toJavaObject(Media.class);
                media.getMeta().setFrom(jmsg.getFrom());
                jmsg.setData(media);
                break;
            case RequestCode.MSG_TEXT:
                Text text = data.toJavaObject(Text.class);
                text.getMeta().setFrom(jmsg.getFrom());
                jmsg.setData(text);
                break;
            case RequestCode.SYC:
                Syc syc = data.toJavaObject(Syc.class);
                syc.getMeta().setFrom(jmsg.getFrom());
                jmsg.setData(syc);
                break;
            default:
                Command cmd = data.toJavaObject(Command.class);
                cmd.getMeta().setFrom(jmsg.getFrom());
                jmsg.setData(cmd);
                break;
        }
    }
}
