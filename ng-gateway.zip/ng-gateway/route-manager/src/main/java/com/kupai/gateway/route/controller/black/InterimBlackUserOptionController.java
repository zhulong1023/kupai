package com.kupai.gateway.route.controller.black;

import com.kupai.gateway.route.annocations.ApiStatus;
import com.kupai.gateway.route.annocations.AuthType;
import com.kupai.gateway.route.annocations.BaseInfo;
import com.kupai.gateway.route.annocations.SignType;
import com.kupai.gateway.route.data.Result;
import com.kupai.gateway.route.service.InterimBlackUserOptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 房间临时禁言操作接口类
 * Created by Administrator on 2017/3/29.
 */
@RestController
@RequestMapping("/route/api/black/interim")
public class InterimBlackUserOptionController {

    @Autowired
    private InterimBlackUserOptionService interimBlackUserOptionService;

    /**
     * 添加临时禁言黑名单
     *
     * @param source        来源
     * @param roomId        房间号
     * @param uid           被禁言人
     * @param gagTime 禁言时长 单位s 默认30s
     * @return
     */
    @RequestMapping(value = "/add.json", method = RequestMethod.POST, produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.PUBLIC, needAuth = AuthType.REQUIRED, needSign = SignType.NOTNEED)
    public Result<Object> addInterimBlack(
            @RequestParam(name = "source", required = true) String source,
            @RequestParam(name = "roomId", required = true) String roomId,
            @RequestParam(name = "uid", required = true) String uid,
            @RequestParam(name = "gagTime", required = false, defaultValue = "30") Long gagTime) {
        boolean flag = interimBlackUserOptionService.addInterimBlack(source, roomId, uid, gagTime);
        return new Result<>(flag);
    }
}
