package com.kupai.gateway.route.controller;

import com.kupai.gateway.route.annocations.ApiStatus;
import com.kupai.gateway.route.annocations.AuthType;
import com.kupai.gateway.route.annocations.BaseInfo;
import com.kupai.gateway.route.annocations.SignType;
import com.kupai.gateway.route.data.Result;
import com.kupai.gateway.route.service.ChatroomManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhulong on 2017/3/22.
 * 房间管理
 */
@RestController
@RequestMapping(value = "/route/api/chatroom/manage")
public class ChatroomManageController {

    @Autowired
    private ChatroomManageService chatroomManageService;

    /**
     * 创建房间
     * @param source 系统来源
     * @param createId 创建者
     * @return
     */
    @RequestMapping(value = "addChatroom",method = RequestMethod.POST,
            produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> addChatroom(
            @RequestParam(value = "source",required = true) String source,
            @RequestParam(value = "createId",required = true) long createId){
        Map<String,Object> map = new HashMap<String, Object>(1);
        long roomid = chatroomManageService.createRoom(source,createId);
        Result<Object> result = null;
        if(roomid>0){
            result = new Result<>(true);
        }else{
            result = new Result<>(false);
        }
        map.put("roomId",roomid);
        result.setData(map);
        return result;
    }
    
    @RequestMapping(value = "getChatroomUid",method = RequestMethod.GET,
            produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> getChatroomUid(
            @RequestParam(value = "roomId",required = true) long roomId,
            @RequestParam(value = "source",required = true) int source){
        List<Long> ret = chatroomManageService.getChatroomUid(source, roomId);
        Result<Object> result = new Result<Object>(ret);
        return result;
    }
}
