package com.kupai.gateway.route.service;

/**
 * Created by Administrator on 2017/3/29.
 */
public interface InterimBlackUserOptionService {
    /**
     * 添加临时禁言黑名单
     *
     * @param source        来源
     * @param roomId        房间号
     * @param uid           被禁言人
     * @param gagTime 禁言时长
     * @return
     */
    boolean addInterimBlack(String source, String roomId, String uid, Long gagTime);

    /**
     * 验证是否在临时禁言黑名单中
     *
     * @param source 来源
     * @param roomId 房间号
     * @param uid    验证的用户uid
     * @return
     */
    boolean isInInterimBlack(String source, String roomId, String uid);
}
