/**
 * 
 */
package com.kupai.gateway.route.dao;

import java.util.List;

import com.kupai.gateway.common.model.SourceConfig;

/**
 * @author zhouqisheng
 * 2017年4月10日
 */
public interface SourceConfigDao {
    
    /**
     * 查询所有平台配置
     * @return
     */
    List<SourceConfig> getAllSourceConfig();

}
