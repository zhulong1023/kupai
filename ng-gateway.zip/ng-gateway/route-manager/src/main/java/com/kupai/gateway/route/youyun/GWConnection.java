package com.kupai.gateway.route.youyun;

import com.ioyouyun.wchat.protocol.WeimiSort;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Date: 16/11/12
 * Time: 下午2:37
 *
 * @author lintc
 */
public class GWConnection {
    private static final Logger LOGGER = LoggerFactory.getLogger(GWConnection.class);

    private Thread receiveThread;
    private Timer timer;

    private volatile  Selector selector;
    private volatile  SocketChannel socketChannel;

    private final static int heartbeatInterval = 1000;
    //连续发送心跳包失败的最大次数
    private final static int MAX_HEART_BEAT_FAILED_COUNT = 5;
    private AtomicInteger heartbeatFailedCount = new AtomicInteger(0);

    boolean start(InetSocketAddress address, PacketHandler.PacketProcessor processor) {
        //尝试与IM服务器建立连接
        boolean bConnected = connect(address, processor);
        //连接建立成功后,开启数据接收线程和心跳线程
        if (bConnected) {
            //数据接收线程
            receiveThread = new ReceiveThread("IM-Receive-Thread");
            receiveThread.start();

            //心跳线程
            timer = new Timer("IM-Client-Timer");
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    byte[] entity = WeimiUtil.generateRequestEntity("heartbeat",
                            WeimiSort.heartbeat, null, null);
                    try {

                        socketChannel.write(PacketHandler.buildPacket(entity));
                        LOGGER.info(String.format("send heart beat packet successfully, socket channel[%s->%s]",
                                socketChannel.getRemoteAddress(), socketChannel.getLocalAddress()));
                        //成功发送心跳包就需要将失败计数器清零
                        heartbeatFailedCount.set(0);

                    } catch (Throwable t) {
                        //心跳失败计数器+1
                        int failedCount = heartbeatFailedCount.incrementAndGet();
                        //该心跳线程不允许跑飞
                        LOGGER.error("heartbeat error. failed count "+failedCount+", error details: ", t);
                        //判断是否需要重连
                        try {
                            //心跳失败次数达到最大值,重新连接
                            if (failedCount >= MAX_HEART_BEAT_FAILED_COUNT) {
                                //socket channel 是一个损坏的channel, 打印日志时需要特别小心
                                LOGGER.error(String.format("broken socket [%s] heartbeat successive failed count %s more than %s, should reconnect the IM Server.",
                                        socketChannel, failedCount, MAX_HEART_BEAT_FAILED_COUNT));

                                boolean isConnected = connect(address, processor);
                                if(isConnected){
                                    //清零失败计数器
                                    heartbeatFailedCount.set(0);
                                }
                            }
                        } catch (Exception e) {
                            LOGGER.error("do reconnect IM Server failed", e);
                        }
                    }
                }
            }, heartbeatInterval, heartbeatInterval);
        }
        return bConnected;
    }

    /**
     * 检测连接是否存活
     *
     * @param socketChannel 网络套接字连接
     * @return 存活则返回true, 否则为false
     */
    private boolean isAlive(SocketChannel socketChannel){
        return null!=socketChannel && socketChannel.isOpen() && socketChannel.isConnected();
    }


    private boolean connect(InetSocketAddress address, PacketHandler.PacketProcessor processor) {
        boolean bConnected = false;
        try {
            //假如连接已经存在且处于打开状态,先将老的连接关闭
            //socketChannel.isConnected()只是说明客户端发起的链接已经建立好,但是无法解决对端主动关闭该链接的情况.
            if (isAlive(socketChannel)) {
                LOGGER.warn(String.format("socket channel on %s is already opened and connected, close this old connection before create new connection. address: [%s->%s], opened:%s, connected:%s",
                        address, socketChannel.getRemoteAddress(), socketChannel.getLocalAddress(),
                        socketChannel.isOpen(), socketChannel.isConnected()));
                socketChannel.close();
                socketChannel = null;
            }

            //原有的selector 存在则将其关闭

            if (null != selector) {
                selector.close();
            }

            if (null != socketChannel) {
                //关闭原有连接,防止连接泄露
                socketChannel.close();
            }

            //建立socket channel
            socketChannel = SocketChannel.open();
            if (socketChannel.connect(address)) {
                socketChannel.configureBlocking(false);
                selector = Selector.open();
                socketChannel.register(selector, SelectionKey.OP_READ,
                        new PacketHandler(processor));
                bConnected = true;
                LOGGER.info(String.format("connect to IM server successfully, socket_channel local_address %s, remote_address %s",
                        socketChannel.getRemoteAddress(), socketChannel.getRemoteAddress()));
            }
        } catch (IOException e) {
            LOGGER.error("connect to IM Server " + address + " failed", e);
        }
        return bConnected;
    }


    void stop() {
        if (receiveThread != null) {
            LOGGER.info("stop connection and thread");
            try {
                timer.cancel();
                socketChannel.close();
                selector.close();
                receiveThread.interrupt();
            } catch (Exception e) {
                LOGGER.error("stop connection failed",e);
            }
        }
    }

    private class ReceiveThread extends Thread {

        public ReceiveThread(String name){
            super(name);
        }

        @Override
        public void run() {
            LOGGER.info("receive thread start");
            while(!Thread.interrupted()){
                //只有在当前线程被中断的情况下,此接收线程才会结束生命,否则一直运行
                try {
                    if (GWConnection.this.isAlive(socketChannel)) {
                        selector.select(1000);
                        Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
                        while (iterator.hasNext()) {
                            SelectionKey key = iterator.next();
                            PacketHandler reader = (PacketHandler) key.attachment();
                            iterator.remove();
                            if (key.isReadable()) {
                                SocketChannel socketChannel = (SocketChannel) key.channel();
                                if (!reader.read(socketChannel)) {
                                    LOGGER.error("socket read error, local_address=" + socketChannel.getLocalAddress() + ", remote_address" + socketChannel.getRemoteAddress());
                                    key.cancel();
                                }
                            }
                        }
                    }
                } catch (Throwable t) {
                    LOGGER.error("receive thread has encountered exception, socket_channel  " + socketChannel, t);
                }
            }
            LOGGER.info("receive thread exit");
        }
    }
}
