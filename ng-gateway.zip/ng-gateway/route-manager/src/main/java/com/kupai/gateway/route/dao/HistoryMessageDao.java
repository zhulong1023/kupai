package com.kupai.gateway.route.dao;

import com.kupai.gateway.route.model.HistoryMessage;

import java.util.List;

/**
 * Created by zhaoshengqi on 2017/3/21.
 */
public interface HistoryMessageDao {
    /**
     * 查询消息列表
     * @param msgId 0 消息ID
     * @param sessionId 0 SESSIONID
     * @param userId 0 用户ID
     * @param type -1 消息类型
     * @return
     */
    List<HistoryMessage> queryHistoryMessage(long msgId, String sessionId,  long userId, int type,int status);

    /**
     * insert消息
     * @param historyMessage
     * @return
     */
    boolean addHistoryMessage(HistoryMessage historyMessage);

    boolean updateStatusByIds(String msgIds);

    HistoryMessage getHistoryMessageById(long msgId);

    List<HistoryMessage> getHistoryMessageByIds(String msgIds);
}
