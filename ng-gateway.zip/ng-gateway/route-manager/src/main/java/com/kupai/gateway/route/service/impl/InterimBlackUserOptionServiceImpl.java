package com.kupai.gateway.route.service.impl;

import com.kupai.gateway.common.util.TimeUtil;
import com.kupai.gateway.route.cache.black.InterimBlackUserOptionStorage;
import com.kupai.gateway.route.exception.ErrorResultCode;
import com.kupai.gateway.route.exception.RouteManagerExceptionUtils;
import com.kupai.gateway.route.service.InterimBlackUserOptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2017/3/29.
 */
@Service
public class InterimBlackUserOptionServiceImpl implements InterimBlackUserOptionService{

    @Autowired
    private InterimBlackUserOptionStorage interimBlackUserOptionStorage;

    /**
     * 添加临时禁言黑名单
     *
     * @param source        来源
     * @param roomId        房间号
     * @param uid           被禁言人
     * @param gagTime 禁言时长 单位s
     * @return
     */
    @Override
    public boolean addInterimBlack(String source, String roomId, String uid, Long gagTime) {
        Long invalidTime = TimeUtil.getCurrentSeconds() + gagTime;
        boolean flag = interimBlackUserOptionStorage.addInterimBlack(source, roomId, uid, invalidTime);
        if (!flag) {
            throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.SET_BLACK_USER_ERROR);
        }
        return true;
    }

    /**
     * 验证是否在临时禁言黑名单中
     *
     * @param source 来源
     * @param roomId 房间号
     * @param uid    验证的用户uid
     * @return
     */
    @Override
    public boolean isInInterimBlack(String source, String roomId, String uid) {
        return interimBlackUserOptionStorage.isInInterimBlack(source, roomId, uid);
    }
}
