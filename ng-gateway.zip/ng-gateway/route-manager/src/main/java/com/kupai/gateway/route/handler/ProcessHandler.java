/**
 *
 */
package com.kupai.gateway.route.handler;

import com.kupai.gateway.common.jgroups.JGroupMessage;

/**
 * 消息处理接口
 *
 * @author zhouqisheng
 *         2017年3月24日
 */
public interface ProcessHandler {

    /**
     * 处理接收到的消息
     *
     * @param jGroupMessage
     * @return
     */
    void doProcess(JGroupMessage jGroupMessage);
}
