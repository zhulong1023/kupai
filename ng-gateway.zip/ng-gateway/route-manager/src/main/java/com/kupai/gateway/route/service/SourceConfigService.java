/**
 * 
 */
package com.kupai.gateway.route.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.model.SourceConfig;
import com.kupai.gateway.route.cache.SourceConfigStorage;
import com.kupai.gateway.route.dao.SourceConfigDao;

/**
 * @author zhouqisheng 2017年4月10日
 */
@Service
public class SourceConfigService {
    @Autowired
    private SourceConfigDao sourceConfigDao;
    @Autowired
    private SourceConfigStorage sourceConfigStorage;

    @Scheduled(fixedRate = 5 * 60 * 1000)
    public void updateCache() {
        List<SourceConfig> list = sourceConfigDao.getAllSourceConfig();
        if (list != null) {
            for (SourceConfig config : list) {
                sourceConfigStorage.setSourceConfig(config.getSource(), config);
            }
        }
    }

}
