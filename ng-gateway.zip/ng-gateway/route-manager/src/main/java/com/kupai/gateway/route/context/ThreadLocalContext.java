package com.kupai.gateway.route.context;

/**
 * Created by Administrator on 2017/3/21.
 */
public class ThreadLocalContext extends InheritableThreadLocal<RouteManagerContext> {
    /**
     * 上下文信息
     */
    private final static ThreadLocalContext threadLocalContext = new ThreadLocalContext(){
        @Override
        protected RouteManagerContext initialValue() {
            RouteManagerContext routeManagerContext = new RouteManagerContext();
            routeManagerContext.setUniqueRequestId(RequestIdGen.getRequestId());
            return routeManagerContext;
        }
    };

    /**
     * 获得当前线程对象
     * @return
     */
    public static ThreadLocalContext getInstance() {
        return threadLocalContext;
    }
}
