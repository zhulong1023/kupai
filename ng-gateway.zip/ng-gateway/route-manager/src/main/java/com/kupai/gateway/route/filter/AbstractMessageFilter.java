package com.kupai.gateway.route.filter;

import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.JGroupsNode;

/**
 * Created by Administrator on 2017/3/27.
 */
public abstract class AbstractMessageFilter implements MessageFilter {

    /**
     * 处理具体的消息
     * @param jGroupMessage
     */
    @Override
    public abstract boolean preHandler(JGroupsNode jgroupsNode, JGroupMessage jGroupMessage);

    /**
     * 后置消息过滤
     *
     * @param jgroupsNode
     * @param msg
     * @param e
     * @return
     */
    @Override
    public boolean afterHandler(JGroupsNode jgroupsNode, JGroupMessage msg, Throwable e) {
        return true;
    }
}
