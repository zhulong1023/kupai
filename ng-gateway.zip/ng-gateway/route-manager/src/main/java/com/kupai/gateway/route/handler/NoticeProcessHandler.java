package com.kupai.gateway.route.handler;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.route.handler.processor.DefaultRequestProcessor;

/**
 * 通知类消息处理器
 * Created by zhaoshengqi on 2017/4/5.
 */
@Component
public class NoticeProcessHandler extends AbstractProcessHandler {

    /**
     * 注册该处理器
     */
    @PostConstruct
    protected void registerHandler() {
        DefaultRequestProcessor.registerProcessHandler(RequestCode.MSG_NOTICE, this);
    }

    /**
     * 处理接收到的消息
     *
     * @param jGroupMessage
     * @return
     */
    @Override
    protected JGroupMessage doProcess0(JGroupMessage jGroupMessage) {
        jGroupMessage.setSourceAdd(null);
        jGroupMessage.setSendType(JGroupMessage.SendType.MULTI.getValue());
        return jGroupMessage;
    }

}
