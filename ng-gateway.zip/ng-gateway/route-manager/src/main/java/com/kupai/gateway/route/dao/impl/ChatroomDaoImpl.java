package com.kupai.gateway.route.dao.impl;

import com.kupai.gateway.route.dao.ChatroomDao;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.model.Chatroom;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by zhulong on 2017/3/21.
 */
@Component
public class ChatroomDaoImpl implements ChatroomDao{

    @Autowired
    private JdbcTemplate jdbcTemplate;

    //插入房間信息
    private static final String ADD_CHATROOM_INFO = "INSERT INTO chatroom " +
            "(source,counter,create_id,create_time)" +
            " values (?,?,?,?)";
    private static final String NEXT_ID = "select max(id)+1 as id from kupai_gateway.chatroom";
    private static final String FIND_CHATROOM_BYID = "select * from kupai_gateway.chatroom where id = ? and source = ?";

    @Override
    public long saveChatroom(Chatroom room) {
        try {
            long nextid = this.getNextId();
            if(jdbcTemplate.update(ADD_CHATROOM_INFO, room.getSource(),
                    room.getCounter(),room.getCreateId(),room.getCreateTime()) > 0){
                return nextid;
            };
        }catch (DuplicateKeyException e){
            ApiLogger.error("插入房间信息异常，id=" + room.getId() + ",异常信息：" + e);

        }
        return 0l;
    }

    @Override
    public Chatroom findChatroomById(Long id,Integer source) {

        return jdbcTemplate.query(FIND_CHATROOM_BYID,new Object[]{id.longValue(),source.intValue()},new ResultSetExtractor<Chatroom>() {
            @Override
            public Chatroom extractData(ResultSet rs) throws SQLException, DataAccessException {
                if (rs.next()) {
                    Chatroom room = new Chatroom();
                    room.setId(rs.getLong("id"));
                    room.setSource(rs.getString("source"));
                    room.setCounter(rs.getLong("counter"));
                    room.setCreateId(rs.getLong("create_id"));
                    return room;
                }
                return null;
            }
        });
        //return jdbcTemplate.queryForObject(FIND_CHATROOM_BYID,new Object[]{id.longValue(),source.intValue()},new BeanPropertyRowMapper<Chatroom>(Chatroom.class));
    }

    public long getNextId() {
        long nid = this.queryForLong(NEXT_ID);
        if (nid == 0l) {
            return 1;
        }
        return nid;
    }

    public long queryForLong(String sql) throws DataAccessException {
        Number number = (Number) jdbcTemplate.queryForObject(sql, Long.class);
        return (number != null ? number.longValue() : 0);
    }
}
