package com.kupai.gateway.route.exception;

/**
 * Created by Administrator on 2017/3/21.
 */
public class ApiException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private ErrorResult resultCode;

    public ApiException(ErrorResult resultCode) {
        super();
        this.resultCode = resultCode;
    }

    public ErrorResult getResultCode() {
        return resultCode;
    }

    public void setResultCode(ErrorResult resultCode) {
        this.resultCode = resultCode;
    }
}
