package com.kupai.gateway.route.filter;

import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.JGroupsNode;

/**
 * Created by Administrator on 2017/3/27.
 */
public interface MessageFilter {
    /**
     * 前置消息过滤
     * @param jgroupsNode
     * @param msg
     * @return
     */
    boolean preHandler(JGroupsNode jgroupsNode, JGroupMessage msg);
    
    /**
     * 后置消息过滤
     * @param jgroupsNode
     * @param msg
     * @param e
     * @return
     */
    boolean afterHandler(JGroupsNode jgroupsNode, JGroupMessage msg, Throwable e);
}
