package com.kupai.gateway.route.service;

import com.kupai.gateway.route.data.Result;
import org.springframework.web.multipart.MultipartFile;

/**
 * Created by Administrator on 2017/3/21.
 */
public interface MultimediaUploadService {
    /**
     * 上传多媒体文件，包含图片 语音  视频
     *
     * @param item
     * @return
     */
    Result<Object> upload(MultipartFile item);
}
