package com.kupai.gateway.route.youyun;

import com.ioyouyun.wchat.protobuf.InvalidProtocolBufferException;
import com.ioyouyun.wchat.protocol.MetaMessageType;
import com.ioyouyun.wchat.protocol.WChatMessage;
import com.ioyouyun.wchat.protocol.Weimi.WeimiPacket;

public class TextMessage {
    public MetaMessageType type;
    public String msgId;
    public String fromuid;
    public String touid;
    public long time;
    public byte[] padding;
    public String text;
    public String paddingText;

    public boolean parse(WeimiPacket meyouPacket) {
        if (meyouPacket.hasContent()) {
            WChatMessage.Meta meta;
            try {
                meta = WChatMessage.Meta.parseFrom(meyouPacket.getContent().toByteArray());
            } catch (InvalidProtocolBufferException e1) {
                return false;
            }
            type = MetaMessageType.valueOf((meta.getType().toByteArray())[0]);
            //普通的文本  @ 和进出房间消息 才进行解析
            if (type == MetaMessageType.text || type == MetaMessageType.textext || type == MetaMessageType.mixed) {
                //评论,叫价的类型为text,若消息有@某人的时候则为textext
                msgId = meta.getId();
                touid = meta.getTo();
                fromuid = meta.getFrom();
                time = meta.getTime();
                text = meta.getContent().toStringUtf8();
                WChatMessage.ExtContent contentEx;
                try {
                    contentEx = WChatMessage.ExtContent.parseFrom(meta.getContentExt());
                    padding = contentEx.getContent().toByteArray();
                } catch (InvalidProtocolBufferException e) {
                    return false;
                }
                return true;
            }
        }
        return false;
    }
}
