package com.kupai.gateway.route.handler.processor;

import com.kupai.gateway.common.jgroups.JGroupMessage;

/**
 * Created by Administrator on 2017/3/27.
 */
public interface RequestProcessor {

    /**
     * 处理从rm过来的请求
     *
     * @param jGroupMessage
     */
    void processRequest(JGroupMessage jGroupMessage);
}
