/**
 * 
 */
package com.kupai.gateway.route.handler;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.route.handler.processor.DefaultRequestProcessor;

/**
 * @author zhouqisheng
 * 2017年3月28日
 */
@Component
public class AuthProcessHandler extends AbstractProcessHandler{
    
    /**
     * 注册该处理器
     */
    @PostConstruct
    protected void registerHandler() {
        DefaultRequestProcessor.registerProcessHandler(RequestCode.AUTH, this);
    }


    @Override
    protected JGroupMessage doProcess0(JGroupMessage jGroupMessage) {
        jGroupMessage.setSendType(JGroupMessage.SendType.MULTI.getValue());
        jGroupMessage.setSourceAdd(null);
        return jGroupMessage;
    }

}
