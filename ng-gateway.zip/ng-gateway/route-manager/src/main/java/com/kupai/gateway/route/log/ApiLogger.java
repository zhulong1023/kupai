package com.kupai.gateway.route.log;

import com.alibaba.fastjson.JSON;
import com.kupai.gateway.route.context.RouteManagerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * 日志工具类
 *
 * @author zqd
 */
public class ApiLogger {

    private static final Logger DEBUG = LoggerFactory.getLogger("debug");
    private static final Logger INFO = LoggerFactory.getLogger("info");
    private static final Logger WARN = LoggerFactory.getLogger("warn");
    private static final Logger ERROR = LoggerFactory.getLogger("error");
    private static final Logger REQUEST = LoggerFactory.getLogger("request");
    private static final Logger HTTP_ACCESS = LoggerFactory.getLogger("http_access");
    private static final Logger DB_INFO = LoggerFactory.getLogger("db_info");
    private static final Logger REDIS = LoggerFactory.getLogger("redis");

    private static final Logger MESSAGE = LoggerFactory.getLogger("message");

    //第三方调用日志
    private static final Logger THIRD_PARTY_ERROR = LoggerFactory.getLogger("thirdparty_error");

    private static final String requestFormat = "%s %s %s %s %s %s %s %s";
    private static final String common = "%s %s";

    public static void debug(String message) {
        DEBUG.info(String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message));
    }

    public static void info(String message) {
        INFO.info((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)));
    }

    public static void warn(String message) {
        WARN.warn((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)));
    }

    public static void error(String message) {
        ERROR.error((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)));
    }

    public static void error(String message, Throwable throwable) {
        ERROR.error((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)), throwable);
    }

    public static void http_access(String message) {
        HTTP_ACCESS.info((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)));
    }

    public static void http_warn(String message) {
        HTTP_ACCESS.warn((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)));
    }

    public static void dbInfo(String message) {
        DB_INFO.info((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)));
    }

    public static void thirdPartyError(String message, Throwable throwable) {
        THIRD_PARTY_ERROR.error((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)), throwable);
    }

    /**
     * 记录消息
     * @param message
     */
    public static void message(String message) {
        INFO.info((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)));
    }

    /**
     * redis日志
     * @param message 信息
     * @param level 1 info 2 warn 3 error
     */
    public static void redis(String message, int level) {
        if (level == 1) {
            REDIS.info((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)));
        }
        if (level == 2) {
            REDIS.warn((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)));
        }
        if (level == 3) {
            REDIS.error((String.format(common, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), message)));
        }
    }


    public static void request(HttpServletRequest request, HttpServletResponse response) {
        if (request == null) {
            return;
        }
        if (!RouteManagerContext.getRouteManagerContext().isHasPrintRequestLog()) {
            Map<String, String> map = new HashMap<String, String>();
            Enumeration<String> paramNames = request.getParameterNames();
            while (paramNames.hasMoreElements()) {
                String paramName = (String) paramNames.nextElement();

                String[] paramValues = request.getParameterValues(paramName);
                if (paramValues.length == 1) {
                    String paramValue = paramValues[0];
                    if (paramValue.length() != 0) {
                        map.put(paramName, paramValue);
                    }
                }
            }

            String token = request.getHeader("_UID_") == null ? "-" : request.getHeader("_UID_");
            String reqParam = JSON.toJSONString(map);

            int status = response.getStatus();
            long now = System.currentTimeMillis();

            String responseStr = "";
            if (RouteManagerContext.getRouteManagerContext().isPrintResponse()) {
                responseStr = RouteManagerContext.getRouteManagerContext().getResponse();
            }
            REQUEST.info(String.format(requestFormat, RouteManagerContext.getRouteManagerContext().getUniqueRequestId(), status,
                    RouteManagerContext.getRouteManagerContext().getUid(), "token:" + token, "url:" + request.getRequestURI(),
                    "request:" + reqParam, "usetime:" + (now - RouteManagerContext.getRouteManagerContext().getStartTime()), "response:" + responseStr));
            RouteManagerContext.getRouteManagerContext().setHasPrintRequestLog(true);
        }
    }
}
