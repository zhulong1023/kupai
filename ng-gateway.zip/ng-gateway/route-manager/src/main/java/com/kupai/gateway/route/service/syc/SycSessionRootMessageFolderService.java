package com.kupai.gateway.route.service.syc;

import com.kupai.gateway.route.model.HistoryMessage;
import com.kupai.gateway.route.service.HistoryMessageService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/3/30.
 */
@Service
public class SycSessionRootMessageFolderService {

    @Autowired
    private HistoryMessageService historyMessageService;

    /**
     * 获得消息列表
     *
     * @param source    来源系统
     * @param sessionId 房间id
     * @param pullType  拉取方向 0 拉取最新数据  1 拉取历史数据
     * @param messageId 消息id  即score
     * @param pageSize  每页显示多少条数据
     * @return
     */
    public Map<String, Object> getMessageListByMessageId(String source, String sessionId, int pullType, String messageId, int pageSize, String uid) {
        Map<String, Object> map = null;
        List<HistoryMessage> historyMessageList = historyMessageService.sycMessage(pullType, Long.valueOf(messageId), pageSize, sessionId);
        if (CollectionUtils.isNotEmpty(historyMessageList)) {
            map = new HashMap<>(2);
            map.put("messageId", this.getHistoryMaxMessageId(sessionId));
            map.put("messageList", historyMessageList);
        }
        return map;
    }

    /**
     * 获得当前回话中最大的messageId
     *
     * @param sessionId 会话id
     * @return
     */
    public String getHistoryMaxMessageId(String sessionId) {
        return historyMessageService.getHistoryMaxMessageId(sessionId);
    }
}
