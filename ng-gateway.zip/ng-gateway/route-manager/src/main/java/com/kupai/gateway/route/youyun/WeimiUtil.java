package com.kupai.gateway.route.youyun;

import com.ioyouyun.wchat.protobuf.ByteString;
import com.ioyouyun.wchat.protocol.Command;
import com.ioyouyun.wchat.protocol.Weimi;

/**
 * 提供将wchat协议信息包装成pb网关包
 */
public class WeimiUtil {
	public static final int AuthOK = 200;
	public static final int AuthTimeout = 400;
	public static final int AuthFailed = 401;
	public static final int AuthForceOut = 402;
	public static final int AuthException = 403;

	public static byte[] generateRequestEntity(String callbackId, int sort,
			ByteString content, Command command) {
		return generateRequestEntityBase(callbackId, sort, content, null, null,
				command);
	}

	public static byte[] generateRequestEntityExt(String callbackId, int sort,
			ByteString content, byte[] picData) {
		return generateRequestEntityBase(callbackId, sort, content, picData,
				null, null);
	}

	/**
	 * 生产WeimiPacket基础类
	 * 
	 * @param callbackId
	 * @param sort
	 * @param content
	 * @param picData
	 * @param httpReq
	 * @param command
	 * @return
	 */
	private static byte[] generateRequestEntityBase(String callbackId,
                                                    int sort, ByteString content, byte[] picData,
                                                    Weimi.HttpReq.Builder httpReq, Command command) {
		Weimi.WeimiPacket.Builder meyouPacket = null;
		meyouPacket = Weimi.WeimiPacket.newBuilder().setCallbackId(callbackId)
				.setSort(sort);
		if (content != null) {
			meyouPacket.setContent(content);
		}
		if (picData != null) {
			meyouPacket.setAttache(ByteString.copyFrom(picData));
		}
		if (httpReq != null) {
			meyouPacket.setHttpReq(httpReq);
		}
		if (command != null) {
			meyouPacket.setUri(ByteString.copyFrom(new byte[] { command
					.toByte() }));
		}
		return meyouPacket.build().toByteArray();
	}

}
