package com.kupai.gateway.route.service.httpClient;

/**
 * 开放平台接口
 * Created by Administrator on 2017/3/30.
 */
public interface OpenPlatformClient {
}
