package com.kupai.gateway.route.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.data.Command;
import com.kupai.gateway.common.data.DataMeta;
import com.kupai.gateway.common.data.Text;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.JGroupsMessageHandler;
import com.kupai.gateway.common.util.IdWorker;
import com.kupai.gateway.route.log.ApiLogger;

/**
 * Created by zhaoshengqi on 2017/3/30.
 */
@Service
public class GwPushMessageService {

    @Autowired
    private IdWorker idWorker;

    @Autowired
    private JGroupsMessageHandler jGroupsMessageHandler;


    /**
     * 为外部服务提供推送消息接口
     *
     * @param source   来源系统 0库拍1开放平台
     * @param event    事件
     * @param from     fromId
     * @param roomId   房间ID
     * @param toIds    接收ID(支持多个)
     * @param data     内容
     * @param ext      扩展信息 【json格式】
     * @param code     requestCode
     * @param chatType 聊天类型 1个人 2房间
     * @return
     */
    public Map<String, Object> handleMessage(final int source, final String event,
                                             final long from, final long roomId, final String toIds, final String data, final JSONObject ext, final int code, final int chatType) {

        Map<String, Object> map = new HashMap<String, Object>();
        try {

            JGroupMessage jGroupMessage = new JGroupMessage();
            DataMeta dataMeta = new DataMeta();
            long requestId=idWorker.nextId();
            dataMeta.setFrom(from);
            if (roomId!=0){
                dataMeta.setTo(roomId);
            }
            dataMeta.setEvent(event);
            dataMeta.setExt(ext);
            dataMeta.setCode(code);
            dataMeta.setChatType(chatType);

            jGroupMessage.setCode(code);
            jGroupMessage.setFrom(from);
            jGroupMessage.setRequestId(requestId);
            jGroupMessage.setSource(source);
            jGroupMessage.setSendType(JGroupMessage.SendType.P2P.getValue());
            if (roomId!=0){
                jGroupMessage.setRoomId(roomId);
            }else{
                String[] stoIds = toIds.split(",");
                List<Long> toUid = new ArrayList<>(stoIds.length);
                for (String id : stoIds) {
                    toUid.add(Long.parseLong(id));
                }
                jGroupMessage.setToUid(toUid);
            }
            if (code== RequestCode.MSG_TEXT){
                Text text = new Text();
                text.setContent(data);
                text.setMeta(dataMeta);
                jGroupMessage.setData(JSON.toJSON(text));
            }else if (code == RequestCode.MSG_NOTICE){
                Command command = new Command();
                command.setContent(data);
                command.setMeta(dataMeta);
                jGroupMessage.setData(command);
            }

            jGroupsMessageHandler.messageHandler(jGroupMessage);
            map.put("messageHandler","SUCCESS");
        }catch (Exception e){
            ApiLogger.error("handleMessage ERROR",e);
        }
        return map;
    }


}
