package com.kupai.gateway.route.controller;

import com.kupai.gateway.route.annocations.ApiStatus;
import com.kupai.gateway.route.annocations.AuthType;
import com.kupai.gateway.route.annocations.BaseInfo;
import com.kupai.gateway.route.annocations.SignType;
import com.kupai.gateway.route.data.Result;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Administrator on 2017/3/21.
 */
@RestController
@RequestMapping(value = "/rote_manager/help")
public class HelpController {

    /**
     * help
     *
     * @return
     */
    @RequestMapping(value = "/help", method = RequestMethod.GET, produces = "application/json")
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> help() {
        return new Result<>(true);
    }
}
