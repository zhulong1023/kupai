package com.kupai.gateway.route.cache.black;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kupai.gateway.common.util.TimeUtil;
import com.kupai.gateway.route.constant.BlackRedisKeyPre;

import redis.clients.jedis.JedisCluster;

/**
 * Created by Administrator on 2017/3/29.
 */
@Component
public class BlackWhiteUserOptionStorage {

    @Autowired
    private JedisCluster jedisCluster;

    /**
     * 维护黑白名单用户
     *
     * @param source 系统
     * @param org    机构
     * @param uids   用户uid列表
     * @param type   类型 1 黑名单  2 白名单
     * @return
     */
    public long saveBlackWhiteUser(String source, String org, String uids, Integer type, Long gagTime) {
        long count = 0;
        String key = this.getUserKey(source, org, type);
        if (StringUtils.isNotEmpty(uids)) {
            String[] uidArr = uids.split(",");
            Long inviteTime = TimeUtil.getCurrentSeconds() + gagTime;
            for (int i = 0; i < uidArr.length; i++) {
                jedisCluster.hdel(key, uidArr[i]);
                count += jedisCluster.hset(key, uidArr[i], String.valueOf(inviteTime));
            }
        }
        return count;
    }

    /**
     * 维护黑白名单用户
     *
     * @param source 系统
     * @param org    机构
     * @param uids   用户uid列表
     * @param type   类型 1 黑名单  2 白名单
     * @return
     */
    public long removeBlackWhiteUser(String source, String org, String uids, Integer type) {
        long count = 0;
        String key = this.getUserKey(source, org, type);
        if (StringUtils.isNotEmpty(uids)) {
            String[] uidArr = uids.split(",");
            for (int i = 0; i < uidArr.length; i++) {
                count += jedisCluster.hdel(key, uidArr[i]);
            }
        }
        return count;
    }

    /**
     * 维护机构对应的黑白名单房间list
     *
     * @param source 系统
     * @param org    机构
     * @param rooms  房间列表
     * @param type   类型 1 黑名单  2 白名单
     * @return
     */
    public boolean saveBlackWhiteRoom(String source, String org, String rooms, Integer type) {
        if (StringUtils.isNotEmpty(rooms)) {
            String[] roomArr = rooms.split(",");
            for (int i = 0; i < roomArr.length; i++) {
                String key = this.getRoomKey(source, type, roomArr[i]);
                String value = this.getUserKey(source, org, type);
                jedisCluster.set(key, value);
            }
        }
        return true;
    }

    /**
     * 维护机构对应的黑白名单房间list
     *
     * @param source 系统
     * @param org    机构
     * @param rooms  用户uid列表
     * @param type   类型 1 黑名单  2 白名单
     * @return
     */
    public boolean removeBlackWhiteRoom(String source, String org, String rooms, Integer type) {
        if (StringUtils.isNotEmpty(rooms)) {
            String[] roomArr = rooms.split(",");
            for (int i = 0; i < roomArr.length; i++) {
                String key = this.getRoomKey(source, type, roomArr[i]);
                jedisCluster.del(key);
            }
        }
        return true;
    }

    /**
     * 获得黑或者白名单用户列表
     * @param source
     * @param roomId
     * @param type 1 黑名单  2 白名单
     * @return
     */
    public Map<String, String> getUserList(String source, String roomId, Integer type) {
        String key = getRoomKey(source, type, roomId);
        String value = jedisCluster.get(key);
        if (StringUtils.isNotEmpty(value)) {
            return jedisCluster.hgetAll(value);
        }
        return null;
    }

    /**
     * 返回key
     *
     * @param source
     * @param org
     * @param type
     * @return
     */
    private String getUserKey(String source, String org, Integer type) {
        return BlackRedisKeyPre.BLACK_WHITE_ORG_USER_LIST_PRE + source + "_" + org + "_" + type;
    }

    /**
     * 返回key
     *
     * @param source
     * @param type
     * @return
     */
    private String getRoomKey(String source, Integer type, String room) {
        return BlackRedisKeyPre.BLACK_WHITE_ORG_ROOM_LIST_PRE + source + "_" + type + "_" + room;
    }
}
