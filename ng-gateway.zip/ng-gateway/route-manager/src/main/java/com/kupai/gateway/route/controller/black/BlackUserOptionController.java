package com.kupai.gateway.route.controller.black;

import com.kupai.gateway.route.annocations.ApiStatus;
import com.kupai.gateway.route.annocations.AuthType;
import com.kupai.gateway.route.annocations.BaseInfo;
import com.kupai.gateway.route.annocations.SignType;
import com.kupai.gateway.route.data.Result;
import com.kupai.gateway.route.service.BlackUserOptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 全局禁言操作类
 * Created by Administrator on 2017/3/23.
 */
@RestController
@RequestMapping(value = "/route/api/black")
public class BlackUserOptionController {

    @Autowired
    private BlackUserOptionService blackUserOptionService;

    /**
     * 设置全局黑名单[给前端提供]
     *
     * @param source  系统名称，必须英文名称
     * @param uids    用户uid,多个用，隔开
     * @param gagTime 禁言时长  单位s 默认900s 即15分钟  如果为-1，则为永久禁言
     * @return
     */
    @RequestMapping(value = "/add/addBlackUser.json", method = RequestMethod.POST, produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.PUBLIC, needAuth = AuthType.REQUIRED, needSign = SignType.NOTNEED)
    public Result<Object> addBlackUser(
            @RequestParam(name = "source", required = true) String source,
            @RequestParam(name = "optionUser", required = true) String optionUser,
            @RequestParam(name = "uids", required = true) String uids,
            @RequestParam(name = "gagTime", required = false, defaultValue = "900") long gagTime) {
        boolean flag = blackUserOptionService.setBlackUser(source, uids, 1, gagTime, optionUser);
        return new Result<>(flag);
    }

    /**
     * 设置全局黑名单
     *
     * @param source  系统名称，必须英文名称
     * @param uids    用户uid,多个用，隔开
     * @param status  是否进入黑名单    0 否   1 是
     * @param gagTime 禁言时长  单位s 默认900s 即15分钟
     * @return
     */
    @RequestMapping(value = "/set/setBlackUser.json", method = RequestMethod.POST, produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> setBlackUser(
            @RequestParam(name = "source", required = true) String source,
            @RequestParam(name = "optionUser", required = true) String optionUser,
            @RequestParam(name = "uids", required = true) String uids,
            @RequestParam(name = "status", required = true) Integer status,
            @RequestParam(name = "gagTime", required = false, defaultValue = "900") long gagTime) {
        boolean flag = blackUserOptionService.setBlackUser(source, uids, status, gagTime, optionUser);
        return new Result<>(flag);
    }

    /**
     * 判断是否在黑名单中
     *
     * @param source 系统名称，必须英文名称
     * @return
     */
    @RequestMapping(value = "/get/getBlackUserList.json", method = RequestMethod.GET, produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> getBlackUserList(
            @RequestParam(name = "source", required = true) String source,
            @RequestParam(name = "page", required = false, defaultValue = "1") int page,
            @RequestParam(name = "pageSize", required = false, defaultValue = "20") int pageSize) {
        Map<String, Object> map = blackUserOptionService.getBlackUserList(source, page, pageSize);
        return new Result<>(map);
    }


    /**
     * 判断是否在黑名单中
     *
     * @param source 系统名称，必须英文名称
     * @param uid    用户uid
     * @return
     */
    @RequestMapping(value = "/validate/isBlackUser.json", method = RequestMethod.GET, produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> isBlackUser(
            @RequestParam(name = "source", required = true) String source,
            @RequestParam(name = "uid", required = true) String uid) {
        boolean flag = blackUserOptionService.isBlackUser(source, uid);
        return new Result<>(flag);
    }
}
