package com.kupai.gateway.route.dao.impl;

import com.kupai.gateway.common.util.StringUtils;
import com.kupai.gateway.route.dao.ForbidWordDao;
import com.kupai.gateway.route.model.ForbidWord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by zhulong on 2017/3/24.
 */
@Component("forbidWordDao")
public class ForbidWordDaoImpl implements ForbidWordDao {

    private static Logger LOGGER = LoggerFactory.getLogger(ForbidWordDaoImpl.class);
    private static final String UPDATE_WORD = "UPDATE kupai_gateway.forbid_word set `name` = ?,`type` = ?,`status` = ?,`level` = ?,`start_time` = ?,`end_time` = ? WHERE `id` = ?";
    private static final String ADD_WORDS = "INSERT INTO kupai_gateway.forbid_word (`id`, `name`, `type`,`source`, `status` ,`level`,`start_time`,`end_time`) VALUES $params ";
    private static final String DELETE_WORDS_BY_TYPE = "DELETE FROM kupai_gateway.forbid_word WHERE `type` = ? ";
    private static final String QUERY_ALL = "select * from kupai_gateway.forbid_word where timestampdiff(second,now(),end_time)>=0 or start_time is null and source=?";
    private static final String NEXT_ID = "select max(id)+1 as id from kupai_gateway.forbid_word";

    @Autowired
    private JdbcTemplate jdbcTemplate;


    private ForbidWord extractForbidWord(ResultSet rs) {
        ForbidWord word = new ForbidWord();
        try {

            word.setId(rs.getLong("id"));
            word.setName(rs.getString("name"));
            word.setType(rs.getString("type"));
            word.setLevel(rs.getInt("level"));
            word.setStatus(ForbidWord.WordStatus.parseValue(rs.getInt("status")));
            word.setStartTime(rs.getTimestamp("start_time"));
            word.setEndTime(rs.getTimestamp("end_time"));
            word.setSource(rs.getInt("source"));
            word.setCreateTime(rs.getTimestamp("create_time"));

            return word;
        } catch (SQLException e) {
            LOGGER.error("Error: when extract ForbidWord from db", e);
        }
        return null;
    }

    @Override
    public boolean add(ForbidWord forbidWord) {
        List<ForbidWord> wordList = new ArrayList<ForbidWord>();
        wordList.add(forbidWord);
        return batchAdd(wordList);
    }



    @Override
    public boolean batchAdd(final List<ForbidWord> forbidWordList) {
        StringBuilder sb = new StringBuilder();
        for(int i=0,l = forbidWordList.size();i<l;i++){
            if(i>0){
                sb.append(",");
            }
            sb.append("(");
            sb.append("?,");
            sb.append("?,");
            sb.append("?,");
            sb.append("?,");
            sb.append("?,");
            sb.append("?,");
            sb.append("?,");
            sb.append("?");
            sb.append(")");
        }
        String sql = ADD_WORDS.replace("$params",sb.toString());
        try {
            jdbcTemplate.update(sql, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    int i = 0;
                    long id = getNextId();
                    for (ForbidWord dto : forbidWordList) {
                        ps.setLong(i * 8 + 1, i + id);
                        ps.setString(i * 8 + 2, dto.getName());
                        ps.setString(i * 8 + 3, dto.getType());
                        ps.setInt(i * 8 + 4, dto.getSource());
                        ps.setInt(i * 8 + 5, dto.getStatus().getValue());
                        ps.setInt(i * 8 + 6, dto.getLevel());
                        ps.setTimestamp(i * 8 + 7, dto.getStartTime());
                        ps.setTimestamp(i * 8 + 8, dto.getEndTime());
                        ++i;
                    }
                }
            });
            return true;
        } catch (DuplicateKeyException e) {
            throw e;
        }catch (DataAccessException e) {
            LOGGER.error("ForbidWordDaoImpl.batchAdd exception when performing deleting in DB", e);
            return false;
        }

    }


    @Override
    public boolean updateInfor(ForbidWord word) {
        try {
            jdbcTemplate.update(UPDATE_WORD, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, word.getName());
                    ps.setString(2, word.getType());
                    ps.setInt(3, word.getStatus().getValue());
                    ps.setInt(4, word.getLevel());
                    ps.setTimestamp(5, word.getStartTime());
                    ps.setTimestamp(6, word.getEndTime());
                    ps.setLong(7, word.getId());
                }
            });
            return true;
        } catch (DataAccessException e) {
            LOGGER.error("ForbidWordDaoImpl.updateInfor exception when performing deleting in DB", e);
            throw e;
        }
    }

    @Override
    public boolean delByType(String type) {
        boolean result;
        try {
            jdbcTemplate.update(DELETE_WORDS_BY_TYPE, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, type);
                }
            });
            result = true;
        } catch (DataAccessException e) {
            result = false;
            LOGGER.error("ForbidWordDaoImpl.delByType exception when performing deleting in DB", e);
        }
        return result;
    }


    @Override
    public List<Map<String, Object>> queryForbidWords(String name, int page, int num) {
        int start = 0;
        if (page == 1) {
            start = 0;
        }
        if (page > 1) {
            start = (page - 1) * num;
        }
        //敏感词暂时只支持一级、二级，所有where `level` in (1,2)
        if (StringUtils.isBlank(name)) {
            String sql = " " +
                    "select id,`name`,`level`,type,create_time,`status`,source from kupai_gateway.forbid_word " +
                     /*+ "where `level` in (1,2) " +*/
                    "order by create_time " +
                    "limit ?,?";
            List<Object> params = new ArrayList<>();
            params.add(start);
            params.add(num);
            return jdbcTemplate.queryForList(sql, params.toArray());
        }
        String sql = " " +
                "select id,`name`,`level`,type,create_time,`status`,source from kupai_gateway.forbid_word " +
                "where  " +
                /*"where `level` in (1,2) and " +*/
                " `name` like ? " +
                "order by create_time " +
                "limit ?,?";
        List<Object> params = new ArrayList<>();
        params.add("%" + name + "%");
        params.add(start);
        params.add(num);
        return jdbcTemplate.queryForList(sql, params.toArray());
    }

    @Override
    public long queryCountForbid(String name) {
        if (StringUtils.isBlank(name)) {
            String sql = "" +
                    "select count(1) from kupai_gateway.forbid_word "
                    /*+ "where `level` in (1,2) "*/;
            return this.queryForLong(sql);
        }
        String sql = "" +
                "select count(1) from kupai_gateway.forbid_word " +
                "where  " +
                /*"where `level` in (1,2) and " +*/
                " `name` like ? ";
        List<Object> params = new ArrayList<>();
        params.add("%" + name + "%");
        return this.queryForLong(sql, params.toArray());
    }


    public long getNextId() {
        long nid = this.queryForLong(NEXT_ID);
        if (nid == 0l) {
            return 1;
        }
        return nid;
    }

    public long queryForLong(String sql) throws DataAccessException {
        Number number = (Number) jdbcTemplate.queryForObject(sql, Long.class);
        return (number != null ? number.longValue() : 0);
    }

    public long queryForLong(String sql, Object[] args) throws DataAccessException {
        Number number = (Number) jdbcTemplate.queryForObject(sql, args, Long.class);
        return (number != null ? number.longValue() : 0);
    }

    public int queryForInt(String sql) throws DataAccessException {
        Number number = (Number) jdbcTemplate.queryForObject(sql, Integer.class);
        return (number != null ? number.intValue() : 0);
    }


    @Override
    public List<ForbidWord> queryAll(int source) {
        return (List<ForbidWord>) jdbcTemplate.query(QUERY_ALL, new ResultSetExtractor<List<ForbidWord>>() {
            @Override
            public List<ForbidWord> extractData(ResultSet rs) throws SQLException, DataAccessException {
                List<ForbidWord> list = new ArrayList<>();
                while (rs.next()) {
                    list.add(extractForbidWord(rs));
                }
                return list;
            }
        }, source);
    }


}
