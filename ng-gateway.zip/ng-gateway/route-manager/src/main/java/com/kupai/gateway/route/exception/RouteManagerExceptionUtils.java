package com.kupai.gateway.route.exception;

/**
 * Created by zhangrui on 16/3/7.
 */
public class RouteManagerExceptionUtils {

    public static RuntimeException throwRouteManagerException(ErrorResult error){
        return new ApiException(error);
    }
}
