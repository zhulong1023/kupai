package com.kupai.gateway.route.youyun;

/**
 * 游云消息中ext中type类型
 * Created by Administrator on 2017/3/7.
 */
public enum MessageExtType {
    normal_text((short) 1, "普通消息"),
    programme_text((short) 2, "主持人消息"),
    at_text((short) 3, "@消息"),
    sendprice_text((short) 4, "出价消息"),
    unknown((short) 0, "非定义类型");

    private final short code;
    private final String desc;

    public short getCode() {
        return code;
    }

    MessageExtType(short code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static MessageExtType valueOf(final short code) {
        for (MessageExtType t : MessageExtType.values()) {
            if (code == t.code)
                return t;
        }
        return unknown;
    }
}
