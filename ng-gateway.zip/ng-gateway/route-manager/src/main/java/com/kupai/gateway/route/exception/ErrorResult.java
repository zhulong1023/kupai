package com.kupai.gateway.route.exception;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

/**
 * DATE: 2015/3/30
 * TIME: 16:46
 *
 * @author jiahao@weimi.me
 */
public class ErrorResult {
    private int error_code;
    private String error_zh_CN;


    public ErrorResult(int error_code, String error_zh_CN) {
        this.error_code = error_code;
        this.error_zh_CN = error_zh_CN;
    }

    public int getErrorCode() {
        return error_code;
    }

    public void setErrorCode(int errorCode) {
        this.error_code = errorCode;
    }

    public String getError() {
        return error_zh_CN;
    }

    public void setError(String error) {
        this.error_zh_CN = error;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("{");
        sb.append("\"status\" :").append(false).append(",");
        sb.append(" \"code\" :").append(getErrorCode()+"").append(",");
        sb.append(" \"msg\" :").append("\"").append(getError()).append("\"");
        sb.append("}");
        return sb.toString();
    }

    public JSONObject toJson() {
        JSONObject result = new JSONObject();
        result = JSON.parseObject(toString());
        return result;
    }

    public static void main(String[] args) {
        ErrorResult result = new ErrorResult(1, "test");
        result.toJson();
    }
}
