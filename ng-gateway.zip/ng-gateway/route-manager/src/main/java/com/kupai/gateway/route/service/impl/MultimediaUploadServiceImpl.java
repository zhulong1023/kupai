package com.kupai.gateway.route.service.impl;

import com.kupai.gateway.route.data.Result;
import com.kupai.gateway.route.exception.ApiException;
import com.kupai.gateway.route.exception.ErrorResultCode;
import com.kupai.gateway.route.exception.RouteManagerExceptionUtils;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.service.MultimediaUploadService;
import com.kupai.gateway.route.service.third.ShUploadService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/3/21.
 */
@Service
public class MultimediaUploadServiceImpl implements MultimediaUploadService {

    @Autowired
    private ShUploadService shUploadService;

    //允许上传的文件的最大值
    @Value("${allow.upload.file.maxsize}")
    private String maxSize;

    /**
     * 上传多媒体文件，包含图片 语音  视频
     *
     * @param item
     * @return
     */
    @Override
    public Result<Object> upload(MultipartFile item) {
        try {
            if (checkImage(item)) {
                String fileId = shUploadService.uploadFile(item);
                if (StringUtils.isNotEmpty(fileId)) {
                    Result<Object> result = new Result<>(true);
                    Map<String, String> map = new HashMap<>(1);
                    map.put("fileId", fileId);
                    result.setData(map);
                    return result;
                } else {
                    throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.UPLOAD_ERROR);
                }
            } else {
                throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.FILE_TOO_BIG_ERROR);
            }
        } catch (Exception e) {
            ApiLogger.error("upload file error,name:" + item.getOriginalFilename() + ",contentType:" + item.getContentType() + ",error:" + e, e);
            if (e instanceof ApiException) {
                throw (ApiException) e;
            } else {
                throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.UPLOAD_ERROR);
            }
        }
    }

    /**
     * 检查文件
     *
     * @param item
     * @return
     */
    private boolean checkImage(MultipartFile item) throws IOException {
        boolean flag = false;
        int defaultMaxSize = 20 * 1024 * 1024;
        if (item == null) {
            return flag;
        }
        byte[] imgs = item.getBytes();
        if (imgs == null || imgs.length < 10) {
            return flag;
        }
        if (StringUtils.isNotEmpty(maxSize)) {
            defaultMaxSize = Integer.parseInt(maxSize);
        }
        if (imgs.length >= defaultMaxSize) {
            return flag;
        }
        return true;
    }
}
