package com.kupai.gateway.route.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.serializer.SerializerFeature;

/**
 * Created by zhaoshengqi on 2017/3/21.
 */

public class HistoryMessage {
    /**id*/
    @JSONField(serialzeFeatures = SerializerFeature.WriteNonStringValueAsString)
    private long id;
    /**消息类型*/
    private int type;
    /**消息内容*/
    private String content;
    /**房间ID/toid+userid*/
    private String sessionId;
    /**消息状态*/
    private int status;
    /**用户id*/
    private long userId;
    /**创建时间*/
    private long createTime;

    /**消息来源*/
    private int source;

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setType(int type) {
        this.type = type;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int getType() {
        return type;
    }

    public String getContent() {
        return content;
    }

    public long getUserId() {
        return userId;
    }

    //重写equals方法
    @Override
    public boolean equals(Object obj){
        if (obj instanceof HistoryMessage) {
            if (this.getId()==((HistoryMessage) obj).getId() ||
                    (this.getCreateTime() == ((HistoryMessage) obj).getCreateTime()
                            && this.getUserId() == ((HistoryMessage) obj).getUserId()
                            && this.getSessionId() == ((HistoryMessage) obj).getSessionId()
                            && this.getContent().equals(((HistoryMessage) obj).getContent())
                    )){
                return true;
            }else {
                return false;
            }
        }
        return false;
    }

}
