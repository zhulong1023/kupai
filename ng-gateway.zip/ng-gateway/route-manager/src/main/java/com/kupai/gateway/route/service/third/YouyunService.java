package com.kupai.gateway.route.service.third;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.kupai.gateway.common.retrofit.ServiceGenerator;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.service.httpClient.YouyunClient;
import com.kupai.gateway.route.util.Constants;
import com.kupai.gateway.route.youyun.MessageHandler;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

import static com.kupai.gateway.common.contants.Constants.SOURCE;

/**
 * 调用游云服务相关接口
 * Created by Administrator on 2017/2/22.
 */
@Service("youyunService")
public class YouyunService {
    //游云域名
    @Value("${youyun.domain}")
    private String youYunDomain;

    @Value("${youyun.api.wh.message.url}")
    private String imMessageUrl;

    @Value("${youyun.im.login.room.url}")
    private String loginRoomUrl;

    @Value("${youyun.im.quit.room.url}")
    private String quitRoomUrl;

    private YouyunClient youyunClient;

    /**
     * 初始化http接口实例
     */
    @PostConstruct
    public void init() {
        ApiLogger.info("init retrofit youyunClient");
        youyunClient = ServiceGenerator.createService(YouyunClient.class, youYunDomain, 2000);
    }

    /**
     * h5登录聊天室
     *
     * @param token 库拍token
     * @param gid   聊天室id
     * @param uid   我们的uid
     * @return
     */
    public boolean loginRoom(String token, Integer gid, Long uid) {
        if (StringUtils.isEmpty(token) || gid <= 0 || uid <= 0) {
            return false;
        }
        //构造HTTP请求头
        Map<String, String> httpHeader = this.getHeader();

        //构造HTTP POST参数
        Map<String, String> parameterMap = new HashMap<>(2);
        parameterMap.put("gid", String.valueOf(gid));
        parameterMap.put("thirdUid", String.valueOf(uid));

        JsonObject postResult = ServiceGenerator.execute(youyunClient.loginRoom(loginRoomUrl, httpHeader, parameterMap), parameterMap);
        if (null != postResult && StringUtils.isNotEmpty(postResult.toString())) {
            return YouyunService.acquireResult(postResult.toString());
        }
        return false;
    }

    /**
     * h5登出聊天室
     *
     * @param token 库拍token
     * @param gid   聊天室id
     * @param uid   我们的uid
     * @return
     */
    public boolean quitRoom(String token, Integer gid, Long uid) {
        if (StringUtils.isEmpty(token) || null == gid || gid <= 0 || uid <= 0) {
            return false;
        }
        //构造HTTP请求头
        Map<String, String> httpHeader = this.getHeader();

        //构造HTTP POST参数
        Map<String, String> parameterMap = new HashMap<>();
        parameterMap.put("gid", String.valueOf(gid));
        parameterMap.put("thirdUid", String.valueOf(uid));

        JsonObject postResult = ServiceGenerator.execute(youyunClient.quitRoom(quitRoomUrl, httpHeader, parameterMap), parameterMap);
        if (null != postResult && StringUtils.isNotEmpty(postResult.toString())) {
            return YouyunService.acquireResult(postResult.toString());
        }
        return false;
    }

    /**
     * 调用游云发送消息接口
     *
     * @param content h5端传递过来的消息的内容
     * @return
     */
    public boolean sendImMessage(JSONObject content) {
        //1.将评论组装成IM的评论消息
        String fromUid = content.getString(com.kupai.gateway.common.contants.Constants.FROM_UID);
        if (StringUtils.isEmpty(fromUid)) {
            ApiLogger.warn(String.format("fromUid is invalid, context %s", content.toJSONString()));
            return false;
        }
        String toUid = content.getString(com.kupai.gateway.common.contants.Constants.ROOM_ID);
        if (StringUtils.isEmpty(toUid)) {
            ApiLogger.warn(String.format("toUid is invalid, context %s", content.toJSONString()));
            return false;
        }

        String commentText = content.getString(com.kupai.gateway.common.contants.Constants.COMMENT_TEXT);
        String extContent = content.getString(com.kupai.gateway.common.contants.Constants.COMMENT_EXT);
        if (StringUtils.isBlank(extContent)) {
            extContent = "{}";
        }
        //2.调用IM接口发送评论消息
        //构造HTTP请求头
        Map<String, String> httpHeader = this.getHeader();
        Map<String, String> parameterMap = new HashMap<>(5);
        parameterMap.put("thirdUid", fromUid);
        parameterMap.put("touId", toUid);
        //未打开验证是否有敏感词
        parameterMap.put("check", "0");
        //扩展信息内容
        String encodingExtContent = extContent;
        JSONObject extJsonObject = JSONObject.parseObject(encodingExtContent);
        //在ext中添加来源，用于在从yy接受到消息后，是否继续由rm继续处理
        extJsonObject.put(SOURCE, MessageHandler.RM_SOURCE);
        parameterMap.put("data", commentText);
        parameterMap.put("extContent", extJsonObject.toJSONString());
        //调用发送聊天消息接口
        ServiceGenerator.asyExecute(youyunClient.sendImMessage(imMessageUrl, httpHeader, parameterMap), parameterMap, null, null);
        return true;
    }

    /**
     * 获得header
     *
     * @return
     */
    private static Map<String, String> getHeader() {
        //构造HTTP请求头
        Map<String, String> httpHeader = new HashMap<>(2);
        httpHeader.put(Constants.X_Client_ID_HEADER, Constants.X_Client_ID);
        httpHeader.put(Constants.X_Matrix_UID_HEADER, Constants.X_Matrix_UID);
        return httpHeader;
    }

    /**
     * 获得调用游云结果数据
     *
     * @param apiResult 游云返回的调用结果
     * @return
     */
    private static boolean acquireResult(String apiResult) {
        try {
            if (StringUtils.isNotEmpty(apiResult)) {
                JSONObject jsonObject = JSON.parseObject(apiResult);
                if (null != jsonObject) {
                    int apiStatus = jsonObject.getIntValue("apistatus");
                    if (apiStatus == 1) {
                        return jsonObject.getBooleanValue("result");
                    }
                }
            }
        } catch (Exception e) {
            ApiLogger.error("YouyunService-acquireResult-get result error:" + e);
        }
        return false;
    }
}
