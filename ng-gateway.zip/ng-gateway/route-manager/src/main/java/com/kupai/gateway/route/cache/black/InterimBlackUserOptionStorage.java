package com.kupai.gateway.route.cache.black;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kupai.gateway.common.util.TimeUtil;
import com.kupai.gateway.route.constant.BlackRedisKeyPre;

import redis.clients.jedis.JedisCluster;

/**
 * Created by Administrator on 2017/3/29.
 */
@Component
public class InterimBlackUserOptionStorage {

    @Autowired
    private JedisCluster jedisCluster;

    /**
     * 添加临时禁言黑名单
     *
     * @param source
     * @param roomId
     * @param uid
     * @param invalidTime
     * @return
     */
    public boolean addInterimBlack(String source, String roomId, String uid, Long invalidTime) {
        String key = this.getKey(source, roomId);
        //首先删除掉已经存在的uid，然后再设置
        jedisCluster.hdel(key, uid);
        return jedisCluster.hset(key, uid, String.valueOf(invalidTime)) > 0;
    }

    /**
     * 验证是否在临时禁言黑名单中
     *
     * @param source 来源
     * @param roomId 房间号
     * @param uid    验证的用户uid
     * @return
     */
    public boolean isInInterimBlack(String source, String roomId, String uid) {
        String key = this.getKey(source, roomId);
        String value = jedisCluster.hget(key, uid);
        //如果在房间内
        if (StringUtils.isNotEmpty(value)) {
            Long invalidTime = Long.parseLong(value);
            //已失效
            if (TimeUtil.getCurrentSeconds() - invalidTime > 0) {
                //删除该禁言名单
                jedisCluster.hdel(key, uid);
                return false;
            }
            return true;
        }
        return false;
    }

    /**
     * 获得某个房间内的所有的黑名单列表
     * @param key
     * @return
     */
    public Map<String, String> getRoomInterimBlackUserMap(String key) {
        Map<String, String> map = jedisCluster.hgetAll(key);
        if (null != map) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                String uid = entry.getKey();
                Long invalidTime = Long.valueOf(entry.getValue());
                //已失效
                if (TimeUtil.getCurrentSeconds() - invalidTime > 0) {
                    //删除redis无用元素
                    jedisCluster.hdel(key, uid);
                    //删除元素
                    map.remove(uid);
                }
            }
            return map;
        }
        return null;
    }

    /**
     * 删除某个域
     * @param key
     * @param uid
     * @return
     */
    public boolean delFiled(String key, String uid) {
        jedisCluster.hdel(key, uid);
        return true;
    }

    /**
     * 获取操作的key
     *
     * @param source
     * @param roomId
     * @return
     */
    public String getKey(String source, String roomId) {
        return BlackRedisKeyPre.BLACK_USER_INTERIM_LIST_PRE + source + "_" + roomId;
    }
}
