package com.kupai.gateway.route.model;

import org.apache.commons.lang.math.RandomUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 敏感词匹配树
 */
public class ForbidWordTrie {
    
    public static class ForbidWordVal {
        private String val;
        // 敏感词级别
        private int level;
        //敏感词开关 1开  0关
        private int status;
        private int source;
        

        public ForbidWordVal(String val, int level, int status, int source) {
            this.val = val;
            this.level = level;
            this.status = status;
            this.source = source;
        }

        public String toString() {
            return val;
        }

        public String getVal() {
            return val;
        }

        public int getLevel() {
            return level;
        }

        public int getStatus() {
            return status;
        }

        public int getSource() {
            return source;
        }
    }


    static class Node {
        // 使用有序数组存储子节点,&字符表示通用匹配符，存储在0位置上
        private Node[] childs = new Node[2];
        private char ch;
        private int len;
        private ForbidWordVal val;

        void print() {
            if (this.val != null) {
                System.out.println(this.val);
            }

            for (int i = 0; i < len; i++) {
                childs[i].print();
            }
        }

        private int cmp(char x, char y) {
            if (x == '&') {
                return -1;
            } else if (y == '&') {
                return 1;
            } else {
                return x - y;
            }
        }

        public void add(Node n) {
            // 确保数组容量
            if ((this.len + 1) >= childs.length) {
                int l = (int) ((this.len + 1) * 1.5);
                Node[] copy = new Node[l];
                System.arraycopy(this.childs, 0, copy, 0, this.len);
                this.childs = copy;
            }

            Node t = this;
            int k = t.len;
            while (k > 0) {
                // 把大于当前数组的节点往后移动
                if (cmp(t.childs[k - 1].ch, (n.ch)) > 0) {
                    t.childs[k] = t.childs[k - 1];
                    k--;
                } else {
                    t.childs[k] = n;
                    t.len++;
                    break;
                }
            }
            if (k == 0) {
                t.childs[0] = n;
                t.len++;
            }
        }
    }

    private Node root;
    private int size;

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public ForbidWordTrie() {
        this.root = new Node();
    }

    public ForbidWordTrie(Node root) {
        this.root = root;
    }

    /*   public void add(ForbidWord word) {
           this.add(word.getName(), word.getLevel(), word.getStatus().getValue());
       }*/
    public void add(ForbidWord word) {
        this.add(word.getName(), word.getLevel(), word.getStatus().getValue(), word.getSource());
    }

    public void add(String s, int level, int status, int source) {
        char[] chars = s.toCharArray();
        Node t = this.root;
        Node x = null;
        for (int i = 0; i < chars.length; i++) {
            if ((x = search(t, chars[i])) != null) {
                t = x;
            } else {
                Node n = new Node();
                n.ch = chars[i];
                t.add(n);
                t = n;
            }
        }
        // 叶子节点保存匹配字符串
        t.val = new ForbidWordVal(s, level, status, source);
        this.size++;
    }

    Node search(Node node, char x) {
        if (node.len == 0) {
            return null;
        }

        int low = 0;
        int hight = node.len - 1;
        int mid = (low + hight) / 2;

        while (low <= hight) {
            if (node.childs[mid].ch == x) {
                return node.childs[mid];
            } else if (node.childs[mid].ch < x) {
                low = mid + 1;
            } else {
                hight = mid - 1;
            }
            mid = (low + hight) / 2;
        }
        return null;
    }

    /**
     * 匹配子字符串
     *
     * @param str
     * @return
     */
    public List<ForbidWordVal> match(String str) {
        List<ForbidWordVal> data = new ArrayList<>();
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            int k = 0;
            Node x = this.root;
            Node y = search(x, chars[k + i]);

            while (y != null) {
                if (y.val != null) {
                    data.add(y.val);
                }
                // 如果下个节点是通用字符，那么使用字符串重新开始匹配
                if (y.len > 0 && y.childs[0].ch == '&') {
                    data.addAll(new ForbidWordTrie(y.childs[0]).match(str.substring(k + i + 1)));
                }
                x = y;
                k++;
                if (((k + i) < chars.length)) {
                    y = search(x, chars[k + i]);
                } else {
                    break;
                }
            }
        }
        return data;
    }

    static String randWord() {

        char[] c = "如果违反多级别敏感词的话按最高级别处理那么如If you've seen how dozens of lines of Java or Ruby can dissolve into just a few lines of Clojure, you'll know why the authors of this book call it a \"joyful language.\" Clojure is a dialect of Lisp that runs on the JVM. It combines the nice features of a scripting language with the powerful features of a p【俄回应欧盟撤军要求:恼火一方总是错误一方】俄罗斯外长拉夫罗夫最近很忙，3天时间至少跑了4个国家，话题始终围绕乌克兰，立场也是一如既往：“通常情况下，恼火的一方，永远是错误的一方。”拉夫罗夫批评西方放弃此前的和平协议、克里米亚驻军符合两国协议。详见roduction environment—features like persistent data structures and clean multithreading that you'll need for industrial-strength application developmen".toCharArray();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < (3 + RandomUtils.nextInt(10)); i++) {
            sb.append(c[RandomUtils.nextInt(c.length - 1)]);
        }
        return sb.toString();

    }

    void print() {

    }

    public static void main(String[] args) {

        /*ForbidWordTrie t = new ForbidWordTrie();
        t.add("江泽民&习近平", 1, 1);
        t.add("江泽民&习近平&d", 1, 1);
        t.add("毛习近平1", 1, 1);
        t.add("江泽民1", 1, 1);
        t.add("对方的大幅度反弹大幅度反弹分1", 1, 1);
        t.add("dfd1", 1, 1);
        t.add("wwabd", 1, 1);
        t.add("w&a", 1, 1);
        String word = null;
        for (int i = 0; i < 10000; i++) {
            word = randWord();
            t.add(word, 1, 1);
        }

        long start = System.currentTimeMillis();
        List<ForbidWordVal> wwabddabccc = null;
        for (int i = 0; i < 10000; i++) {

            wwabddabccc = t.match("wwabd江泽民dqwwwwwwa习近平1bcccddddddddddddddddddddddddddddddddddddddwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwcc");
        }

        for (ForbidWordVal v : wwabddabccc) {
            System.out.println(v.getVal());
        }
        System.out.print(System.currentTimeMillis() - start);*/
    }
}
