package com.kupai.gateway.route.annocations;

/**
 * @author zhangrui
 */
public enum ApiStatus {


    INTERNAL() {
        public int id() {
            return 5;
        }

        public String desc() {
            return "已上线的内部接口";
        }
    },
    PUBLIC {
        public int id() {
            return 7;
        }

        public String desc() {
            return "已上线的公开接口";
        }
    };


    public abstract int id();

    public abstract String desc();
}
