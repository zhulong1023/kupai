package com.kupai.gateway.route.service.third;

import com.google.gson.JsonObject;
import com.kupai.gateway.common.retrofit.ServiceGenerator;
import com.kupai.gateway.route.service.httpClient.ShUploadClient;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.util.HashMap;

/**
 * Created by Administrator on 2017/3/21.
 */
@Service
public class ShUploadService {
    private static Logger LOGGER = LoggerFactory.getLogger(ShUploadService.class);

    private ShUploadClient shUploadClient;

    @Value("${upload.shanghai.domain}")
    private String uploadDomain;

    @Value("${upload.shanghai.file.url}")
    private String uploadFileUrl;

    /**
     * 初始化http接口实例
     */
    @PostConstruct
    public void init() {
        LOGGER.info("init retrofit youyunClient");
        shUploadClient = ServiceGenerator.createService(ShUploadClient.class, uploadDomain, 5000);
    }

    /**
     * 上传文件
     * @param fileItem 具体的文件内容
     * @return 返回上传的文件对应的id
     */
    public String uploadFile(MultipartFile fileItem) throws Exception {
        // 创建 RequestBody，用于封装构建RequestBody
        RequestBody requestFile = RequestBody.create(MediaType.parse(fileItem.getContentType()), fileItem.getBytes());
        // MultipartBody.Part  和后端约定好Key，这里的partName是用image
        MultipartBody.Part body = MultipartBody.Part.createFormData("pic", fileItem.getName(), requestFile);
        // 添加描述
        String descriptionString = "description";
        RequestBody description = RequestBody.create(MediaType.parse(fileItem.getContentType()), descriptionString);
        JsonObject jsonObject = ServiceGenerator.execute(shUploadClient.upload(uploadFileUrl, description, body), new HashMap<>(1));
        if (null != jsonObject) {
            return jsonObject.get("picid").getAsString();
        }
        return null;
    }
}
