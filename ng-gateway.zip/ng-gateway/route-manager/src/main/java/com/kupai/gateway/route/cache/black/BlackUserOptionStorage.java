package com.kupai.gateway.route.cache.black;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.util.TimeUtil;
import com.kupai.gateway.route.constant.BlackRedisKeyPre;
import com.kupai.gateway.route.log.ApiLogger;

import redis.clients.jedis.JedisCluster;

/**
 * Created by Administrator on 2017/3/23.
 */
@Service
public class BlackUserOptionStorage {

    //永久禁言标示
    public static final long FOREVER_GAG = -1L;

    @Autowired
    private JedisCluster jedisCluster;

    /**
     * 添加黑名单
     *
     * @param system      系统英文名
     * @param uid         uid禁言的uid
     * @param invalidTime 禁言失效时间
     * @return
     */
    public boolean saveBlackToGlobalList(String system, String uid, Long invalidTime) {
        String userKey = BlackRedisKeyPre.BLACK_USER_LIST_GLOBAL_PRE + system + "_";
        //先删除已经存在的uid
        jedisCluster.hdel(userKey, uid);
        long userList = jedisCluster.hset(userKey, uid, invalidTime + "");
        if (userList <= 0) {
            ApiLogger.redis(String.format("saveBlackToGlobalList failed, system %s, uid %s, invalidTime %s, userList:", system, uid, invalidTime, userList), 2);
        }
        return userList > 0;
    }

    /**
     * 从黑名单中删除该禁言用户
     *
     * @param system 系统英文名
     * @param uid    uid禁言的uid
     * @return
     */
    public boolean removeBlackFromGlobalList(String system, String uid, String modifyUser) {
        try {
            String userKey = BlackRedisKeyPre.BLACK_USER_LIST_GLOBAL_PRE + system + "_";
            return jedisCluster.hdel(userKey, uid + "") > 0;
        } catch (Exception e) {
            ApiLogger.redis(String.format("removeBlackFromGlobalList system %s, uid %s, error %s", system, uid, e), 3);
        }
        return false;
    }

    /**
     * 获取用户是否是黑名单用户
     *
     * @param system 系统英文名
     * @param uid    uid
     * @return
     */
    public boolean isBlackUser(String system, String uid) {
        boolean flag = false;
        try {
            String userKey = BlackRedisKeyPre.BLACK_USER_LIST_GLOBAL_PRE + system + "_";
            String invalidTime = jedisCluster.hget(userKey, uid);
            if (StringUtils.isNotEmpty(invalidTime)) {
                long _invalidTime = Long.valueOf(invalidTime);
                if (_invalidTime == FOREVER_GAG) {
                    flag = true;
                } else {
                    //验证是否还在禁言时间内
                    flag = TimeUtil.getCurrentSeconds() - _invalidTime < 0 ? true : false;
                    if (!flag) {
                        boolean _flag = this.removeBlackFromGlobalList(system, uid, "system");
                        ApiLogger.redis(String.format("isBlackUser del black expire user,system %s, uid %s, _flag %s", system, uid, _flag), 1);
                    }
                }
            }
            return flag;
        } catch (Exception e) {
            ApiLogger.redis(String.format("isBlackUser system %s, uid %s, error %s", system, uid, e), 3);
        }
        return flag;
    }


    /**
     * 获取所有的黑名单用户
     *
     * @return
     */
    public Map<String, String> getAllBlackUserMap(String system) {
        try {
            String userKey = BlackRedisKeyPre.BLACK_USER_LIST_GLOBAL_PRE + system + "_";
            return jedisCluster.hgetAll(userKey);
        } catch (Exception e) {
            e.printStackTrace();
            ApiLogger.redis(String.format("getAllBlackUserMap is error, system %s, e %s", system, e), 3);
        }
        return null;
    }
}
