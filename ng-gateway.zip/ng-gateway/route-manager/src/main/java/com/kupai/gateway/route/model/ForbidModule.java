package com.kupai.gateway.route.model;

import java.util.Arrays;
import java.util.List;

/**
 * 敏感词模块分类
 */
public class ForbidModule {

    /**
     * 使用敏感词的模块分类
     */
    public static enum ModuleKind  {
        create_name(1, "创建名称"),
        message(2, "聊天消息");
        /*create_intra(2, "创建简介"),
        search_user(3, "搜索用户"),
        search_group(4, "搜索群组"),
        private_chat(5, "私聊"),
        group_chat(6, "群聊"),
        user_state(7, "个人动态"),
        group_state(8, "群组动态"),
        event(9, "活动"),
        comment(10, "评论");*/

        private int id;
        private String name;

        ModuleKind(int id, String name) {
            this.id = id;
            this.name = name;
        }

        /*public JSONObject toJSONObject() {
            JSONObject object = new JSONObject();
            object.append("id", id);
            object.append("name", name);

            return object;
        }*/

    }

    /**
     * 敏感词处理策略
     */
    public static enum Value {
        use(0, "豁免"),
        use_with_mark(1, "允许使用，但是将敏感词替换成***"),
        forbid(2, "禁止使用");
        private int val;
        private String desc;

        Value(int val, String desc) {
            this.val = val;
            this.desc = desc;
        }

        /*public JSONObject toJSONObject() {
            JSONObject object = new JSONObject();
            object.append("val", val);
            object.append("desc", desc);

            return object;
        }*/

        public int getVal() {
            return val;
        }

        public String getDesc() {
            return desc;
        }

        public static String getDesc(int val) {
            for (Value v : Value.values()) {
                if (v.val == val) {
                    return v.desc;
                }
            }
            return "";
        }
    }

    /**
     * 使用敏感词的模块
     */
    public static enum Module  {

        text_message(1, ModuleKind.message, "聊天文本消息");
       /* user_nickname(1, ModuleKind.create_name, "创建用户昵称"),
        secret_group_name(2, ModuleKind.create_name, "创建私密群组名称"),
        public_group_name(3, ModuleKind.create_name, "创建公开群组名称"),

        user_intra(4, ModuleKind.create_intra, "创建个人简介"),
        secret_group_intra(5, ModuleKind.create_intra, "创建私密群组简介"),
        public_group_intra(6, ModuleKind.create_intra, "创建公开群组简介"),

        search_user(7, ModuleKind.search_user, "搜索用户"),
        search_nearby(8, ModuleKind.search_user, "搜索附近的人"),
        search_group(9, ModuleKind.search_group, "搜索群组"),
        search_group_nearby(10, ModuleKind.search_group, "搜索附近的群组"),

        private_chat_great(11, ModuleKind.private_chat, "私聊-打招呼"),
        private_chat_friend(12, ModuleKind.private_chat, "私聊-好友会话"),
        group_chat_temp(13, ModuleKind.group_chat, "群聊-临时群组"),
        group_chat_secret(14, ModuleKind.group_chat, "群聊-私密群聊"),
        group_chat_public(15, ModuleKind.group_chat, "群聊-公开群组"),

        private_state_photo(16, ModuleKind.user_state, "动态-我的相册"),
        group_state_secret(17, ModuleKind.group_state, "动态-私密群组"),
        group_state_public(18, ModuleKind.group_state, "动态-公开群组"),

        event_secret_group(19, ModuleKind.event, "活动-私密群组"),
        event_public_group(20, ModuleKind.event, "活动-公开群组"),

        comment_friend(21, ModuleKind.comment, "好友评论"),
        comment_secret_group(22, ModuleKind.comment, "私密群组评论"),
        comment_public_group(23, ModuleKind.comment, "公开群组评论"),

        group_mark(24, ModuleKind.create_name, "我的群昵称");*/

        private int id;
        private ModuleKind kind;
        private String name;

        public static Module valueOf(int id) {
            for (Module m : values()) {
                if (id == m.getId()) {
                    return m;
                }
            }
            return null;
        }


        Module(int id, ModuleKind kind, String name) {
            this.id = id;
            this.kind = kind;
            this.name = name;
        }


        /*public JSONObject toJSONObject() {
            JSONObject object = new JSONObject();
            object.append("id", id);
            object.append("name", name);
            object.append("kind", kind.toJSONObject());

            return object;
        }*/

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public ModuleKind getKind() {
            return kind;
        }

        public void setKind(ModuleKind kind) {
            this.kind = kind;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static List<ModuleKind> getModuleAll() {
        return Arrays.asList(ModuleKind.values());
    }

    public static class Result{

        String text;
        boolean flag;

        public Result(String text,boolean flag){
            this.text = text;
            this.flag = flag;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public boolean getFlag() {
            return flag;
        }

        public void setFlag(boolean flag) {
            this.flag = flag;
        }
    }

}
