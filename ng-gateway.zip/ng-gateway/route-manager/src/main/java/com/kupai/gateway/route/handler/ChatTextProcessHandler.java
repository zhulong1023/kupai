package com.kupai.gateway.route.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.contants.Constants;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.common.data.DataMeta;
import com.kupai.gateway.common.data.Text;
import com.kupai.gateway.common.data.enumpac.ChatTypeEnum;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.util.IdWorker;
import com.kupai.gateway.route.handler.processor.DefaultRequestProcessor;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.model.HistoryMessage;
import com.kupai.gateway.route.service.HistoryMessageService;
import com.kupai.gateway.route.service.third.YouyunService;
import com.kupai.gateway.route.youyun.MessageHandler;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Objects;

/**
 * 文字聊天处理类 Created by Administrator on 2017/3/27.
 */
@Component
public class ChatTextProcessHandler extends AbstractProcessHandler {

    @Autowired
    private YouyunService youyunService;

    @Autowired
    private HistoryMessageService historyMessageService;

    @Autowired
    private IdWorker idWorker;

    /**
     * 注册该处理器
     */
    @PostConstruct
    protected void registerHandler() {
        DefaultRequestProcessor.registerProcessHandler(RequestCode.MSG_TEXT, this);
    }

    /**
     * 处理接收到的消息
     *
     * @param jGroupMessage
     * @return
     */
    @Override
    protected JGroupMessage doProcess0(JGroupMessage jGroupMessage) {
        ApiLogger.message(String.format("do process chat text message start, message info %s", jGroupMessage.toString()));
        Text text = (Text) jGroupMessage.getData();
        DataMeta dataMeta = text.getMeta();
        try {
            ChatTypeEnum.parser(dataMeta.getChatType());
        } catch (Exception e) {
            jGroupMessage.setCode(ResponseCode.SYSTEM_ERROR);
            jGroupMessage.setData(ResponseMessage.NOT_SUPPORT_CHAT_MESSAGE);
            return jGroupMessage;
        }

        // 存入到数据库中
        HistoryMessage historyMessage = new HistoryMessage();
        long messageId = idWorker.nextId();
        jGroupMessage.setMsgId(messageId);
        historyMessage.setId(messageId);

        //防止ext为string类型
        JSONObject ext = null;
        if (dataMeta.getExt() instanceof JSONObject) {
            ext = (JSONObject) dataMeta.getExt();
        } else {
            ext = JSON.parseObject((String) dataMeta.getExt());
        }
        dataMeta.setExt(ext);

        //at消息处理
        List<Long> atUidList = dataMeta.getAtUid();
        if (atUidList != null) {
            jGroupMessage.setAtUid(atUidList);
            dataMeta.setAtUid(null);//历史不存at信息，减少信息长度
        }

        JSONObject textJson = JSONObject.parseObject(JSONObject.toJSONString(text));
        textJson.put("messageId", String.valueOf(messageId));

        historyMessage.setContent(textJson.toJSONString());
        historyMessage.setSource(jGroupMessage.getSource());
        historyMessage.setType(dataMeta.getChatType());
        historyMessage.setCreateTime(System.currentTimeMillis());
        historyMessage.setUserId(dataMeta.getFrom());
        historyMessage.setStatus(1);
        if (jGroupMessage.getToUid() != null) {
            for (long uid : jGroupMessage.getToUid()) {
                historyMessage.setSessionId(dataMeta.getFrom() >= uid ? dataMeta.getFrom() + "_" + uid : uid + "_" + dataMeta.getFrom());
                historyMessageService.receiveMessage(historyMessage);
            }
        } else {
            if (dataMeta.getChatType() == ChatTypeEnum.ROOM.getType()) {
                historyMessage.setSessionId(String.valueOf(dataMeta.getTo()));
                // todo 发送完成后，需要发送到云通讯，需要判断聊天消息的来源，即来自哪个系统，来自库拍才进行转发到游云
                this.sendTextMessageToYouyun(text);
            } else {
                historyMessage.setSessionId(dataMeta.getFrom() >= dataMeta.getTo() ? dataMeta.getFrom() + "_" + dataMeta.getTo() : dataMeta.getTo() + "_" + dataMeta.getFrom());
            }
            historyMessageService.receiveMessage(historyMessage);
        }

        //在此处发送回执
        this.doResponse0(jGroupMessage, dataMeta.getFrom(), ResponseCode.MSG_TEXT_OK);

        jGroupMessage.setSourceAdd(null);
        jGroupMessage.setSendType(JGroupMessage.SendType.MULTI.getValue());

        return jGroupMessage;
    }

    /**
     * 发送聊天消息到游云
     *
     * @param text
     */
    private void sendTextMessageToYouyun(Text text) {
        DataMeta dataMeta = text.getMeta();
        JSONObject ext = (JSONObject) dataMeta.getExt();
        if (null != ext) {
            //判断如果消息来自于游云系统，则不再转发给游云系统进行处理
            String yySource = ext.getString(Constants.SOURCE);
            if (StringUtils.isNotEmpty(yySource) && Objects.equals(yySource, MessageHandler.YY_SOURCE)) {
                return;
            }
        }
        // 需要对消息进行处理后，调用游云
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(com.kupai.gateway.common.contants.Constants.FROM_UID, dataMeta.getFrom());
        jsonObject.put(com.kupai.gateway.common.contants.Constants.ROOM_ID, dataMeta.getTo());
        jsonObject.put(com.kupai.gateway.common.contants.Constants.COMMENT_TEXT, text.getContent());
        jsonObject.put(com.kupai.gateway.common.contants.Constants.COMMENT_EXT, dataMeta.getExt());
        youyunService.sendImMessage(jsonObject);
    }
}
