package com.kupai.gateway.route.dao;

import com.kupai.gateway.route.model.BlackUserDO;

import java.util.List;

/**
 * 黑名单数据库操作
 * Created by Administrator on 2017/3/23.
 */
public interface BlackUserDao {
    /**
     * 保存黑名单
     *
     * @param blackUserDO
     * @return
     */
    boolean saveBlackUser(BlackUserDO blackUserDO);

    /**
     * 删除黑名单
     *
     * @param system 系统英文名
     * @param uid    uid
     * @return
     */
    boolean removeBlackUser(String system, String uid, String modifyUser);

    /**
     * 支持分页
     *
     * @param system   系统英文名
     * @param page     第几页
     * @param pageSize 每页数据大小
     * @return
     */
    List<BlackUserDO> listBlackUser(String system, int page, int pageSize);

    /**
     * 查询黑名单数量
     *
     * @param system 系统英文名
     * @return
     */
    Integer countBlackUser(String system);
}
