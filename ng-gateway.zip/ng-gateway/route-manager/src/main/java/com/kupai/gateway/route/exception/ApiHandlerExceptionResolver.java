package com.kupai.gateway.route.exception;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.PriorityOrdered;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import com.kupai.gateway.route.context.RouteManagerContext;
import com.kupai.gateway.route.log.ApiLogger;

/**
 * 统一封装异常信息
 * Created by zhangrui on 16/3/7.
 */
public class ApiHandlerExceptionResolver implements HandlerExceptionResolver, PriorityOrdered {
	
	private static ModelAndView NULL_VIEW = new ModelAndView();

    @Override
    public ModelAndView resolveException(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
        ErrorResult apiError = null;
        if (e instanceof ApiException) {
            apiError = ((ApiException) e).getResultCode();
        } else if(e instanceof HttpRequestMethodNotSupportedException){
        	apiError = new ErrorResult(ErrorResultCode.API_ERROR.getErrorCode(), e.getMessage());
        }  else if(e instanceof MissingServletRequestParameterException){
        	apiError = new ErrorResult(ErrorResultCode.PARAM_REQUIRED.getErrorCode(), ErrorResultCode.PARAM_REQUIRED.getError());
        	apiError.setError(String.format(apiError.getError(), ((MissingServletRequestParameterException)e).getParameterName()));
        } else {
            apiError = ErrorResultCode.API_ERROR;
            ApiLogger.error("api error", e);
        }

        try{
            httpServletResponse.setHeader("Content-Type", "application/json;charset=UTF-8");
            try(PrintWriter pw = httpServletResponse.getWriter()){
            	pw.write(apiError.toString());
            }
            
            try {
                ApiLogger.request(RouteManagerContext.getRouteManagerContext().getOriginRequest(), RouteManagerContext.getRouteManagerContext().getOriginResponse());
            }
          catch (Exception e1){
              ApiLogger.error("write the request log error", e1);
          }
        } catch (Exception exp) {
            ApiLogger.error("write to browser error", exp);
        }
        return NULL_VIEW;
    }

	@Override
	public int getOrder() {
		// 作为最先执行的错误处理
		return Integer.MIN_VALUE;
	}
}
