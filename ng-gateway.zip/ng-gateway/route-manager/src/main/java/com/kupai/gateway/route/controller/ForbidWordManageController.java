package com.kupai.gateway.route.controller;

import com.kupai.gateway.common.util.StringUtils;
import com.kupai.gateway.route.annocations.ApiStatus;
import com.kupai.gateway.route.annocations.AuthType;
import com.kupai.gateway.route.annocations.BaseInfo;
import com.kupai.gateway.route.annocations.SignType;
import com.kupai.gateway.route.data.Result;
import com.kupai.gateway.route.model.ForbidWord;
import com.kupai.gateway.route.service.ForbidWordService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhulong on 2017/3/31.
 * 敏感词接口
 */
@RestController
@RequestMapping(value = "/route/api/forbidword/manage")
public class ForbidWordManageController {

    private static Logger LOGGER = LoggerFactory.getLogger(ForbidWordManageController.class);

    @Autowired
    private ForbidWordService forbidWordService;

    /**
     * 新增敏感词
     * @param name      敏感字
     * @param type      敏感词类型,如：毒品药品
     * @param status    生效状态: 失效 0; 有效 1
     * @param level     敏感词级别(0:‘豁免’ 1:‘允许使用，但是将敏感词替换成***’ 2:‘禁止使用’)
     * @param source    敏感词来源，如：库拍;开放平台;自定义
     * @param startTime 生效时间:空值表示永久有效(格式为：”yyyy-MM-dd HH:mm:ss“)
     * @param endTime   失效时间(格式为：”yyyy-MM-dd HH:mm:ss“)
     * @return
     */
    @RequestMapping(value = "addForbidWord",method = RequestMethod.POST,
            produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> addForbidWord(
            @RequestParam(value = "name",required = true) String name,
            @RequestParam(value = "type",required = true) String type,
            @RequestParam(value = "status",required = true) int status,
            @RequestParam(value = "level",required = true) int level,
            @RequestParam(value = "source", required = false, defaultValue = "-1") int source,
            @RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime){

        ForbidWord.WordStatus wordStatus = ForbidWord.WordStatus.parseValue(status);
        Timestamp startTimeParse = null;
        Timestamp endTimeParse = null;

        boolean flag = false;
        try {
            if (StringUtils.isNotBlank(startTime)) {
                startTimeParse = Timestamp.valueOf(startTime);
            }
            if (StringUtils.isNotBlank(endTime)) {
                endTimeParse = Timestamp.valueOf(endTime);
            }
            ForbidWord dto = new ForbidWord(name, type, level, wordStatus, startTimeParse, endTimeParse, source);

            flag = forbidWordService.add(dto);
        }catch (Exception e){
            LOGGER.error("editForbidWord  insert failed  ",e);
        }
        return new Result<>(flag);
    }

    /**
     * 修改敏感词
     * @param name       敏感字
     * @param type       敏感词类型,如：毒品药品
     * @param status     生效状态: 失效 0; 有效 1
     * @param level      敏感词级别(0:‘豁免’ 1:‘允许使用，但是将敏感词替换成***’ 2:‘禁止使用’)
     * @param id         敏感词主键ID
     * @param startTime  生效时间:空值表示永久有效
     * @param endTime    失效时间
     * @return
     */
    @RequestMapping(value = "editForbidWord",method = RequestMethod.POST,
            produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> editForbidWord(
            @RequestParam(value = "id",required = true) Long id,
            @RequestParam(value = "name",required = false) String name,
            @RequestParam(value = "type",required = false) String type,
            @RequestParam(value = "status",required = false) int status,
            @RequestParam(value = "level",required = false) int level,
            @RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime){

        ForbidWord.WordStatus wordStatus = ForbidWord.WordStatus.parseValue(status);
        Timestamp startTimeParse = null;
        Timestamp endTimeParse = null;

        boolean flag = false;
        try {
            if (StringUtils.isNotBlank(startTime)) {
                startTimeParse = Timestamp.valueOf(startTime);
            }
            if (StringUtils.isNotBlank(endTime)) {
                endTimeParse = Timestamp.valueOf(endTime);
            }
            ForbidWord dto = new ForbidWord(id,name, type, level, wordStatus, startTimeParse, endTimeParse);

            flag = forbidWordService.updateInfor(dto);
        }catch (Exception e){
            LOGGER.error("editForbidWord  update failed  ",e);
        }
        return new Result<>(flag);
    }


    /**
     * 查询敏感词
     * @param name   敏感字
     * @param page  当前页
     * @param num   每页展示的条数
     * @return
     */
    @RequestMapping(value = "queryForbidWords",method = RequestMethod.GET,
            produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "查询敏感词，带分页", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> queryForbidWords(
            @RequestParam(value = "name",required = true) String name,
            @RequestParam(value = "page",required = true) int page,
            @RequestParam(value = "num",required = true) int num
    ){
        long countRecords = forbidWordService.queryCountForbid(name);
        long totalPage = countRecords / num + (countRecords % num == 0 ? 0 : 1);
        List<Map<String, Object>> result =  forbidWordService.queryForbidWords(name,page,num);
        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("total_page", totalPage);
        resultMap.put("count", countRecords);
        resultMap.put("words", result);
        return new Result<>(resultMap);
    }

    /**
     * 删除某个类型下的所有敏感词
     * @param type  敏感词类型,如：毒品药品
     * @return
     */
    @RequestMapping(value = "deleteByType",method = RequestMethod.POST,
            produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> deleteByType(
            @RequestParam(value = "type",required = true) String type){

        boolean flag = forbidWordService.delByType(type);
        return new Result<>(flag);
    }



    /**
     * 批量添加敏感词
     * @param level  敏感词级别ID
     * @param assembleStr 拼装串：每个敏感词之间用|分割,敏感词各个属性之间用,分割.(敏感字,类型,生效状态,生效时间,失效时间,来源)
     * @return
     */
    @RequestMapping(value = "batchAdd",method = RequestMethod.POST,
            produces = {"application/json;charset=UTF-8"})
    @BaseInfo(desc = "批量添加敏感词", status = ApiStatus.INTERNAL, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> batchAdd(
            @RequestParam(value = "level",required = true) int level,
            @RequestParam(value = "assembleStr",required = true) String assembleStr
    ){
        List<ForbidWord> wordList = new ArrayList<ForbidWord>();
        String[] assmbleList = StringUtils.split(assembleStr, "|");
        boolean flag = false;
        try {
            for(String assmbleDTO : assmbleList){
                String[] strDTO = StringUtils.split(assmbleDTO, ",");

                Timestamp startTimeParse = null;
                Timestamp endTimeParse = null;
                if (StringUtils.isNotBlank(strDTO[3])) {
                    startTimeParse = Timestamp.valueOf(strDTO[3]);
                }
                if (StringUtils.isNotBlank(strDTO[4])) {
                    endTimeParse = Timestamp.valueOf(strDTO[4]);
                }

                ForbidWord dto = new ForbidWord(strDTO[0], strDTO[1], level, ForbidWord.WordStatus.parseValue(Integer.valueOf(strDTO[2])), startTimeParse, endTimeParse, Integer.valueOf(strDTO[5]));
                wordList.add(dto);
            }
            flag = forbidWordService.batchAdd(wordList);
        }catch (Exception e){
            LOGGER.error(" batchAdd  insert failed  ",e);
        }
        return new Result<>(flag);
    }


}
