/**
 * 
 */
package com.kupai.gateway.route.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.kupai.gateway.common.model.SourceConfig;
import com.kupai.gateway.route.dao.SourceConfigDao;

/**
 * @author zhouqisheng
 * 2017年4月10日
 */
@Repository
public class SourceConfigDaoImpl implements SourceConfigDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    private RowMapper<SourceConfig> rowMapper = new BeanPropertyRowMapper<>(SourceConfig.class);

    /* (non-Javadoc)
     * @see com.kupai.gateway.route.dao.SourceConfigDao#getAllSourceConfig()
     */
    @Override
    public List<SourceConfig> getAllSourceConfig() {
        return jdbcTemplate.query("select * from source_config", rowMapper);
    }

}
