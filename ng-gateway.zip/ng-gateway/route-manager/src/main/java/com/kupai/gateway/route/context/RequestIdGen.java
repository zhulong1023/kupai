package com.kupai.gateway.route.context;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by zhangrui on 16/4/5.
 */
public class RequestIdGen {

    private static String address;

    private static final AtomicInteger index = new AtomicInteger(1);


    static{
        try {
            address = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    public static String getRequestId(){
        return address + " " + index.getAndIncrement();
    }
}
