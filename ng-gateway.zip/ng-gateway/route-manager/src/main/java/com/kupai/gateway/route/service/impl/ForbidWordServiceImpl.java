package com.kupai.gateway.route.service.impl;

import com.kupai.gateway.route.dao.ForbidWordDao;
import com.kupai.gateway.route.model.ForbidWord;
import com.kupai.gateway.route.service.ForbidWordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by zhulong on 2017/3/24.
 * 敏感词管理api
 */
@Service
public class ForbidWordServiceImpl implements ForbidWordService {

    @Autowired
    private ForbidWordDao forbidWordDao;


    @Override
    public boolean add(ForbidWord forbidWord) {
        return forbidWordDao.add(forbidWord);
    }

    @Override
    public boolean batchAdd(List<ForbidWord> forbidWordList) {
        return forbidWordDao.batchAdd(forbidWordList);
    }

    @Override
    public boolean updateInfor(ForbidWord word) {
        return forbidWordDao.updateInfor(word);
    }

    @Override
    public boolean delByType(String type) {
        return forbidWordDao.delByType(type);
    }

    @Override
    public List<ForbidWord> queryAll(int source) {
        return forbidWordDao.queryAll(source);
    }

    @Override
    public List<Map<String, Object>> queryForbidWords(String name, int page, int num) {
        return forbidWordDao.queryForbidWords(name,page,num);
    }

    @Override
    public long queryCountForbid(String name) {
        return forbidWordDao.queryCountForbid(name);
    }
}
