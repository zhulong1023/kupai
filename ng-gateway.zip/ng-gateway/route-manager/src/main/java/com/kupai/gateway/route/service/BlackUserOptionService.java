package com.kupai.gateway.route.service;

import java.util.Map;

/**
 * Created by Administrator on 2017/3/23.
 */
public interface BlackUserOptionService {

    /**
     * 设置全局黑名单
     *
     * @param source  系统名称，必须英文名称
     * @param uids    用户uid,多个用，隔开
     * @param status  是否进入黑名单  0 取消禁言   1 禁言
     * @param gagTime 禁言时长  单位s 默认900s 即15分钟
     * @return
     */
    boolean setBlackUser(String source, String uids, Integer status, long gagTime, String optionUser);

    /**
     * 获得是否为黑名单用户
     *
     * @param source 系统名称，必须英文名称
     * @param uid
     * @return
     */
    boolean isBlackUser(String source, String uid);

    /**
     * 分页获取黑名单
     *
     * @param source   系统英文名称
     * @param page
     * @param pageSize
     * @return
     */
    Map<String, Object> getBlackUserList(String source, int page, int pageSize);

    /**
     * 移除黑名单
     * @param source
     * @param uid
     * @param optionUser
     * @return
     */
    boolean removeBlackUser(String source, String uid, String optionUser);
}
