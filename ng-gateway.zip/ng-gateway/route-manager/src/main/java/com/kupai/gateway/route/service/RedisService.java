package com.kupai.gateway.route.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.common.contants.KeyRepertory;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.model.HistoryMessage;

import redis.clients.jedis.JedisCluster;

/**
 * Created by zhaoshengqi on 2017/3/23.
 */
@Service
public class RedisService {
    /**超时时间30天*/
    private static final int expire30Days = 30 * 24 * 3600;
    /**超时时间一天*/
    private static final int expire1Day = 1 * 24 * 3600;
    /**超时时间1小时*/
    private static final int expire1Hour = 3600;

    @Autowired
    private JedisCluster jedisCluster;

    /**
     获取消息列表
     * @param sessionId 房间ID
     * @param type 消息类型
     * @param start 开始
     * @param end 结束
     * @return
     */
    public List<HistoryMessage> getHistoryMessageList(String sessionId, long type, int start, int end){
        List<HistoryMessage> historyMessageList = new ArrayList<>();
        List<String> messageStrList = new ArrayList<>(jedisCluster.zrevrange(KeyRepertory.HISTORY_MESSAGE_LIST +type+"_"+sessionId,
                start,end));

        if(CollectionUtils.isNotEmpty(messageStrList)){
            //JSONArray.parseArray(messageList,HistoryMessage.class);
            for(int i=0;i<messageStrList.size();i++){
                HistoryMessage historyMessage = JSONObject.parseObject(messageStrList.get(i),HistoryMessage.class);
                historyMessageList.add(historyMessage);
            }
        }
        ApiLogger.info("RedisService getHistoryMessageList key="+KeyRepertory.HISTORY_MESSAGE_LIST +type+"_"+sessionId+" " +
                "result=:"+messageStrList);
        return historyMessageList;
    }

    /**
     * 添加消息到Zset
     * @param historyMessage
     * @return
     */
    public boolean addHistoryMessageToZset(HistoryMessage historyMessage){

      boolean result = jedisCluster.zadd(KeyRepertory.HISTORY_MESSAGE_LIST + historyMessage.getType()+"_"+historyMessage.getSessionId(),
                historyMessage.getCreateTime(),JSONObject.toJSONString(historyMessage)) > 0;
        ApiLogger.info("RedisService addHistoryMessageZset key="+KeyRepertory.HISTORY_MESSAGE_LIST + historyMessage.getType()+"_"+ historyMessage.getSessionId() +
                " result=:"+result);
      return result;

    }

    /**
     * 获取游标对象
     * @param key
     * @return
     */
    public String getCursor(String key){
        return jedisCluster.get(key);
    }

    /**
     * 添加游标对象
     * @param key
     * @return
     */
    public void setCursor(String key,String value){
        jedisCluster.set(key,value);
    }


    /**
     * 设置失效时间30天
     * @param key
     * @return
     */
    public boolean expire30Days(String key) {
        return jedisCluster.expire(key,expire30Days)>0;
    }
    /**
     * 设置失效时间1小时
     * @param key
     * @return
     */
    public boolean expire1Hour(String key) {
        return jedisCluster.expire(key,expire1Hour)>0;
    }
}
