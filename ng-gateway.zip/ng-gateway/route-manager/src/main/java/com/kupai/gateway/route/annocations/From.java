package com.kupai.gateway.route.annocations;

/**
 * Created by zhangrui on 16/4/5.
 */
public enum From {
    OUTER,
    INNER;
}
