package com.kupai.gateway.route.exception;

/**
 * Created by weimi on 2016/2/1.
 */
public class ErrorResultCode {
    //系统异常 10001 --- 10100
    public final static ErrorResult API_ERROR = new ErrorResult(10001, "网络环境欠佳，请稍后重试！");
    public final static ErrorResult PARAM_REQUIRED = new ErrorResult(10002, "%s 参数必传");
    public static final ErrorResult NEED_BASE_INFO = new ErrorResult(10003, "需要配置BaseInfo信息");
    public final static ErrorResult API_NOT_EXIST = new ErrorResult(10004, "接口不存在！");

    //各个不同的业务自定义范围
    //上传文件 10101 --- 10150
    public final static ErrorResult UPLOAD_ERROR = new ErrorResult(10101, "upload file error");
    public final static ErrorResult FILE_TOO_BIG_ERROR = new ErrorResult(10102, "file big than allow max size");
    public final static ErrorResult FILE_NOT_ALLOW_NULL = new ErrorResult(10103, "file not allow blank");

    //黑名单操作 10151 --- 10200
    public final static ErrorResult SET_BLACK_USER_ERROR = new ErrorResult(10151, "set black error");

    //push服务  10201 --- 10250
    public final static ErrorResult PARAM_JSON_ERROR = new ErrorResult(10201, "json resolve error");
    public final static ErrorResult PARAM_ID_ERROR = new ErrorResult(10201, "roomID和toIds必须且只能传一个");
    public final static ErrorResult PARAM_CODE_ERROR = new ErrorResult(10201, "不支持的code类型");

    //消息操作 10251 ---10300
    public final static ErrorResult NO_RESULT_FIND_ERROR = new ErrorResult(10251, "未查询到相关数据!");
    public final static ErrorResult PAGE_FORMAT_ERROR = new ErrorResult(10252, "参数错误!");

}
