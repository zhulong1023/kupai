package com.kupai.gateway.route.interceptor;

import com.kupai.gateway.route.annocations.*;
import com.kupai.gateway.route.context.RouteManagerContext;
import com.kupai.gateway.route.exception.ErrorResultCode;
import com.kupai.gateway.route.exception.RouteManagerExceptionUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import redis.clients.util.SafeEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author zqd
 * @author zhangrui
 * @date 2016/4/1
 * @time 17:10
 */
public class BaseInfoInterceptor extends HandlerInterceptorAdapter {

    //内外网访问
    private final String FROM = "x-matrix-from";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 设置response请求唯一标签
        response.setHeader("x-matrix-host", RouteManagerContext.getRouteManagerContext().getUniqueRequestId());
        RouteManagerContext.getRouteManagerContext().setOriginRequest(request);
        RouteManagerContext.getRouteManagerContext().setOriginResponse(response);
        if (handler instanceof HandlerMethod) {
            HandlerMethod hm = (HandlerMethod) handler;
            BaseInfo baseInfo = hm.getMethodAnnotation(BaseInfo.class);
            if (baseInfo == null) {
                throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.NEED_BASE_INFO);
            }
            AuthType authType = baseInfo.needAuth();
            //app调用需要验证有效性
            if (authType == AuthType.REQUIRED) {

            } else if (authType == AuthType.OPTION) { //不需要认证的接口，如feed流，还有php接口
                //不做任何操作
            }

            //公开访问接口，还是内部访问接口【php】
            ApiStatus apiStatus = baseInfo.status();
            if (apiStatus == ApiStatus.INTERNAL) {
                String from = request.getHeader(FROM);
                if (!From.INNER.name().equals(from)) {
                    try (PrintWriter pw = response.getWriter()) {
                        response.setContentType("application/json");
                        pw.write(ErrorResultCode.API_NOT_EXIST.toString());
                    }
                    return false;
                }
            } else if (apiStatus == ApiStatus.PUBLIC) {
                //不做任何操作
            }

            //是否需要验证签名
            SignType signType = baseInfo.needSign();
            if (signType == SignType.NEED) {
                //
            }
        }
        return true;

    }

    /**
     * 获取请求的参数的map
     *
     * @param request
     * @return
     */
    private Map<String, Object> getParameterMap(HttpServletRequest request) {
        Map properties = request.getParameterMap();
        // 返回值Map
        Map<String, Object> returnMap = new HashMap<String, Object>();
        if (properties != null && properties.size() > 0) {
            Iterator entries = properties.entrySet().iterator();
            Map.Entry entry;
            String name = "";
            String value = "";
            while (entries.hasNext()) {
                entry = (Map.Entry) entries.next();
                name = (String) entry.getKey();
                Object valueObj = entry.getValue();
                if (null == valueObj) {
                    value = "";
                } else if (valueObj instanceof String[]) {
                    String[] values = (String[]) valueObj;
                    for (int i = 0; i < values.length; i++) {
                        value = values[i] + ",";
                    }
                    value = value.substring(0, value.length() - 1);
                } else {
                    value = valueObj.toString();
                }
                //IOS在传递Base64数据时，如果含有+号，在网络传输时被替换成了" "
                value = value.replace(" ", "+");
                returnMap.put(name, SafeEncoder.encode(value));
            }
        }
        return returnMap;
    }
}

