package com.kupai.gateway.route.service.impl;

import com.kupai.gateway.common.util.TimeUtil;
import com.kupai.gateway.route.cache.black.BlackUserOptionStorage;
import com.kupai.gateway.route.dao.BlackUserDao;
import com.kupai.gateway.route.exception.ErrorResultCode;
import com.kupai.gateway.route.exception.RouteManagerExceptionUtils;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.model.BlackUserDO;
import com.kupai.gateway.route.service.BlackUserOptionService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/3/23.
 */
@Service
public class BlackUserOptionServiceImpl implements BlackUserOptionService {

    @Autowired
    private BlackUserOptionStorage blackUserOptionStorage;

    @Autowired
    private BlackUserDao blackUserDao;

    /**
     * 设置全局黑名单
     *
     * @param source  系统名称，必须英文名称
     * @param uids    用户uid,多个用，隔开
     * @param status  是否进入黑名单 0 取消禁言   1 禁言
     * @param gagTime 禁言时长  单位s 默认900s 即15分钟
     * @return
     */
    @Override
    public boolean setBlackUser(String source, String uids, Integer status, long gagTime, String optionUser) {
        boolean flag = true;
        String[] tuids = uids.split(",");
        //刷新缓存，防止缓存中没有数据
        this.validateRedisIncludeAllBlackUser(source);
        for (String uid : tuids) {
            try {
                if (status == 1) {
                    //计算禁言结束时间
                    Long invalidTime = 0L;
                    if (gagTime != BlackUserOptionStorage.FOREVER_GAG) {
                        invalidTime = TimeUtil.getCurrentSeconds() + gagTime;
                    } else {
                        invalidTime = BlackUserOptionStorage.FOREVER_GAG;
                    }

                    //存入数据库中
                    BlackUserDO blackUserDO = new BlackUserDO(source, uid, gagTime, invalidTime, optionUser);
                    //保存进数据库
                    if (blackUserDao.saveBlackUser(blackUserDO)) {
                        blackUserOptionStorage.saveBlackToGlobalList(source, uid, invalidTime);
                    }
                } else {
                    this.removeBlackUser(source, uid, optionUser);
                }
            } catch (Exception e) {
                ApiLogger.error(String.format("setBlackUser is error, source %s, uids %s, status %s, gagTime %s, optionUser %s", source, uids, status, gagTime, optionUser), e);
                throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.SET_BLACK_USER_ERROR);
            }
        }
        return flag;
    }


    /**
     * 获得是否为黑名单用户
     *
     * @param source 系统名称，必须英文名称
     * @param uid
     * @return
     */
    @Override
    public boolean isBlackUser(String source, String uid) {
        return blackUserOptionStorage.isBlackUser(source, uid);
    }

    /**
     * 分页获取黑名单
     *
     * @param source   系统英文名称
     * @param page
     * @param pageSize
     * @return
     */
    @Override
    public Map<String, Object> getBlackUserList(String source, int page, int pageSize) {
        Map<String, Object> result = new HashMap<>(2);
        List<BlackUserDO> blackUserDOList = blackUserDao.listBlackUser(source, page, pageSize);
        if (CollectionUtils.isNotEmpty(blackUserDOList)) {
            for (int i = 0; i < blackUserDOList.size(); i++) {
                BlackUserDO blackUserDO = blackUserDOList.get(i);
                if (blackUserDO.getInvalidTime() != BlackUserOptionStorage.FOREVER_GAG) {
                    long secondTime = blackUserDO.getInvalidTime() - (System.currentTimeMillis() / 1000);
                    if (secondTime <= 0) {
                        //删除过期的黑名单
                        this.removeBlackUser(source, blackUserDO.getUid(), "system");
                        //无效
                        blackUserDO.setYn(0);
                    }
                }
            }
        }
        result.put("list", blackUserDOList);
        result.put("totalCount", blackUserDao.countBlackUser(source));
        return result;
    }

    /**
     * 移除黑名单
     *
     * @param source
     * @param uid
     * @param optionUser
     * @return
     */
    @Override
    public boolean removeBlackUser(String source, String uid, String optionUser) {
        if (blackUserDao.removeBlackUser(source, uid, optionUser)) {
            return blackUserOptionStorage.removeBlackFromGlobalList(source, uid, optionUser);
        }
        return false;
    }


    /**
     * 验证redis中是否有数据，如果没有，则查询所有的数据放入到redis中
     *
     * @param source
     * @return
     */
    private void validateRedisIncludeAllBlackUser(String source) {
        long startTime = System.currentTimeMillis();
        Map<String, String> allBlackUserMap = blackUserOptionStorage.getAllBlackUserMap(source);
        if (null == allBlackUserMap || allBlackUserMap.size() == 0) {
            //查询所有的黑名单，放入到redis中
            Map<String, Object> map = this.getBlackUserList(source, 1, Integer.MAX_VALUE);
            if (null != map && map.size() > 0) {
                @SuppressWarnings("unchecked")
                List<BlackUserDO> blackUserDOList = (List<BlackUserDO>) map.get("list");
                if (CollectionUtils.isNotEmpty(blackUserDOList)) {
                    for (int i = 0; i < blackUserDOList.size(); i++) {
                        BlackUserDO blackUserDO = blackUserDOList.get(i);
                        //有效才放入缓存
                        if (blackUserDO.getYn() == 1) {
                            blackUserOptionStorage.saveBlackToGlobalList(source, blackUserDO.getUid(), blackUserDO.getInvalidTime());
                        }
                    }
                }
            }
        }
        ApiLogger.info("load info to redis,use " + (System.currentTimeMillis() - startTime) + "ms");
    }
}
