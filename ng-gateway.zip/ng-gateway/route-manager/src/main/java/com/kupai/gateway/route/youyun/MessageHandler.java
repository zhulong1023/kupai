package com.kupai.gateway.route.youyun;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ioyouyun.wchat.protocol.MetaMessageType;
import com.ioyouyun.wchat.protocol.Weimi;
import com.ioyouyun.wchat.protocol.WeimiSort;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.data.Command;
import com.kupai.gateway.common.data.DataMeta;
import com.kupai.gateway.common.data.Text;
import com.kupai.gateway.common.data.enumpac.ChatTypeEnum;
import com.kupai.gateway.common.data.enumpac.Source;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.ResponseIdGen;
import com.kupai.gateway.route.handler.ChatTextProcessHandler;
import com.kupai.gateway.route.service.MessageDispatchService;
import com.kupai.gateway.route.service.MonitorService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.Objects;

import static com.kupai.gateway.common.contants.Constants.SOURCE;

/**
 * Date: 16/11/12 Time: 下午4:21
 *
 * @author lintc
 */
@Service("messageHandler")
public class MessageHandler implements PacketHandler.PacketProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(MessageHandler.class);
    private static Logger messageLogger = LoggerFactory.getLogger("message");

    public static final String RM_SOURCE = "rm";
    public static final String YY_SOURCE = "youyun";

    @Autowired
    private MessageDispatchService messageDispatchService;

    @Autowired
    private ChatTextProcessHandler chatTextProcessHandler;

    @Autowired
    private MonitorService monitorService;

    @Override
    public void process(Weimi.WeimiPacket packet) {
        int sort = packet.getSort();
        switch (sort) {
        case WeimiSort.heartbeat:
            LOGGER.debug("heartbeat response from server");
            break;
        case WeimiSort.notice:
            TextMessage message = new TextMessage();
            if (message.parse(packet)) {
                handle(message);
            }
            break;
        default:
            break;
        }
    }

    @Override
    public void onError() {
        LOGGER.error("receive error message from server");
    }

    public void handle(TextMessage message) {
        MetaMessageType messageType = message.type;
        boolean bNeedPush = false;
        // 解析message中的padding字节数组，得到paddingText
        String paddingText = this.getPaddingText(message.padding);
        message.paddingText = paddingText;
        if (MetaMessageType.text == messageType) {
            bNeedPush = true;
            // 过滤掉出价信息(出价100元,赚取0.5元) ext type == 4
            if (null != paddingText) {
                try {
                    JSONObject extJsonObject = JSON.parseObject(paddingText);
                    // 当扩展信息中type == 4时，过滤该消息，不进行转发
                    if (extJsonObject.getIntValue("type") == MessageExtType.sendprice_text.getCode()) {
                        bNeedPush = false;
                    }
                } catch (Exception ex) {
                    LOGGER.warn(String.format("handle invalid json format, ext=%s", paddingText));
                }
            }
        } else if (MetaMessageType.textext == messageType) {
            bNeedPush = true;
        } else if (MetaMessageType.mixed == messageType) {
            bNeedPush = true;
        }
        if (bNeedPush) {
            doConcretePush(message);
        }
    }

    /**
     * 发送im消息到客户端
     *
     * @param message
     */
    private void doConcretePush(TextMessage message) {
        monitorService.incrementImMessage();
        String roomId = message.touid;
        String fromUid = message.fromuid;
        String paddingText = message.paddingText;
        String decodeText;
        try {
            decodeText = java.net.URLDecoder.decode(message.text, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            LOGGER.error(String.format("url decoder text failed, message.text=%s", message.text));
            decodeText = message.text;
        }

        messageLogger.info(String.format(
                "[IM-Server-Message] receive message from IM server. fromUid=%s, roomId=%s,text=%s, extText=%s",
                fromUid, roomId, decodeText, paddingText));

        if (StringUtils.isBlank(roomId)) {
            LOGGER.warn(String.format("invalid room_id %s", roomId));
            return;
        }
        // 构建评论消息JSON串
        JSONObject extJsonObject = null;
        // 将padding(即扩展信息)包装在body里面,作为其一个ext属性
        if (null != paddingText) {
            try {
                extJsonObject = JSON.parseObject(paddingText);
            } catch (Exception ex) {
                LOGGER.warn(String.format("invalid json format, ext=%s", paddingText));
            }
        } else {
            extJsonObject = new JSONObject();
        }

        if (null != extJsonObject) {
            String source = extJsonObject.getString(SOURCE);
            // 判断消息的根本来源是rm还是null，如果是rm，说明是从rm传递到yy的消息，则不需要再进行处理
            if (StringUtils.isNotEmpty(source) && Objects.equals(source, RM_SOURCE)) {
                return;
            }
        }
        // 放上
        extJsonObject.put(SOURCE, YY_SOURCE);

        // 判断是否是进出房间消息
        if (message.type == MetaMessageType.mixed) {
            String action = extJsonObject.getString("operation");
            // 确认是否是进出房间消息
            if (Objects.equals(action, "enter") || Objects.equals(action, "exit")) {
            } else {
                LOGGER.warn(String.format("invalid mixed action %s, room_id %s", action, roomId));
                return;
            }
            // 谁进入或者退出房间:
            fromUid = extJsonObject.getString("uid");

            // 组装进出房间消息
            Command command = new Command();
            command.setContent("{roomId:" + roomId + "}");

            DataMeta dataMeta = new DataMeta();
            dataMeta.setEvent(action);
            dataMeta.setExt(extJsonObject);
            dataMeta.setFrom(Long.valueOf(fromUid));
            dataMeta.setTo(Long.valueOf(roomId));
            dataMeta.setCode(ResponseCode.INOUT_ROOM_OK);

            command.setMeta(dataMeta);

            JGroupMessage jGroupMessage = new JGroupMessage();
            jGroupMessage.setCode(RequestCode.ROOM);
            jGroupMessage.setFrom(Long.valueOf(fromUid));
            jGroupMessage.setRequestId(ResponseIdGen.getResponseId());
            jGroupMessage.setOneWay(true);
            jGroupMessage.setData(command);
            jGroupMessage.setRoomId(Long.valueOf(roomId));
            jGroupMessage.setSourceAdd(null);
            jGroupMessage.setSource(Source.KUPAI.getValue());
            jGroupMessage.setSendType(JGroupMessage.SendType.MULTI.getValue());
            messageDispatchService.forward(jGroupMessage);
        } else {
            // 组装text
            Text text = new Text();
            text.setContent(decodeText);

            DataMeta dataMeta = new DataMeta();
            dataMeta.setChatType(ChatTypeEnum.ROOM.getType());
            dataMeta.setCode(RequestCode.MSG_TEXT);
            dataMeta.setFrom(Long.valueOf(fromUid));
            dataMeta.setTo(Long.valueOf(roomId));
            dataMeta.setEvent("add");
            dataMeta.setChatType(ChatTypeEnum.ROOM.getType());
            dataMeta.setExt(extJsonObject);

            text.setMeta(dataMeta);

            // 调用chatText处理类
            JGroupMessage jGroupMessage = new JGroupMessage();
            jGroupMessage.setCode(RequestCode.MSG_TEXT);
            jGroupMessage.setFrom(Long.valueOf(fromUid));
            jGroupMessage.setRequestId(ResponseIdGen.getResponseId());
            jGroupMessage.setOneWay(true);
            jGroupMessage.setData(text);
            jGroupMessage.setRoomId(Long.valueOf(roomId));
            jGroupMessage.setSourceAdd(null);
            jGroupMessage.setSource(Source.KUPAI.getValue());
            chatTextProcessHandler.doProcess(jGroupMessage);
        }
    }

    /**
     * 获得padding的String对象
     *
     * @param padding
     * @return
     */
    private String getPaddingText(byte[] padding) {
        String paddingText = null;
        if (null != padding && padding.length > 0) {
            paddingText = new String(padding);
            try {
                paddingText = java.net.URLDecoder.decode(paddingText, "UTF-8");
            } catch (Exception ex) {
                LOGGER.error(String.format("url decode failed, paddingText=%s", paddingText));
            }
        }
        return paddingText;
    }
}
