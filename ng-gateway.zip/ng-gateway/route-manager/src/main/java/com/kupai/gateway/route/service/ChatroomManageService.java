package com.kupai.gateway.route.service;

import com.kupai.gateway.route.cache.RoomStorage;
import com.kupai.gateway.route.dao.ChatroomDao;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.model.Chatroom;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

/**
 * Created by zhulong on 2017/3/21. 房间管理
 */
@Service
public class ChatroomManageService {

    @Resource
    private ChatroomDao chatroomDao;
    @Resource
    private RoomStorage roomStorage;

    /**
     * @ Author: zhulong @ Description: 创建房间 @ param: @ Date: 18:45 2017/3/21
     */
    public long createRoom(String source, long createid) {
        ApiLogger.info("ChatroomManageService-->createRoom for source:" + source);
        Chatroom room = new Chatroom();
        //room.setId(TimeUtil.getCurrentSeconds()); // todo uuid生成
        room.setSource(source);
        room.setCounter(0);
        room.setCreateId(createid);
        room.setCreateTime(new Date());
        long roomid = chatroomDao.saveChatroom(room);
        return roomid;
    }

    /**
     * 根据id查询房间
     * @param id
     * @return
     */
    public Chatroom findChatroomById(Long id,Integer source){
        Chatroom room = chatroomDao.findChatroomById(id,source);
        return room;
    }

    /**
     * 查询房间在线用户id
     * 
     * @param source
     * @param roomId
     * @return
     */
    public List<Long> getChatroomUid(int source, long roomId) {
        Set<String> uidSet = roomStorage.listRoomSession(roomId);
        if (uidSet == null || uidSet.size() == 0) {
            return Collections.emptyList();
        }

        List<Long> uidList = new ArrayList<>(uidSet.size());
        for (String uid : uidSet) {
            uidList.add(Long.parseLong(uid));
        }
        return uidList;
    }

}
