package com.kupai.gateway.route.service.impl;

import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kupai.gateway.common.util.TimeUtil;
import com.kupai.gateway.route.cache.black.BlackUserOptionStorage;
import com.kupai.gateway.route.cache.black.BlackWhiteUserOptionStorage;
import com.kupai.gateway.route.log.ApiLogger;
import com.kupai.gateway.route.service.BlackWhiteUserOptionService;

/**
 * Created by Administrator on 2017/3/29.
 */
@Service
public class BlackWhiteUserOptionServiceImpl implements BlackWhiteUserOptionService {

    @Autowired
    private BlackWhiteUserOptionStorage blackWhiteUserOptionStorage;


    /**
     * 维护黑白名单用户
     *
     * @param source 系统
     * @param org    机构
     * @param uids   用户uid列表
     * @param type   类型 1 黑名单  2 白名单
     * @param status 0 取消禁言  1 禁言
     * @return
     */
    @Override
    public boolean setBlackWhiteUser(String source, String org, String uids, Integer type, Integer status, Long gagTime) {
        if (status == 1) {
            long count = blackWhiteUserOptionStorage.saveBlackWhiteUser(source, org, uids, type, gagTime);
            ApiLogger.info(String.format("save black white user, source %s, org %s, uids %s, type %s, count %s", source, org, uids, type, count));
        } else if (status == 0) {
            long count = blackWhiteUserOptionStorage.removeBlackWhiteUser(source, org, uids, type);
            ApiLogger.info(String.format("remove black white user, source %s, org %s, uids %s, type %s, count %s", source, org, uids, type, count));
        }
        return true;
    }

    /**
     * 维护机构对应的黑白名单房间list
     *
     * @param source 系统
     * @param org    机构
     * @param rooms  房间列表
     * @param type   类型 1 黑名单  2 白名单
     * @param status 0 取消禁言  1 禁言
     * @return
     */
    @Override
    public boolean setBlackWhiteRoom(String source, String org, String rooms, Integer type, Integer status) {
        if (status == 1) {
            boolean flag = blackWhiteUserOptionStorage.saveBlackWhiteRoom(source, org, rooms, type);
            ApiLogger.info(String.format("save black white room, source %s, org %s, rooms %s, type %s, flag %s", source, org, rooms, type, flag));
        } else if (status == 0) {
            boolean flag = blackWhiteUserOptionStorage.removeBlackWhiteRoom(source, org, rooms, type);
            ApiLogger.info(String.format("remove black white room, source %s, org %s, rooms %s, type %s, flag %s", source, org, rooms, type, flag));
        }
        return true;
    }


    /**
     * 获得黑白名单列表
     *
     * @param source 系统
     * @param room   房间列表
     * @param type   类型 1 黑名单  2 白名单
     * @return
     */
    @Override
    public Map<String, String> getUserList(String source, String room, Integer type) {
        return blackWhiteUserOptionStorage.getUserList(source, room, type);
    }

    /**
     * 获得黑白名单列表
     *
     * @param source 系统
     * @param room   房间列表
     * @param type   类型 1 黑名单  2 白名单
     * @return
     */
    @Override
    public boolean isBlackUser(String uid, String source, String room, Integer type) {
        Map<String, String> userMap = this.getUserList(source, room, type);
        if(userMap==null){
            return false;
        }
        for(Map.Entry<String, String> map : userMap.entrySet()) {
            String key = map.getKey();
            String inviteTime = map.getValue();
            if (Objects.equals(key, uid) && (Long.valueOf(inviteTime) > TimeUtil.getCurrentSeconds() || Long.valueOf(inviteTime) == BlackUserOptionStorage.FOREVER_GAG)) {
                return true;
            }
        }
        return false;
    }
}
