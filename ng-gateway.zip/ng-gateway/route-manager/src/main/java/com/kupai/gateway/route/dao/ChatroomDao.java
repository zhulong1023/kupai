package com.kupai.gateway.route.dao;

import com.kupai.gateway.route.model.Chatroom;

/**
 * Created by admin on 2017/3/21.
 * 房间管理接口
 */
public interface ChatroomDao {

    long saveChatroom(Chatroom room);

    Chatroom findChatroomById(Long id,Integer source);
}
