package com.kupai.gateway.route.constant;

/**
 * 存放黑名单key前缀
 * Created by Administrator on 2017/3/23.
 */
public class BlackRedisKeyPre {
    //黑名单key前缀
    public static final String BLACK_USER_LIST_GLOBAL_PRE = "black_user_list_global_";

    //临时禁言黑名单key前缀
    public static final String BLACK_USER_INTERIM_LIST_PRE = "black_user_interim_";

    //面对机构禁言黑名单key前缀
    public static final String BLACK_WHITE_ORG_USER_LIST_PRE = "black_white_org_user_list_";
    public static final String BLACK_WHITE_ORG_ROOM_LIST_PRE = "black_white_org_room_list_";
}
