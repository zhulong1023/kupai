package com.kupai.gateway.route.dao.impl;

import com.kupai.gateway.route.dao.BlackUserDao;
import com.kupai.gateway.route.model.BlackUserDO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/3/23.
 */
@Component
public class BlackUserDaoImpl implements BlackUserDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    //插入黑名单
    private static final String SAVE_BLACK_USER_SQL = "INSERT INTO black_user (source, uid, gag_time, invalid_time, create_user, create_time, modify_time, modify_user) VALUES (?,?,?,?,?, NOW(), NOW(),?) on duplicate key update gag_time=?,invalid_time=?,create_user=?,create_time=NOW(), modify_time=NOW(), modify_user=?";
    //删除黑名单
    private static final String REMOVE_BLACK_USER_BY_SYSTEM_UID = "UPDATE black_user SET yn = 0, modify_time = NOW(), modify_user = ? WHERE source = ? AND uid = ?";
    //查询黑名单列表
    private static final String LIST_BLACK_USER_BY_SYSTEM = "SELECT source, uid, gag_time, invalid_time, create_user, create_time, modify_time, modify_user, yn FROM black_user WHERE source = ? ";
    //查询黑名单数量
    private static final String COUNT_BLACK_USER_BY_SYSTEM = "SELECT COUNT(*) FROM black_user WHERE source = ?";


    /**
     * 保存黑名单
     *
     * @param blackUserDO
     * @return
     */
    @Override
    public boolean saveBlackUser(BlackUserDO blackUserDO) {
        return jdbcTemplate.update(SAVE_BLACK_USER_SQL, new Object[]{blackUserDO.getSource(), blackUserDO.getUid(), blackUserDO.getGagTime(),
                blackUserDO.getInvalidTime(), blackUserDO.getCreateUser(), blackUserDO.getCreateUser(),blackUserDO.getGagTime(),
                blackUserDO.getInvalidTime(), blackUserDO.getCreateUser(), blackUserDO.getCreateUser()}) > 0;
    }

    /**
     * 删除黑名单
     *
     * @param source 系统英文名
     * @param uid    uid
     * @return
     */
    @Override
    public boolean removeBlackUser(String source, String uid, String modifyUser) {
        return jdbcTemplate.update(REMOVE_BLACK_USER_BY_SYSTEM_UID, new Object[]{modifyUser, source, uid}) > 0;
    }

    /**
     * 支持分页
     *
     * @param source   系统英文名
     * @param page     第几页
     * @param pageSize 每页数据大小
     * @return
     */
    @Override
    public List<BlackUserDO> listBlackUser(String source, int page, int pageSize) {
        StringBuilder sb = new StringBuilder(LIST_BLACK_USER_BY_SYSTEM);
        List<Object> params = new ArrayList<>();
        sb.append(" limit ?,?");
        params.add(source);
        params.add((page - 1) * pageSize);
        params.add(pageSize);
        return jdbcTemplate.query(sb.toString(), params.toArray(), new RowMapper<BlackUserDO>() {
            @Override
            public BlackUserDO mapRow(ResultSet resultSet, int i) throws SQLException {
                BlackUserDO blackUserDO = extractBlackUserDO(resultSet);
                return blackUserDO;
            }
        });
    }

    /**
     * 查询黑名单数量
     *
     * @param source   系统英文名
     * @return
     */
    @Override
    public Integer countBlackUser(String source) {
        return jdbcTemplate.query(COUNT_BLACK_USER_BY_SYSTEM, new Object[]{source}, new ResultSetExtractor<Integer>() {
            @Override
            public Integer extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                if (resultSet.next()) {
                    return resultSet.getInt(1);
                }
                return 0;
            }
        });
    }

    /**
     * 组装对象
     *
     * @param resultSet
     * @return
     */
    private BlackUserDO extractBlackUserDO(ResultSet resultSet) throws SQLException {
        BlackUserDO blackUserDO = new BlackUserDO();
        blackUserDO.setSource(resultSet.getString("source"));
        blackUserDO.setUid(resultSet.getString("uid"));
        blackUserDO.setGagTime(resultSet.getLong("gag_time"));
        blackUserDO.setInvalidTime(resultSet.getLong("invalid_time"));
        blackUserDO.setCreateUser(resultSet.getString("create_user"));
        blackUserDO.setCreateTime(resultSet.getDate("create_time"));
        blackUserDO.setModifyTime(resultSet.getDate("modify_time"));
        blackUserDO.setModifyUser(resultSet.getString("modify_user"));
        blackUserDO.setYn(resultSet.getInt("yn"));
        return blackUserDO;
    }
}
