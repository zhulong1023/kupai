package com.kupai.gateway.route.filter;

import com.kupai.gateway.common.annotations.RegistrantConfiguration;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.data.Text;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.JGroupsNode;
import com.kupai.gateway.route.model.ForbidModule;
import com.kupai.gateway.route.service.ForbidWordHandleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhulong on 2017/3/27. 敏感词验证
 */
@Component
@RegistrantConfiguration(code = {RequestCode.MSG_TEXT}, order = 3)
public class ForbidWordValidateFilter extends AbstractMessageFilter {

    @Autowired
    private ForbidWordHandleService forbidWordHandleService;

    /**
     * 处理敏感词
     *
     * @param jgroupsNode
     * @param jGroupMessage
     * @return
     */
    @Override
    public boolean preHandler(JGroupsNode jgroupsNode, JGroupMessage jGroupMessage) {
        // 只针对于聊天文本消息进行敏感词验证
        if (jGroupMessage.getCode() == RequestCode.MSG_TEXT) {
            // 本handler处理该消息
            Text text = (Text) jGroupMessage.getData();
            ForbidModule.Result result = forbidWordHandleService.checkForbidWords(String.valueOf(text.getContent()), jGroupMessage.getSource().intValue());
            if (result.getFlag()) {
                List<Long> toUid = new ArrayList<>(1);
                toUid.add(jGroupMessage.getFrom());
                jGroupMessage.setCode(ResponseCode.MSG_TEXT_FORBIDWORD);//消息含有敏感词
                jGroupMessage.setToUid(toUid);
                jGroupMessage.setSendType(JGroupMessage.SendType.P2P.getValue());
                jGroupMessage.setOneWay(true);
                jgroupsNode.sendMessage(jGroupMessage.getSourceAdd(), jGroupMessage);
                return false;
            }
            text.setContent(result.getText());
            jGroupMessage.setData(text);
        }
        return true;
    }
}
