package com.kupai.gateway.route.service.third;

import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2017/3/30.
 */
@Service
public class OpenPlatformService {
}
