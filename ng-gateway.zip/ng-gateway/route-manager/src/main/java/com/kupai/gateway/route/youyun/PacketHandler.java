package com.kupai.gateway.route.youyun;

import com.ioyouyun.wchat.protocol.Weimi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class PacketHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(PacketHandler.class);
    private final static byte protocolVersion = 2;// 协议版本号
    private final static byte command = 0;
    private final static int versionLength = 1;// version的长度
    private final static int commandLength = 1;// command的长度
    private final static int lengthLength = 4;// bodyLength的长度
    private final static int headerLength = versionLength + commandLength
            + lengthLength;// 协议头部长度

    private int readBufSize = 64 * 1024;
    private ByteBuffer lastDataBuffer = null;

    public interface PacketProcessor {
        void process(Weimi.WeimiPacket meyouPacket);

        void onError();
    }

    private PacketProcessor responseProcessor;
    ByteBuffer receiveByteBuffer = ByteBuffer.allocate(readBufSize);

    public PacketHandler(PacketProcessor processor) {
        responseProcessor = processor;
    }

    static public ByteBuffer buildPacket(byte[] entity) {
        final ByteBuffer bb = ByteBuffer.allocate(headerLength + entity.length);
        bb.put(protocolVersion);
        bb.put(command);
        bb.putInt(entity.length);
        bb.put(entity);
        bb.flip();
        return bb;
    }

    public boolean read(SocketChannel socketChannel) {
        try {
            receiveByteBuffer.clear();
            if (socketChannel.read(receiveByteBuffer) > 0) {
                receiveByteBuffer.flip();
                decode(receiveByteBuffer);
            }
        } catch (Exception e) {
            LOGGER.error("read packet error",e);
            fireError();
            return false;
        }
        return true;
    }

    public void fireError() {
        responseProcessor.onError();
    }

    private void decode(ByteBuffer dataBuffer) {
        if (lastDataBuffer != null) {
            dataBuffer = mergeBuffer(lastDataBuffer, dataBuffer);
            lastDataBuffer = null;
        }

        for (; ; ) {
            int oldPosition = dataBuffer.position();
            boolean result = decodeBuffer(dataBuffer);
            if (result) {
                if (!dataBuffer.hasRemaining())
                    break;
                if (dataBuffer.position() == oldPosition)
                    break;
            } else
                break;
        }

        if (dataBuffer.hasRemaining()) {
            lastDataBuffer = copyBuffer(dataBuffer);
        }
    }

    private ByteBuffer mergeBuffer(ByteBuffer buffer1, ByteBuffer buffer2) {
        ByteBuffer newBuffer = ByteBuffer.allocate(buffer1.remaining()
                + buffer2.remaining());
        newBuffer.put(buffer1);
        newBuffer.put(buffer2);
        newBuffer.flip();
        return newBuffer;
    }

    public ByteBuffer copyBuffer(ByteBuffer dataBuffer) {
        ByteBuffer newBuffer = ByteBuffer.allocate(dataBuffer.remaining());
        newBuffer.put(dataBuffer);
        newBuffer.flip();
        return newBuffer;
    }

    private boolean decodeBuffer(ByteBuffer buffer) {
        int position = buffer.position();
        int length = buffer.remaining();
        if (length < headerLength)
            return false;

        int version = buffer.get();
        //不能忽略次字节
        int flag = buffer.get();
        int contentLength = buffer.getInt();

        if (version != protocolVersion || contentLength >= 10 * 1024 * 1024)
            return false;

        if (length >= headerLength + contentLength) {
            try {
                byte[] contentArray = new byte[contentLength];
                buffer.get(contentArray);
                Weimi.WeimiPacket meyouPacket = Weimi.WeimiPacket.parseFrom(contentArray);
                responseProcessor.process(meyouPacket);
            } catch (Exception e) {
                LOGGER.error("processor error ", e);
            }
            return true;

        }
        buffer.position(position);
        return false;
    }
}

