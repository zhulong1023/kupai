package com.kupai.gateway.route.annocations;

/**
 * Created by zhangrui on 16/3/14.
 */
public enum SignType {
    NEED,
    NOTNEED;
}