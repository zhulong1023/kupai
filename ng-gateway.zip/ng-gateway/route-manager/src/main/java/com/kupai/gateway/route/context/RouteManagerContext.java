package com.kupai.gateway.route.context;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.Serializable;

/**
 * @author zhangrui
 */
@SuppressWarnings("serial")
public class RouteManagerContext implements Serializable {

    private String response;

    private String uniqueRequestId;

    //用于统计请求的时间
    private long startTime;

    //避免二次打印requestlog
    private boolean hasPrintRequestLog = false;
    //是否打印返回结果
    private boolean printResponse = true;

    private HttpServletRequest originRequest;
    private HttpServletResponse originResponse;

    //记录请求的用户uid
    private String uid = "";

    public static RouteManagerContext getRouteManagerContext() {
        RouteManagerContext routeManagerContext = ThreadLocalContext.getInstance().get();
        return routeManagerContext;
    }

    public static void clear(){
        ThreadLocalContext.getInstance().remove();
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getUniqueRequestId() {
        return uniqueRequestId;
    }

    public void setUniqueRequestId(String uniqueRequestId) {
        this.uniqueRequestId = uniqueRequestId;
    }

    public boolean isHasPrintRequestLog() {
        return hasPrintRequestLog;
    }

    public void setHasPrintRequestLog(boolean hasPrintRequestLog) {
        this.hasPrintRequestLog = hasPrintRequestLog;
    }

    public boolean isPrintResponse() {
		return printResponse;
	}

	public void setPrintResponse(boolean printResponse) {
		this.printResponse = printResponse;
	}

	public HttpServletRequest getOriginRequest() {
        return originRequest;
    }

    public void setOriginRequest(HttpServletRequest originRequest) {
        this.originRequest = originRequest;
    }

    public HttpServletResponse getOriginResponse() {
        return originResponse;
    }

    public void setOriginResponse(HttpServletResponse originResponse) {
        this.originResponse = originResponse;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
