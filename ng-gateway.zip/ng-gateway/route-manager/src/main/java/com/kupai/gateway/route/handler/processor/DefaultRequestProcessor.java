package com.kupai.gateway.route.handler.processor;

import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.route.handler.DefaultProcessHandler;
import com.kupai.gateway.route.handler.ProcessHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/3/27.
 */
@Service
public class DefaultRequestProcessor implements RequestProcessor {

    private static final Map<Integer, ProcessHandler> processHandlers = new HashMap<>();

    @Autowired
    private DefaultProcessHandler defaultProcessHandler;

    /**
     * 处理从rm过来的请求
     *
     * @param jGroupMessage
     */
    @Override
    public void processRequest(JGroupMessage jGroupMessage) {
        if (null != jGroupMessage && null != jGroupMessage.getData()) {
            //获得要处理的handler
            ProcessHandler processHandler = processHandlers.get(jGroupMessage.getCode());
            if (null == processHandler) {
                processHandler = defaultProcessHandler;
            }
            //使用相应的处理器处理请求
            processHandler.doProcess(jGroupMessage);
        }
    }

    /**
     * 注册消息处理器
     *
     * @param requestCode    请求码
     * @param processHandler 请求码对应的处理器
     */
    public final static void registerProcessHandler(int requestCode, ProcessHandler processHandler) {
        if (null == processHandler) {
            return;
        }
        processHandlers.put(requestCode, processHandler);
    }
}
