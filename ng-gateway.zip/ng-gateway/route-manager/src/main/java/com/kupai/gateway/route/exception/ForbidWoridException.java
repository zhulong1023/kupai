/**
 *
 */
package com.kupai.gateway.route.exception;

import com.kupai.gateway.route.util.ExcepFactor;
import org.apache.commons.lang.StringUtils;

import java.util.Set;

/**
 * @author jolestar
 */
public class ForbidWoridException extends MatrixException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public ForbidWoridException(Set<String> forbidWords) {
        super(ExcepFactor.E_FORBIDWORD, new Object[]{StringUtils.join(forbidWords, ",")});
    }

    public ForbidWoridException(String forbidWords) {
        super(ExcepFactor.E_FORBIDWORD, new Object[]{forbidWords});
    }

}