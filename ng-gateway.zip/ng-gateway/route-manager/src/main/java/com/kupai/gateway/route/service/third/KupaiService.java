package com.kupai.gateway.route.service.third;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.kupai.gateway.common.data.Bid;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.retrofit.ResponseProcessor;
import com.kupai.gateway.common.retrofit.ServiceGenerator;
import com.kupai.gateway.route.service.httpClient.KupaiClient;
import com.kupai.gateway.route.util.Constants;

/**
 * Created by Administrator on 2017/2/27.
 */
@Service("kupaiService")
public class KupaiService {
    private static Logger LOGGER = LoggerFactory.getLogger(KupaiService.class);

    @Value("${kupai.domain}")
    private String kupaiDomain;

    @Value("${bid.api.sendPrice.url}")
    private String sendPriceUrl;

    private KupaiClient kupaiClient;

    /**
     * 初始化http接口实例
     */
    @PostConstruct
    public void init() {
        LOGGER.info("init retrofit kupaiClient");
        kupaiClient = ServiceGenerator.createService(KupaiClient.class, kupaiDomain, 2000);
    }

    /**
     * 出价请求
     *
     * @param content
     * @return
     */
    public String sendPrice(JGroupMessage jGroupMessage, Bid content, ResponseProcessor responseProcessor) {
        //1.构造HTTP请求头
        Map<String, String> httpHeader = new HashMap<>();
        httpHeader.put(Constants.BAOKU_X_MATRIX_FROM_HEADER, "INNER");

        //2.解析content内容
        Map<String, String> parameterMap = new HashMap<>();
        parameterMap.put("saleId", content.getBidId());
        parameterMap.put("price", String.valueOf(content.getPrice()));
        parameterMap.put("isAnony", String.valueOf(content.getAnonymous()));
        parameterMap.put("fromUid", String.valueOf(content.getMeta().getFrom()));
        parameterMap.put("toUid", String.valueOf(content.getMeta().getTo()));
        //将extContent内容, url encoder后发送给后端
        String extContent = content.getExt();
        parameterMap.put("extContent", extContent);
        //3.调用出价API接口发送上行消息
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("success", true);
        ServiceGenerator.asyExecute(kupaiClient.sendPrice(sendPriceUrl, httpHeader, parameterMap), parameterMap, responseProcessor, jGroupMessage);
        String postResult = jsonObject == null ? "" : jsonObject.toString();
        return postResult;
    }
}
