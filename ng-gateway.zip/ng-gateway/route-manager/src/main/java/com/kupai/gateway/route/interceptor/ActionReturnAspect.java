package com.kupai.gateway.route.interceptor;

import com.alibaba.fastjson.JSONObject;
import com.kupai.gateway.route.context.RouteManagerContext;
import com.kupai.gateway.route.data.Result;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

/**
 * Created by zhangrui on 16/4/1.
 */
@Aspect
public class ActionReturnAspect {

    @Pointcut("@annotation(org.springframework.web.bind.annotation.RequestMapping)")
    public  void requestPointcut() {
    }

    @Pointcut("execution(public * com.kupai.gateway.route.controller..*.*(..))")
    public void recordRequestTime(){}

    @AfterReturning(pointcut="requestPointcut()",returning = "result")
    public void doAfter(JoinPoint jp, Result<Object> result) {
        RouteManagerContext.getRouteManagerContext().setResponse(JSONObject.toJSONString(result));
    }


    @Before("recordRequestTime()")
    public void doBefore() {
        RouteManagerContext.getRouteManagerContext().setStartTime(System.currentTimeMillis());
    }
}