package com.kupai.gateway.route.service.httpClient;

import com.google.gson.JsonObject;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Url;

/**
 * Created by Administrator on 2017/3/21.
 */
public interface ShUploadClient {

    /**
     * 上传多媒体文件
     * @param url
     * @param description
     * @param file
     * @return
     */
    @Multipart
    @POST
    Call<JsonObject> upload(@Url String url, @Part("description") RequestBody description, @Part MultipartBody.Part file);
}
