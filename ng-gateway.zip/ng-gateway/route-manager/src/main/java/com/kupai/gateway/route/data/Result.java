package com.kupai.gateway.route.data;

import java.io.Serializable;

/**
 * 此类的描述：
 *
 * @param <T>
 * @ClassName: Result
 * @Description: 数据封装对象
 * @author:yuepeng001
 * @date 2015年8月24日 下午4:40:11
 */
public class Result<T> implements Serializable {

    private static final long serialVersionUID = 588661676563845067L;

    /**
     * 错误编码
     */
    private int code;

    /**
     * 本地化的信息,对应错误编码的本地化说明
     */
    private String msg;

    /**
     * 执行状态
     */
    private boolean status;

    /**
     * 返回值对象
     */
    private T data;

    public Result() {
    }

    /**
     * 如果状态为true,默认 msg=succes code="0000" 创建一个新的实例 Result.
     *
     * @param status
     */
    public Result(boolean status) {
        if (status == true) {
            this.status = status;
            this.msg = "success";
            this.code = 0;
            this.data = (T) "{}";
        } else {
            this.status = status;
            this.msg = "请求失败";
            this.code = 1;
            this.data = (T) "{}";
        }

    }

    /**
     * 创建一个新的实例 Result.
     *
     * @param status
     * @param data
     */
    public Result(boolean status, T data) {
        this.status = status;
        this.data = data;
    }

    /**
     * 创建一个新的实例 Result. 对于增加、删除、修改成功或者失败的处理
     *
     * @param status
     * @param code
     */
    public Result(boolean status, int code, String msg) {
        this.status = status;
        this.code = code;
        this.msg = msg;
        this.data = (T) "{}";
    }

    /**
     * 对于查询或者需要返回Data数据的处理
     *
     * @param status
     * @param data
     */
    public Result(boolean status, int code, T data, String msg) {
        this.status = status;
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    /**
     * 如果放入的数据不为空, this.status = true;this.msg = "success";this.code = "0000"; 创建一个新的实例 Result.
     *
     * @param data
     */
    public Result(T data) {
        this.status = true;
        this.data = data;
        this.msg = "success";
        this.code = 0;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

}
