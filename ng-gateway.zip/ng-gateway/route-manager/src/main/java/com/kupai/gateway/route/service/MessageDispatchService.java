package com.kupai.gateway.route.service;

import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.JGroupsNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 消息分发服务
 * <p>
 * 1. 接收来自客户端的上行请求,解析消息格式并转发给后端服务
 * 2. 接收来自后端服务推送过来的消息(主要是IM消息服务),解析消息并分发给相应的拍卖间的所有连接
 * </p>
 * Date: 16/11/11
 * Time: 下午5:19
 *
 * @author lintc
 */
@Service("messageDispatchService")
public class MessageDispatchService{

    @Autowired
    private JGroupsNode jgroupsNode;

    /**
     * 转发webSocketFrame给相应的后端服务
     *
     * @param jGroupMessage
     */
    public void forward(JGroupMessage jGroupMessage) {
        jgroupsNode.sendMessage(jGroupMessage.getSourceAdd(), jGroupMessage);
    }
    /**
     * 转发到所有的RM
     *
     * @param jGroupMessage
     */
    public void forwardToRm(JGroupMessage jGroupMessage) {
        jgroupsNode.sendMessageToRM(jGroupMessage);
    }
}
