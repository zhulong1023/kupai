package com.kupai.gateway.route.handler;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.stereotype.Component;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.common.data.Command;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.route.handler.processor.DefaultRequestProcessor;
import com.kupai.gateway.route.model.Chatroom;
import com.kupai.gateway.route.service.ChatroomManageService;

/**
 * Created by zhulong on 2017/3/30.
 */
@Component
public class InOutRoomProcessHandler extends AbstractProcessHandler {
    private Logger log = LoggerFactory.getLogger(getClass());
    @Resource(name = "historyMessageCache")
    private CaffeineCache historyMessageCache;
    @Autowired
    private ChatroomManageService chatroomManageService;

    /**
     * 注册该处理器
     */
    @PostConstruct
    protected void registerHandler() {
        DefaultRequestProcessor.registerProcessHandler(RequestCode.ROOM, this);
    }

    @Override
    protected JGroupMessage doProcess0(JGroupMessage jGroupMessage) {
        log.info("process room in or out request {}", jGroupMessage);
        Command cmd = (Command) jGroupMessage.getData();
        Long roomId = jGroupMessage.getRoomId();
        if (null != roomId) {
            Integer resouce = Integer.valueOf(jGroupMessage.getSource());
            String key = roomId.longValue() + "_" + resouce.intValue();
            Chatroom room = (Chatroom) historyMessageCache.getNativeCache().asMap().get(key);
            if (null == room) {
                room = chatroomManageService.findChatroomById(roomId, resouce);
                if (room != null) {
                    historyMessageCache.put(key, room);
                }
            }
            
            if (room != null) {
                log.info("{} room success room={} uid={}", cmd.getMeta().getEvent(), roomId, jGroupMessage.getFrom());
                this.doResponse0(jGroupMessage, cmd.getMeta().getFrom(), ResponseCode.INOUT_ROOM_OK, jGroupMessage.getData());
            } else {
                log.info("{} room fail and room not exist, room={} uid={}", cmd.getMeta().getEvent(), roomId, jGroupMessage.getFrom());
                this.doResponse0(jGroupMessage, cmd.getMeta().getFrom(), ResponseCode.NONE_ROOM, ResponseMessage.ROOM_NOT_EXIST);
                return null;
            }
        }

        jGroupMessage.setSourceAdd(null);
        jGroupMessage.setSendType(JGroupMessage.SendType.MULTI.getValue());

        return jGroupMessage;
    }
}
