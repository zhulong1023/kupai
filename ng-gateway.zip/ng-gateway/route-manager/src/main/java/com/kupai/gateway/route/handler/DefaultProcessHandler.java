/**
 *
 */
package com.kupai.gateway.route.handler;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.jgroups.JGroupMessage;

/**
 * @author zhouqisheng 2017年3月24日
 */
@Component("defaultProcessHandler")
public class DefaultProcessHandler extends AbstractProcessHandler {

    /**
     * 处理接收到的消息
     *
     * @param jGroupMessage
     * @return
     */
    @Override
    protected JGroupMessage doProcess0(JGroupMessage jGroupMessage) {
        jGroupMessage.setCode(ResponseCode.CODE_NOT_SUPPORTED);
        jGroupMessage.setData("无效的业务码");
        List<Long> toUid = new ArrayList<>(1);
        toUid.add(jGroupMessage.getFrom());
        jGroupMessage.setToUid(toUid);

        return jGroupMessage;
    }
}
