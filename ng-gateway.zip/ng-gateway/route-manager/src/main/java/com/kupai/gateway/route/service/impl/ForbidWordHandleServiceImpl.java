package com.kupai.gateway.route.service.impl;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.kupai.gateway.common.util.JChineseConvertor;
import com.kupai.gateway.common.util.StringUtils;
import com.kupai.gateway.route.model.ForbidModule;
import com.kupai.gateway.route.model.ForbidWord;
import com.kupai.gateway.route.model.ForbidWordTrie;
import com.kupai.gateway.route.service.ForbidWordHandleService;
import com.kupai.gateway.route.service.ForbidWordService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by zhulong on 2017/3/25.
 * 敏感词处理接口
 */
@Service
public class ForbidWordHandleServiceImpl implements ForbidWordHandleService, InitializingBean {

    private static Logger LOGGER = LoggerFactory.getLogger(ForbidWordHandleServiceImpl.class);

    // 敏感词使用配置
    private LoadingCache<Integer, ForbidWordTrie> forbidWordTrieLoadingCache;
//    private LoadingCache<ForbidModule.Module, Map<Integer, ForbidWordConfig>> wordConfigs;

    // 默认3分钟重新加载一次
    private int loadPeriod = 3 * 1000 * 60;
    private JChineseConvertor convertor = JChineseConvertor.getInstance();

    @Resource
    ForbidWordService forbidWordService;

    public void setLoadPeriod(int loadPeriod) {
        this.loadPeriod = loadPeriod;
    }

    @Override
    public void afterPropertiesSet() throws Exception {

        loadWordConifg();
    }

    private void loadWordConifg() {

        forbidWordTrieLoadingCache = CacheBuilder.newBuilder().maximumSize(ForbidModule.Module.values().length).expireAfterWrite(loadPeriod, TimeUnit.MILLISECONDS)
                .build(new CacheLoader<Integer, ForbidWordTrie>() {
                    public ForbidWordTrie load(Integer source) {
                        List<ForbidWord> byId = forbidWordService.queryAll(source);

                        ForbidWordTrie trie = new ForbidWordTrie();
                        trie.setSize(byId.size());
                        for (ForbidWord w : byId) {
                            trie.add(w);
                        }
                        return trie;
                    }
                });

    }


    public ForbidModule.Result checkForbidWords(String text, int source) {
        ForbidModule.Result result = new ForbidModule.Result(text, false);
        if (StringUtils.isBlank(text)) {
            return result;
        }
        String simpleText = convertor.t2s(text);  //如果是繁体，先转换为简体
        try {
            List<ForbidWordTrie.ForbidWordVal> match = null;
            ForbidWordTrie globalForbidWordTrie = forbidWordTrieLoadingCache.get(-1);
            if (globalForbidWordTrie.getSize() > 0) {
                match = globalForbidWordTrie.match(simpleText);
            }

            ForbidWordTrie forbidWordTrie = forbidWordTrieLoadingCache.get(source);
            if (forbidWordTrie.getSize() > 0) {
                match.addAll(forbidWordTrie.match(simpleText));
            }

            if (match.size() == 0) {
                return result;
            }
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug(String.format("check ForbidWords text massage:", text));
                for (ForbidWordTrie.ForbidWordVal val : match) {
                    LOGGER.debug(String.format("check ForbidWords level =%s ,val = %s :", val.getLevel(), val.getVal()));
                }
            }
            // 是否需要根据敏感词的优先等级规则做不同的处理
            for (ForbidWordTrie.ForbidWordVal val : match) {
                // 敏感词设置未开启，则不处理
                if (val.getStatus() == 0) continue;
                if (val.getLevel() == ForbidModule.Value.use.getVal()) {
                    //豁免
                    continue;
                } else if (val.getLevel() == ForbidModule.Value.forbid.getVal()) {
                    //禁止使用
                    //throw new ForbidWoridException(getOriginText(text, simpleText, val.getVal()));
                    result.setFlag(true);
                } else if (val.getLevel() == ForbidModule.Value.use_with_mark.getVal()) {
                    //允许使用，但是将敏感词替换成***
                    String[] split = val.getVal().split("&");
                    for (String s : split) {
                        String originText = getOriginText(text, simpleText, s); //得到原词
                        text = text.replace(originText, "***");
                        simpleText = simpleText.replace(s, "***");
                    }
                    result.setText(text);
                }
            }
        } catch (Exception e) {
            LOGGER.error(String.format("check ForbidWords message is %s , error %s", text, e));
        }
        return result;
    }


    private String getOriginText(String origin, String simple, String word) {
        String result;
        int index, end;
        boolean same = StringUtils.equals(origin, simple);
        if (!same) {
            LOGGER.debug("getOriginText origin: " + origin + ",simple: " + simple + ",forbid word: " + word);
        }
        if (!same && (index = simple.indexOf(word)) > -1
                && (end = index + word.length()) <= origin.length()) {
            result = origin.substring(index, end);
        } else {
            result = word;
        }
        return result;
    }


}
