package com.kupai.gateway.route.controller;

import com.kupai.gateway.route.annocations.ApiStatus;
import com.kupai.gateway.route.annocations.AuthType;
import com.kupai.gateway.route.annocations.BaseInfo;
import com.kupai.gateway.route.annocations.SignType;
import com.kupai.gateway.route.data.Result;
import com.kupai.gateway.route.exception.ErrorResultCode;
import com.kupai.gateway.route.exception.RouteManagerExceptionUtils;
import com.kupai.gateway.route.service.MultimediaUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * 上传多媒体文件入口
 * Created by Administrator on 2017/3/21.
 */
@RestController
@RequestMapping(value = "/route/upload")
public class MultimediaUploadController {

    @Autowired
    private MultimediaUploadService multimediaUploadService;

    /**
     * 上传文件
     *
     * @param formFile
     * @return
     */
    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST, produces = "application/json")
    @BaseInfo(desc = "", status = ApiStatus.PUBLIC, needAuth = AuthType.OPTION, needSign = SignType.NOTNEED)
    public Result<Object> uploadFile(@RequestParam("file") MultipartFile formFile) {
        if (null != formFile) {
            return multimediaUploadService.upload(formFile);
        }
        throw RouteManagerExceptionUtils.throwRouteManagerException(ErrorResultCode.FILE_NOT_ALLOW_NULL);
    }
}
