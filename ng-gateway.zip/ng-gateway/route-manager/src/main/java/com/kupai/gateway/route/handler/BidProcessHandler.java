package com.kupai.gateway.route.handler;

import javax.annotation.PostConstruct;

import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.common.data.enumpac.Source;
import com.kupai.gateway.route.log.ApiLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.data.Bid;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.retrofit.ResponseProcessor;
import com.kupai.gateway.route.handler.processor.DefaultRequestProcessor;
import com.kupai.gateway.route.service.MessageDispatchService;
import com.kupai.gateway.route.service.MonitorService;
import com.kupai.gateway.route.service.third.KupaiService;

/**
 * 处理出价消息 Created by Administrator on 2017/3/27.
 */
@Component
public class BidProcessHandler implements ProcessHandler {

    @Autowired
    private KupaiService kupaiService;

    @Autowired
    private MonitorService monitorService;

    @Autowired
    private MessageDispatchService messageDispatchService;

    /**
     * 注册该处理器
     */
    @PostConstruct
    protected void registerHandler() {
        DefaultRequestProcessor.registerProcessHandler(RequestCode.BID, this);
    }

    /**
     * 处理接收到的消息
     *
     * @param jGroupMessage
     * @return
     */
    @Override
    public void doProcess(JGroupMessage jGroupMessage) {
        ApiLogger.info("bid message process, message info " + jGroupMessage.toString());
        monitorService.incrementBidAddMessage();
        Bid bid = (Bid) jGroupMessage.getData();
        // todo 判断系统来源，确定调用哪个系统接口
        if (jGroupMessage.getSource() == Source.KUPAI.getValue()) {
            kupaiService.sendPrice(jGroupMessage, bid, new ResponseProcessor() {
                @Override
                public void processor(Object responseResult, Object... object) {
                    // 符合条件才继续执行，否则丢弃
                    if (null != object && object.length == 1) {
                        JGroupMessage jGroupMessage = (JGroupMessage) object[0];
                        // 构建结果
                        jGroupMessage.setCode(ResponseCode.BID_OK);
                        jGroupMessage.setData(responseResult);
                        messageDispatchService.forward(jGroupMessage);
                    }
                }
            });
        } else if (jGroupMessage.getSource() == Source.OPEN_FLAT.getValue()){
            //todo 开放平台出价处理逻辑
        } else {
            // 构建结果
            jGroupMessage.setCode(ResponseCode.BID_FAILED);
            jGroupMessage.setData(ResponseMessage.NOT_SUPPORT_SOURCE);
            messageDispatchService.forward(jGroupMessage);
        }
    }
}
