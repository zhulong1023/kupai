package com.kupai.gateway.route.service;

import com.kupai.gateway.route.model.HistoryMessage;

import java.util.List;

/**
 * Created by zhaoshengqi on 2017/3/21.
 */


public interface HistoryMessageService {

    List<HistoryMessage> queryHistoryMessage(long msgId,String sessionId, int pageSize);

    /**
     * 查询syc消息列表
     *
     * @param msgId     游标 消息ID
     * @param sessionId 场景ID(roomID/toid+uid)
     * @param pageSize
     * @return
     */
    List<HistoryMessage> sycMessage(int pullType, long msgId, int pageSize, String sessionId);

    boolean receiveMessage( HistoryMessage historyMessage);

    boolean deleteMessage(String msgIds);

    /**
     * 获得当前回话中最大的messageId
     * @param sessionId 会话id
     * @return
     */
    String getHistoryMaxMessageId(String sessionId);

    /**
     * 查询已删除数据
     * @param sessionId
     * @return
     */
    List<HistoryMessage> queryInvalidHistoryMessage(String sessionId);
}
