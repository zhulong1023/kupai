package com.kupai.gateway.route.service.httpClient;

import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.Map;

/**
 * Created by Administrator on 2017/2/24.
 */
public interface YouyunClient {

    /**
     * post请求接口 发送im聊天消息
     * @param headerMap header列表
     * @param fieldMap 参数列表
     * @return
     */
    @FormUrlEncoded
    @POST
    Call<JsonObject> sendImMessage(@Url String url, @HeaderMap Map<String, String> headerMap, @FieldMap Map<String, String> fieldMap);

    /**
     * post请求接口 登录房间
     * @param headerMap header列表
     * @param fieldMap 参数列表
     * @return
     */
    @FormUrlEncoded
    @POST
    Call<JsonObject> loginRoom(@Url String url, @HeaderMap Map<String, String> headerMap, @FieldMap Map<String, String> fieldMap);

    /**
     * post请求接口  登出房间
     * @param headerMap header列表
     * @param fieldMap 参数列表
     * @return
     */
    @FormUrlEncoded
    @POST
    Call<JsonObject> quitRoom(@Url String url, @HeaderMap Map<String, String> headerMap, @FieldMap Map<String, String> fieldMap);

    /**
     * get请求接口
     * @param url 请求的url
     * @param headerMap header列表
     * @return
     */
    @GET
    Call<JsonObject> httpGet(@Url String url, @HeaderMap Map<String, String> headerMap);
}
