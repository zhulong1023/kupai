package com.kupai.gateway.route.base;

import com.kupai.gateway.common.redis.RedisConfig;
import com.kupai.gateway.common.util.IdWorker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by zhaoshengqi on 2017/3/30.
 */
@Configuration
@EnableAutoConfiguration
public class IdWorkerInit {
    private static Logger logger = LoggerFactory.getLogger(RedisConfig.class);

    @Value("${id.worker.worker.id}")
    private long workerId;
    @Value("${id.worker.data.center.id}")
    private long datacenterId;

    @Bean
    public IdWorker getIdWorker(){
        logger.info("getIdworker SUCCESS");
        return new IdWorker(workerId, datacenterId);
    }

    public long getWorkerId() {
        return workerId;
    }

    public void setWorkerId(long workerId) {
        this.workerId = workerId;
    }

    public long getDatacenterId() {
        return datacenterId;
    }

    public void setDatacenterId(long datacenterId) {
        this.datacenterId = datacenterId;
    }
}
