package com.kupai.gateway.route.filter;

import com.kupai.gateway.common.contants.ResponseMessage;
import com.kupai.gateway.common.data.DataMeta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kupai.gateway.common.annotations.RegistrantConfiguration;
import com.kupai.gateway.common.contants.RequestCode;
import com.kupai.gateway.common.contants.ResponseCode;
import com.kupai.gateway.common.data.Text;
import com.kupai.gateway.common.jgroups.JGroupMessage;
import com.kupai.gateway.common.jgroups.JGroupsNode;
import com.kupai.gateway.route.service.BlackUserOptionService;
import com.kupai.gateway.route.service.BlackWhiteUserOptionService;
import com.kupai.gateway.route.service.InterimBlackUserOptionService;

import java.util.ArrayList;
import java.util.List;

/**
 * 黑名单验证filter Created by Administrator on 2017/3/27.
 */
@Component
@RegistrantConfiguration(code = { RequestCode.MSG_TEXT }, order = 2)
public class BlackUserValidateFilter extends AbstractMessageFilter {

    @Autowired
    private BlackUserOptionService blackUserOptionService;

    @Autowired
    private InterimBlackUserOptionService interimBlackUserOptionService;

    @Autowired
    private BlackWhiteUserOptionService blackWhiteUserOptionService;

    /**
     * 处理具体的消息,处理黑名单
     *
     * @param jGroupMessage
     */
    @Override
    public boolean preHandler(JGroupsNode jgroupsNode, JGroupMessage jGroupMessage) {
        // 只针对于聊天文本消息进行黑名单验证
        if (jGroupMessage.getCode() == RequestCode.MSG_TEXT) {
            // 房间消息才进行禁言验证
            Text text = (Text) jGroupMessage.getData();
            String source = String.valueOf(jGroupMessage.getSource());
            String fromUid = String.valueOf(jGroupMessage.getFrom());
            DataMeta meta = text.getMeta();
            Long to = meta.getTo();
            String roomId = to == null ? "0" : String.valueOf(to);
            // 验证全局黑名单
            boolean isBlackUser = blackUserOptionService.isBlackUser(source, fromUid);
            if (isBlackUser) {
                // 组装黑名单提示消息
                this.assembleAndSendJGroupMessage(jgroupsNode, jGroupMessage);
                return false;
            }
            // 验证房间黑名单
            isBlackUser = interimBlackUserOptionService.isInInterimBlack(source, roomId, fromUid);
            if (isBlackUser) {
                // 组装黑名单提示消息
                this.assembleAndSendJGroupMessage(jgroupsNode, jGroupMessage);
                return false;
            }

            // 验证机构设置黑名单
            isBlackUser = blackWhiteUserOptionService.isBlackUser(fromUid, source, roomId, 1);
            if (isBlackUser) {
                // 组装黑名单提示消息
                this.assembleAndSendJGroupMessage(jgroupsNode, jGroupMessage);
                return false;
            }
        }
        return true;
    }

    /**
     * 如果在和名单中，对JGroupMessage进行组装
     *
     * @param jGroupMessage
     */
    private void assembleAndSendJGroupMessage(JGroupsNode jGroupsNode, JGroupMessage jGroupMessage) {
        List<Long> list = new ArrayList<>(1);
        list.add(jGroupMessage.getFrom());
        jGroupMessage.setToUid(list);
        jGroupMessage.setCode(ResponseCode.USER_IN_BLACK);
        jGroupMessage.setData(ResponseMessage.USER_IN_BLACK);
        jGroupsNode.sendMessage(jGroupMessage.getSourceAdd(), jGroupMessage);
    }
}
