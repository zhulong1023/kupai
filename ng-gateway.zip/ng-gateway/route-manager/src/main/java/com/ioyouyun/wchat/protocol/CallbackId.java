package com.ioyouyun.wchat.protocol;

/**
 * 回调标记类
 */
public class CallbackId {
    public static final String HeartbeatActive = "1";
    public static final String Heartbeat = "2";
    public static final String BasicHandShake = "3";
    public static final String WOAuthShake = "4";
    public static final String MAuth = "5";
    public static final String AuthLapse = "6";
    public static final String Sync = "7";
    public static final String FolderSync = "8";
    public static final String FolderCreate = "9";
    public static final String FolderDelete = "10";
    public static final String RecvNotice = "11";
    public static final String SipChannel = "12";
    public static final String GroupCreate = "13";
    public static final String GetItemUnread = "14";
    public static final String SendFile = "15";
    public static final String GetFile = "16";
    public static final String ItemOperations = "17";
    public static final String NoticeMessage = "18";
    public static final String AppProxy = "19";
    public static final String Logout = "20";
}
