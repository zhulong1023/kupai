package com.ioyouyun.wchat.protocol;

public class WeimiSort {
    public static final int heartbeat = 0x001;
    public static final int close = 0x011;
    public static final int wchat = 0x101;
    public static final int handshake = 0x111;
    public static final int notice = 0x112; // wchat notice
    public static final int weimi_gateway_notice = 0x114; // meyou gateway notice
    public static final int contact = 0x141;
    public static final int plugin = 0x181;
    public static final int appproxy = 0x184; // wemichannel
    public static final int logout = 0x190; // logout
    public static final int sipchannel = 0x301; // SipChannel
    public static final int conference = 0x304; // Conference Operation
}
