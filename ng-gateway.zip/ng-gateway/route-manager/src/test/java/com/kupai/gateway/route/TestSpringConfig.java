package com.kupai.gateway.route;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.web.WebAppConfiguration;

/**
 * Date: 16/8/19
 * Time: 上午11:00
 *
 * @author lintc
 */
@Configuration
@ComponentScan(basePackages = {"com.kupai.gateway"})
@EnableAspectJAutoProxy
@WebAppConfiguration
@PropertySource({"classpath:application.properties",
        "classpath:application-db.properties",
        "classpath:application-redis.properties"})
public class TestSpringConfig {

}
