package com.kupai.gateway.route;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Created by Administrator on 2017/3/28.
 */
public class TestGoogleCache {
    public static void main(String[] args) throws ExecutionException, InterruptedException {

        LoadingCache<String, Map<String, String>> loadingCache = CacheBuilder.newBuilder().maximumSize(10).expireAfterWrite(30000, TimeUnit.MILLISECONDS)
                .build(new CacheLoader<String, Map<String, String>>() {
                    @Override
                    public Map<String, String> load(String key) throws Exception {
                        System.out.println("reload in memory");
                        Map<String, String> _cache = new HashMap<>();
                        _cache.put("1", "zhang");
                        _cache.put("2", "shi");
                        _cache.put("3", "chen");
                        return _cache;
                    }
                });

        for (int i = 0; i < 10; i ++) {
            Map<String, String> result = loadingCache.get(i + "");
            if (null != result) {
                result.remove(i + "");
                System.out.println(result);
            } else {
                System.out.println("cache is null");
            }
        }
    }
}
