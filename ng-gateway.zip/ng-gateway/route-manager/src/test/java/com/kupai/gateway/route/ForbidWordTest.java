package com.kupai.gateway.route;

import com.kupai.gateway.route.model.Chatroom;
import com.kupai.gateway.route.model.ForbidModule;
import com.kupai.gateway.route.service.ChatroomManageService;
import com.kupai.gateway.route.service.ForbidWordHandleService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by zhulong on 2017/3/24.
 * 敏感词test
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TestSpringConfig.class)
public class ForbidWordTest {

    private static Logger LOGGER = LoggerFactory.getLogger(ForbidWordTest.class);

    @Autowired
    private ForbidWordHandleService forbidWordService;
    @Autowired
    private ChatroomManageService chatroomManageService;


    @Test
    public void testForbidWordLocalCache() throws Exception {

        // 测试内容
        String key = "少时诵诗书所所所所所所所都是对的多多多多多多多多西藏独立宣言ssssss" +
                "到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度" +
                "到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度" +
                "到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度" +
                "到处都是从市场上的程度到处都是从市场上的程自棼处都是从市场上的程度到处都是从市场上的程度" +
                "到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度" +
                "到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度" +
                "到处都是从市场上的程度到处都是从市场上的白色星期三都是从市场上的程度到处都是从市场上的程度" +
                "到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上裆钟央发炎人是从市场上的程度" +
                "到处都是从市场上的程度到处都是从市zheng变度到处都是从市场上的程度到处都是从市场上的程度" +
                "到处都是从市场上的程度到处都是从市场上的程度到处都是从市场上的程度到处裆肿娘市场上的程度";
        String key2 = "狗日的dddddddd";
        /*File file = new File("E:/desk/forbidword.txt");
        int countChar =0;
        //创建一个读取文件的流对象
        //FileReader fileReader = new FileReader(file);
        //bufferreader只是进行了一下封装，是读取的效率更高
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8"));
        String str;
        StringBuilder sb = new StringBuilder();
        while ((str =bufferedReader.readLine())!=null){
            sb.append(str);
            countChar += str.length();//字符个数就是字符长度
        }*/
        long start, end;
        start = System.currentTimeMillis();
        System.out.println("开始时间：-------------" + start);
        ForbidModule.Result result = forbidWordService.checkForbidWords(key2,1);
        end = System.currentTimeMillis();
        System.out.println("结束时间：-------------" + end);
//        System.out.println("统计结果为：敏感词检测时间为"+(end-start)/1000+"s  字符数统计为:"+countChar);
        System.out.println("返回结果为：" + result.getText() + "-----------------------------");
        if (result.getFlag()) {
            System.out.println("禁止使用该词---------------------------------------------");
        }
        //fileReader.close();
//        bufferedReader.close();

    }

    @Test
    public void testChatroom() {

        Long id = Long.valueOf(1491900176);
        Chatroom room = chatroomManageService.findChatroomById(id, 1);
    }


}
