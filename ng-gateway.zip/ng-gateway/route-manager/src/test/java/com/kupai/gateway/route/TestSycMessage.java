package com.kupai.gateway.route;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/4/13.
 */
public class TestSycMessage {

    public static void main(String[] args) {
        List<Integer> a = new ArrayList<>();
        for (int i = 0; i < 5; i ++) {
            a.add(i + 1);
        }
        List<Integer> sub = new ArrayList<>();
        long startTime = System.currentTimeMillis();
        int pageSize = 5;
        int size = a.size();
        if (size > pageSize) {
            sub = a.subList(0, pageSize);
        } else {
            sub = a.subList(0, size);
        }
        /*
        for (int i = size - 1; i >= 0; i --) {
            Integer x = a.get(i);
            if (x.intValue() == 99998) {
                int toIndex = size;
                if (size - (i + 1) > 5) {
                    toIndex = i + 1 + 5;
                }
                sub = a.subList(i + 1, toIndex);
            }
        }*/

        System.out.println(sub);
        System.out.println(System.currentTimeMillis() - startTime);
    }
}
